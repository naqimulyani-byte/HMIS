
import React from 'react';
import { 
  LayoutDashboard, 
  UserPlus, 
  Bed, 
  Beaker, 
  Scan, 
  ClipboardList, 
  Settings, 
  Users, 
  FileText, 
  History, 
  Database,
  ShieldCheck,
  RotateCcw,
  Stethoscope,
  Building2,
  Printer
} from 'lucide-react';
import { PanelCategory, UserRole } from './types';

export const PRIMARY_COLOR = '#8B0000'; // Dark Red

export const NAVIGATION_ITEMS = [
  { id: 'dashboard', label: 'Overview', icon: <LayoutDashboard size={20} />, subtitle: 'Dashboard & Metrics' },
  { id: 'registration', label: 'Registration', icon: <UserPlus size={20} />, subtitle: 'Add New Patient' },
  { id: 'admission', label: 'Pt. Admission', icon: <Bed size={20} />, subtitle: 'Admit to Wards' },
  { id: 'lab-counter', label: 'Lab Counter', icon: <Beaker size={20} />, subtitle: 'Lab Payments' },
  { id: 'lab-results', label: 'Add Lab Results', icon: <ClipboardList size={20} />, subtitle: 'Add Test Results' },
  { id: 'lab-reports', label: 'Print Lab Reports', icon: <Printer size={20} />, subtitle: 'Print Lab Reports' },
  { id: 'radiology', label: 'Radiology Counter', icon: <Scan size={20} />, subtitle: 'Radiology Payments' },
  { id: 'procedures', label: 'Procedure Counter', icon: <Stethoscope size={20} />, subtitle: 'Procedure Payments' },
  { id: 'speciality-setup', label: 'Speciality Setup', icon: <Building2 size={20} />, subtitle: 'Manage Specialities' },
  { id: 'lab-setup', label: 'Lab. Tests Setup', icon: <Beaker size={20} />, subtitle: 'Manage Tests' },
  { id: 'ward-setup', label: 'Ward Setup', icon: <Bed size={20} />, subtitle: 'Manage Wards' },
  { id: 'panel-setup', label: 'Panel Categories', icon: <ClipboardList size={20} />, subtitle: 'Manage Panels' },
  { id: 'hospital-setup', label: 'Hospital Setup', icon: <Settings size={20} />, subtitle: 'Basic Configuration' },
  { id: 'user-management', label: 'User Management', icon: <Users size={20} />, subtitle: 'Manage Staff' },
  { id: 'role-management', label: 'Role Management', icon: <ShieldCheck size={20} />, subtitle: 'Manage User Roles' },
  { id: 'refund', label: 'Process Refund', icon: <RotateCcw size={20} />, subtitle: 'Refund Payments' },
  { id: 'reports', label: 'All Reports', icon: <FileText size={20} />, subtitle: 'Lab, Rad, Proc, Adm, Ref' },
  { id: 'activity-logs', label: 'Activity Logs', icon: <History size={20} />, subtitle: 'System History' },
  { id: 'backup', label: 'Backup & Restore', icon: <Database size={20} />, subtitle: 'Database Tools' },
];

// Added isActive: true to each category to fix TypeScript errors regarding missing required property
export const PANEL_CATEGORIES: PanelCategory[] = [
  { id: '1', name: 'All Categories', discount: 0, color: 'border-red-800', badge: 'bg-red-50 text-red-800', isActive: true },
  { id: '2', name: 'Poor', discount: 40, color: 'border-gray-500', badge: 'bg-gray-100 text-gray-700', isActive: true },
  { id: '3', name: 'ER Patient', discount: 0, color: 'border-pink-400', badge: 'bg-pink-50 text-pink-600', isActive: true },
  { id: '4', name: 'Paying', discount: 0, color: 'border-blue-600', badge: 'bg-blue-50 text-blue-700', isActive: true },
  { id: '6', name: 'Health Card', discount: 100, color: 'border-purple-600', badge: 'bg-purple-50 text-purple-700', isActive: true },
];

export const SPECIALITIES = [
  'Eye OPD (Room 101)',
  'Male Medical OPD',
  'Female Medical OPD',
  'Derma OPD',
  'Ortho OPD',
  'Pediatrics OPD',
  'ENT OPD',
  'Trauma Unit',
];
