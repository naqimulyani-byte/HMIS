
import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Registration from './components/Registration';
import Admission from './components/Admission';
import LabCounter from './components/LabCounter';
import LabResults from './components/LabResults';
import LabReports from './components/LabReports';
import RadiologyCounter from './components/RadiologyCounter';
import ProcedureCounter from './components/ProcedureCounter';
import SpecialitySetup from './components/SpecialitySetup';
import LabTestSetup from './components/LabTestSetup';
import WardSetup, { Ward } from './components/WardSetup';
import PanelSetup from './components/PanelSetup';
import HospitalSetup from './components/HospitalSetup';
import UserManagement from './components/UserManagement';
import RoleManagement from './components/RoleManagement';
import ProcessRefund from './components/ProcessRefund';
import UnifiedReports from './components/UnifiedReports';
import Login from './components/Login';
import { Home, UserPlus, FileText, Menu, Users, X, ChevronRight, LayoutGrid } from 'lucide-react';
import { PRIMARY_COLOR, NAVIGATION_ITEMS } from './constants';
import { Role, PanelCategory, HospitalConfig, User } from './types';

interface Parameter {
  id: string;
  name: string;
  type: string;
  unit: string;
  min: string;
  max: string;
}

interface Test {
  id: string;
  name: string;
  fee: number;
  isActive: boolean;
  parameters: Parameter[];
}

export interface AppPatient {
  id: string;
  mrNo: string;
  name: string;
  guardianName: string;
  gender: string;
  yy: string;
  mm: string;
  dd: string;
  contact: string;
  cnic: string;
  address: string;
  speciality: string;
  status: string;
}

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Global Hospital Configuration
  const [hospitalConfig, setHospitalConfig] = useState<HospitalConfig>({
    name: 'District Headquarter Hospital, Sudhnuti',
    address: 'Palandri Baral Road, Pallandri, Sudhnuti, AJK',
    contact: '+92 (058259) 20024',
    phcNo: 'PHC-REG-12345',
    email: 'info@dhqsudhnuti.gov.pk',
    logo: null
  });

  const [patients, setPatients] = useState<AppPatient[]>([
    { id: '1', mrNo: '2601010003', name: 'HAROON', guardianName: 'Abdullah', gender: 'Male', yy: '5', mm: '2', dd: '10', contact: '03001234567', cnic: '33101-1234567-1', address: 'Sudhnuti', speciality: 'Eye OPD (Room 101)', status: 'Waiting' },
    { id: '2', mrNo: '2601010002', name: 'SAIF ULLAH', guardianName: 'Iqbal', gender: 'Male', yy: '25', mm: '0', dd: '0', contact: '03121234567', cnic: '33101-7654321-1', address: 'Palandri', speciality: 'Pediatrics OPD', status: 'Admitted' },
    { id: '3', mrNo: '2601010001', name: 'SAJJAAD', guardianName: 'Ahmed', gender: 'Male', yy: '22', mm: '5', dd: '0', contact: '03211234567', cnic: '33101-9999999-1', address: 'Baral', speciality: 'Derma OPD', status: 'Waiting' },
  ]);

  const [labTests, setLabTests] = useState<Test[]>([
    { id: '1', name: 'CBC', fee: 700, isActive: true, parameters: [{ id: 'p1', name: 'WBC', type: 'Numeric Value', unit: 'mgg', min: '1000', max: '7000' }, { id: 'p2', name: 'Hemoglobin', type: 'Numeric Value', unit: 'g/dL', min: '13', max: '18' }] },
    { id: '2', name: 'Liver Function Test (LFT)', fee: 1200, isActive: true, parameters: [] },
  ]);

  const [wards, setWards] = useState<Ward[]>([
    { id: '1', name: 'Male Medical Ward', type: 'General', capacity: 20, floor: '1st' },
    { id: '4', name: 'Emergency ICU', type: 'Critical', capacity: 20, floor: 'Ground' },
  ]);

  const [panelCategories, setPanelCategories] = useState<PanelCategory[]>([
    { id: '1', name: 'All Categories', discount: 0, color: 'border-red-800', badge: 'bg-red-50 text-red-800', isActive: true },
    { id: '4', name: 'Paying', discount: 0, color: 'border-blue-600', badge: 'bg-blue-50 text-blue-700', isActive: true, description: 'General Cash Paying' },
    { id: '6', name: 'Health Card', discount: 100, color: 'border-purple-600', badge: 'bg-purple-50 text-purple-700', isActive: true, description: 'Sehat Sahulat Program' },
  ]);

  const [roles, setRoles] = useState<Role[]>([
    { id: '1', name: 'Counter', description: 'REGISTRATION AND PAYMENTS', permissions: ['lab_counter', 'pt_adm', 'pt_reg', 'proc_counter', 'rad_counter', 'proc_refunds', 'lab_rep_view'] },
    { id: '2', name: 'Doctor', description: 'CONSULTATION AND RESULTS', permissions: ['lab_rep_view', 'lab_res_entry', 'view_dash'] },
    { id: '3', name: 'Admin', description: 'FULL SYSTEM ACCESS', permissions: [] }, 
  ]);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentUser(null);
    setActiveTab('dashboard');
  };

  const handleMobileNav = (tabId: string) => {
    setActiveTab(tabId);
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Logic to filter menu based on Admin role
  const adminOnlyTabs = ['user-management', 'role-management', 'hospital-setup', 'speciality-setup', 'lab-setup', 'ward-setup', 'panel-setup'];
  const isUserAdmin = currentUser?.role === 'Admin';
  
  const filteredNavItems = NAVIGATION_ITEMS.filter(item => {
    if (adminOnlyTabs.includes(item.id)) return isUserAdmin;
    return true;
  });

  if (!isAuthenticated) {
    return <Login onLoginSuccess={handleLogin} hospitalName={hospitalConfig.name} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard />;
      case 'registration': return <Registration hospitalConfig={hospitalConfig} patients={patients} setPatients={setPatients} />;
      case 'admission': return <Admission patients={patients} />;
      case 'lab-counter': return <LabCounter availableTests={labTests} />;
      case 'lab-results': return <LabResults />;
      case 'lab-reports': return <LabReports hospitalConfig={hospitalConfig} />;
      case 'radiology': return <RadiologyCounter />;
      case 'procedures': return <ProcedureCounter />;
      case 'speciality-setup': return isUserAdmin ? <SpecialitySetup /> : <Dashboard />;
      case 'lab-setup': return isUserAdmin ? <LabTestSetup tests={labTests} setTests={setLabTests} /> : <Dashboard />;
      case 'ward-setup': return isUserAdmin ? <WardSetup wards={wards} setWards={setWards} /> : <Dashboard />;
      case 'panel-setup': return isUserAdmin ? <PanelSetup panels={panelCategories} setPanels={setPanelCategories} /> : <Dashboard />;
      case 'hospital-setup': return isUserAdmin ? <HospitalSetup config={hospitalConfig} setConfig={setHospitalConfig} wards={wards} setWards={setWards} panels={panelCategories} setPanels={setPanelCategories} roles={roles} setRoles={setRoles} labTests={labTests} setLabTests={setLabTests} /> : <Dashboard />;
      case 'user-management': return isUserAdmin ? <UserManagement roles={roles} /> : <Dashboard />;
      case 'role-management': return isUserAdmin ? <RoleManagement roles={roles} setRoles={setRoles} /> : <Dashboard />;
      case 'refund': return <ProcessRefund hospitalConfig={hospitalConfig} />;
      case 'reports': return <UnifiedReports />;
      default: return <div className="p-20 text-center font-black uppercase text-slate-300">Module Access Restricted</div>;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex overflow-x-hidden">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} currentUser={currentUser} />
      
      <main className="flex-1 lg:ml-72 flex flex-col min-h-screen relative">
        <Header title={activeTab.split('-').join(' ').toUpperCase()} onLogout={handleLogout} hospitalName={hospitalConfig.name} currentUser={currentUser} />
        
        <div className="pt-16 md:pt-20 pb-24 lg:pb-6 flex-1 overflow-x-hidden w-full">
          {renderContent()}
        </div>

        {isMobileMenuOpen && (
          <div className="lg:hidden fixed inset-0 z-[10000] animate-in fade-in duration-200">
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)} />
            <div className="absolute right-0 top-0 bottom-0 w-[85%] max-w-sm bg-white shadow-2xl flex flex-col animate-in slide-in-from-right duration-300">
               <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                  <div>
                    <h3 className="font-black text-[#8B0000] text-xl uppercase leading-none">HMIS Menu</h3>
                    <p className="text-[10px] text-slate-400 font-bold uppercase mt-1 tracking-widest">{currentUser?.fullName} • {currentUser?.role}</p>
                  </div>
                  <button onClick={() => setIsMobileMenuOpen(false)} className="p-2.5 bg-white rounded-2xl shadow-sm border border-slate-100 text-slate-400"><X size={24} /></button>
               </div>
               <div className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
                  {filteredNavItems.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => handleMobileNav(item.id)}
                      className={`w-full flex items-center p-4 rounded-2xl transition-all duration-200 ${
                        activeTab === item.id ? 'bg-[#8B0000] text-white shadow-xl shadow-red-900/20' : 'text-slate-500 hover:bg-slate-50'
                      }`}
                    >
                      <div className={`p-2 rounded-xl mr-4 ${activeTab === item.id ? 'bg-white/20' : 'bg-slate-100 text-slate-400'}`}>
                        {React.cloneElement(item.icon as React.ReactElement, { size: 20 })}
                      </div>
                      <div className="text-left flex-1">
                        <div className={`font-black text-xs uppercase tracking-wide ${activeTab === item.id ? 'text-white' : 'text-slate-800'}`}>{item.label}</div>
                      </div>
                      <ChevronRight size={14} className={activeTab === item.id ? 'text-white/60' : 'text-gray-300'} />
                    </button>
                  ))}
               </div>
            </div>
          </div>
        )}

        <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-slate-100 flex items-center justify-around py-3 px-4 shadow-[0_-10px_25px_rgba(0,0,0,0.05)] z-50 h-20">
          <button onClick={() => handleMobileNav('dashboard')} className={`flex flex-col items-center p-2 flex-1 rounded-2xl ${activeTab === 'dashboard' ? 'text-[#8B0000] bg-red-50' : 'text-slate-400'}`}><Home size={20} /><span className="text-[9px] font-black uppercase mt-1">Home</span></button>
          <button onClick={() => handleMobileNav('registration')} className={`flex flex-col items-center p-2 flex-1 rounded-2xl ${activeTab === 'registration' ? 'text-[#8B0000] bg-red-50' : 'text-slate-400'}`}><UserPlus size={20} /><span className="text-[9px] font-black uppercase mt-1">Reg.</span></button>
          <div className="relative -top-8 px-2"><button className="w-14 h-14 rounded-[1.5rem] bg-[#8B0000] text-white shadow-xl flex items-center justify-center border-4 border-slate-50" onClick={() => setIsMobileMenuOpen(true)}><Menu size={28} /></button></div>
          <button onClick={() => handleMobileNav('reports')} className={`flex flex-col items-center p-2 flex-1 rounded-2xl ${activeTab === 'reports' ? 'text-[#8B0000] bg-red-50' : 'text-slate-400'}`}><FileText size={20} /><span className="text-[9px] font-black uppercase mt-1">Reports</span></button>
          <button onClick={() => handleMobileNav('hospital-setup')} className={`flex flex-col items-center p-2 flex-1 rounded-2xl ${activeTab === 'hospital-setup' ? 'text-[#8B0000] bg-red-50' : 'text-slate-400'}`}><Users size={20} /><span className="text-[9px] font-black uppercase mt-1">Setup</span></button>
        </div>
      </main>
      <style>{`.custom-scrollbar::-webkit-scrollbar { width: 4px; } .custom-scrollbar::-webkit-scrollbar-track { background: transparent; } .custom-scrollbar::-webkit-scrollbar-thumb { background: #E2E8F0; border-radius: 10px; }`}</style>
    </div>
  );
};

export default App;
