
import React, { useState, useMemo } from 'react';
import { Building2, Search, Trash2, Edit2, Plus, X, ChevronDown, Check, Save } from 'lucide-react';
import { PRIMARY_COLOR } from '../constants';

interface Speciality {
  id: string;
  department: string;
  opdName: string;
  building: string;
  floor: string;
  roomNo: string;
}

const SpecialitySetup: React.FC = () => {
  const [specialities, setSpecialities] = useState<Speciality[]>([
    { id: '1', department: 'Department of General Surgery', opdName: 'Surgical OPD', building: 'Main OPD Block', floor: 'Ground Floor', roomNo: '101' },
    { id: '2', department: 'Dentistry Department', opdName: 'Dental OPD', building: 'Main OPD Block', floor: 'Ground Floor', roomNo: '101' },
    { id: '3', department: 'Pediatrics Medicine Department', opdName: 'Pediatrics OPD', building: 'Main OPD Block', floor: 'Ground Floor', roomNo: '101' },
    { id: '4', department: 'Department of Gynae & Obs', opdName: 'Gynae OPD', building: 'Main OPD Block', floor: 'Ground Floor', roomNo: '115' },
    { id: '5', department: 'General Medicine Department', opdName: 'Male Medical OPD', building: 'Main OPD Block', floor: 'Ground Floor', roomNo: '51' },
    { id: '6', department: 'Department of Dermatology', opdName: 'Derma OPD', building: 'Main OPD Block', floor: 'Ground Floor', roomNo: '101' },
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(true);

  const [formData, setFormData] = useState({
    department: '',
    opdName: '',
    building: '',
    floor: '',
    roomNo: ''
  });

  const filteredSpecialities = useMemo(() => {
    return specialities.filter(s => 
      s.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.opdName.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [specialities, searchQuery]);

  const handleSelect = (spec: Speciality) => {
    setSelectedId(spec.id);
    setFormData({
      department: spec.department,
      opdName: spec.opdName,
      building: spec.building,
      floor: spec.floor,
      roomNo: spec.roomNo
    });
  };

  const handleClear = () => {
    setSelectedId(null);
    setFormData({
      department: '',
      opdName: '',
      building: '',
      floor: '',
      roomNo: ''
    });
  };

  const handleSave = () => {
    if (!formData.department || !formData.opdName) {
      alert('Department and OPD Name are required');
      return;
    }

    if (selectedId) {
      setSpecialities(prev => prev.map(s => s.id === selectedId ? { ...formData, id: selectedId } : s));
    } else {
      const newSpec = {
        ...formData,
        id: Math.random().toString(36).substr(2, 9)
      };
      setSpecialities(prev => [...prev, newSpec]);
    }
    handleClear();
  };

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (window.confirm('Are you sure you want to delete this speciality?')) {
      setSpecialities(prev => prev.filter(s => s.id !== id));
      if (selectedId === id) handleClear();
    }
  };

  return (
    <div className="p-4 md:p-6 max-w-[1600px] mx-auto flex flex-col lg:flex-row gap-6 h-[calc(100vh-120px)]">
      
      {/* Left Column: List */}
      <div className="w-full lg:w-96 flex flex-col space-y-4 shrink-0 h-full overflow-hidden">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-black text-[#8B0000] uppercase tracking-tight">Specialities</h3>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 flex flex-col flex-1 overflow-hidden">
          <div className="p-4 border-b border-slate-50">
            <div className="relative">
              <input 
                type="text" 
                placeholder="Search specialities..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-100 bg-slate-50 focus:border-[#8B0000] outline-none text-sm font-medium transition-all"
              />
              <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-300" />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
            {filteredSpecialities.map((spec) => (
              <div 
                key={spec.id}
                onClick={() => handleSelect(spec)}
                className={`p-4 rounded-xl border-2 transition-all cursor-pointer group relative ${
                  selectedId === spec.id 
                  ? 'border-[#8B0000] bg-red-50/20 shadow-md' 
                  : 'border-slate-50 bg-slate-50/50 hover:bg-white hover:border-slate-200'
                }`}
              >
                <div className="pr-8">
                  <h4 className={`font-black text-xs uppercase leading-tight mb-1 ${selectedId === spec.id ? 'text-[#8B0000]' : 'text-slate-800'}`}>
                    {spec.department}
                  </h4>
                  <p className="text-[10px] font-bold text-slate-500 uppercase">{spec.opdName}</p>
                  <div className="text-[9px] font-medium text-slate-400 mt-2 uppercase tracking-tight">
                    {spec.building} | {spec.floor} | Room: {spec.roomNo}
                  </div>
                </div>
                <button 
                  onClick={(e) => handleDelete(e, spec.id)}
                  className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-300 hover:text-red-600 hover:bg-red-50 transition-all opacity-0 group-hover:opacity-100"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right Column: Configuration */}
      <div className="flex-1 space-y-6 h-full overflow-y-auto custom-scrollbar pr-2 pb-6">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-5 border-b border-slate-100">
            <h3 className="text-base font-black text-[#8B0000] uppercase tracking-tight">Speciality Configuration</h3>
          </div>
          
          <div className="p-6 md:p-8 space-y-8">
            {/* Form Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1 relative">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Department (Main Heading)</label>
                <input 
                  type="text" 
                  value={formData.department}
                  onChange={(e) => setFormData({...formData, department: e.target.value})}
                  placeholder="e.g. Department of General Surgery"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner uppercase" 
                />
              </div>
              <div className="space-y-1 relative">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">OPD Name (Sub Heading)</label>
                <input 
                  type="text" 
                  value={formData.opdName}
                  onChange={(e) => setFormData({...formData, opdName: e.target.value})}
                  placeholder="e.g. Surgical OPD"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner uppercase" 
                />
              </div>
              <div className="space-y-1 relative">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Building (e.g. Trauma Center)</label>
                <input 
                  type="text" 
                  value={formData.building}
                  onChange={(e) => setFormData({...formData, building: e.target.value})}
                  placeholder="Main OPD Block"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner" 
                />
              </div>
              <div className="space-y-1 relative">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Floor (e.g. Ground Floor)</label>
                <input 
                  type="text" 
                  value={formData.floor}
                  onChange={(e) => setFormData({...formData, floor: e.target.value})}
                  placeholder="Ground Floor"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner" 
                />
              </div>
              <div className="space-y-1 relative md:col-span-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Room No.</label>
                <input 
                  type="text" 
                  value={formData.roomNo}
                  onChange={(e) => setFormData({...formData, roomNo: e.target.value})}
                  placeholder="101"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner" 
                />
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4 border-t border-slate-50">
              <button 
                onClick={handleClear}
                className="flex-1 py-3.5 rounded-xl border-2 border-slate-100 text-slate-400 font-black text-xs uppercase tracking-widest hover:bg-slate-50 transition-all"
              >
                Clear
              </button>
              <button 
                onClick={handleSave}
                className="flex-[2] py-3.5 rounded-xl bg-[#8B0000] text-white font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-red-900/20 active:scale-95 transition-all flex items-center justify-center space-x-3"
              >
                {selectedId ? <><Edit2 size={16} /> <span>Update</span></> : <><Plus size={16} /> <span>Save Speciality</span></>}
              </button>
            </div>
          </div>
        </div>

        {/* Real-time Preview Section */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <button 
            onClick={() => setShowPreview(!showPreview)}
            className="w-full p-4 flex items-center justify-between hover:bg-slate-50 transition-colors"
          >
            <div className="flex items-center space-x-3">
              <Plus size={16} className={`text-[#8B0000] transition-transform ${showPreview ? 'rotate-45' : ''}`} />
              <span className="text-[11px] font-black text-slate-800 uppercase tracking-widest">Preview Label Format</span>
            </div>
          </button>

          {showPreview && (
            <div className="p-8 md:p-12 border-t border-slate-50 animate-in fade-in slide-in-from-top-4 duration-300">
              <div className="max-w-2xl mx-auto p-10 rounded-3xl bg-slate-50/50 border border-slate-100 shadow-inner">
                <div className="space-y-4">
                  <h2 className="text-2xl md:text-3xl font-black text-slate-800 uppercase tracking-tight leading-none">
                    {formData.department || 'Department Name'}
                  </h2>
                  <h4 className="text-lg font-black text-[#8B0000] uppercase tracking-tight">
                    {formData.opdName || 'OPD Name'}
                  </h4>
                  
                  <div className="flex flex-wrap gap-2 pt-4">
                    <span className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-[10px] font-black text-slate-400 uppercase shadow-sm">
                      {formData.building || 'Building'}
                    </span>
                    <span className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-[10px] font-black text-slate-400 uppercase shadow-sm">
                      {formData.floor || 'Floor'}
                    </span>
                    <span className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-[10px] font-black text-slate-400 uppercase shadow-sm">
                      Room: {formData.roomNo || 'Nos'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #E2E8F0; border-radius: 10px; }
      `}</style>
    </div>
  );
};

export default SpecialitySetup;
