
import React, { useState } from 'react';
import { User as UserIcon, ChevronDown, LogOut, Settings, HelpCircle } from 'lucide-react';
import { PRIMARY_COLOR } from '../constants';
import { User } from '../types';

interface HeaderProps {
  title: string;
  onLogout: () => void;
  hospitalName: string;
  currentUser: User | null;
}

const Header: React.FC<HeaderProps> = ({ title, onLogout, hospitalName, currentUser }) => {
  const [showMenu, setShowMenu] = useState(false);

  return (
    <header className="bg-white border-b border-gray-100 h-16 md:h-20 fixed top-0 right-0 left-0 lg:left-72 z-40 px-3 md:px-8 flex items-center justify-between">
      <div className="flex items-center min-w-0 flex-1 mr-2">
        <h2 className="text-sm md:text-2xl font-black flex items-center tracking-tight truncate">
          <span className="text-[#8B0000] shrink-0">HMIS</span>
          <span className="mx-1.5 md:mx-3 text-gray-200 font-light shrink-0">|</span>
          <span className="text-[#8B0000] uppercase tracking-wide text-[8px] sm:text-[10px] md:text-lg font-bold truncate whitespace-nowrap overflow-hidden">
            {hospitalName}
          </span>
        </h2>
      </div>

      <div className="flex items-center space-x-2 md:space-x-4 relative shrink-0">
        <div 
          onClick={() => setShowMenu(!showMenu)}
          className="flex items-center space-x-1.5 md:space-x-3 bg-white p-1 md:p-1.5 md:pr-4 rounded-full border border-gray-100 cursor-pointer hover:bg-gray-50 transition-all shadow-sm group select-none"
        >
          <div className="w-7 h-7 md:w-10 md:h-10 rounded-full bg-red-50 flex items-center justify-center text-red-800 transition-transform group-hover:scale-95">
            <UserIcon size={14} className="md:w-5 md:h-5" />
          </div>
          <div className="hidden sm:block text-left">
            <div className="text-[10px] md:text-xs font-black text-gray-800 uppercase leading-none">{currentUser?.fullName || 'User'}</div>
            <div className="text-[8px] md:text-[10px] text-gray-400 font-bold mt-1 uppercase tracking-tighter">{currentUser?.role || 'Guest'}</div>
          </div>
          <ChevronDown size={10} className={`text-gray-300 transition-transform ${showMenu ? 'rotate-180' : ''}`} />
        </div>

        {showMenu && (
          <div className="absolute top-full right-0 mt-2 w-48 md:w-56 bg-white rounded-2xl shadow-2xl border border-gray-100 py-2 animate-in fade-in slide-in-from-top-2 duration-200">
            <div className="px-4 py-2 mb-2 border-b border-gray-50">
              <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Active Session</div>
              <div className="text-[10px] md:text-xs font-bold text-gray-800 truncate">{currentUser?.cnic}</div>
            </div>
            <button className="w-full flex items-center px-4 py-2 text-xs font-bold text-gray-600 hover:bg-gray-50 transition-colors">
              <Settings size={14} className="mr-3 text-gray-400" />
              My Profile
            </button>
            <div className="mx-2 my-2 border-t border-gray-50" />
            <button 
              onClick={() => {
                setShowMenu(false);
                onLogout();
              }}
              className="w-full flex items-center px-4 py-2 text-xs font-black text-red-800 hover:bg-red-50 transition-colors"
            >
              <LogOut size={14} className="mr-3" />
              Sign Out
            </button>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
