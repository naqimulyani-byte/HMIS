
import React, { useState, useMemo } from 'react';
import { Bed, Search, Trash2, Edit2, Plus, X, Check, MapPin } from 'lucide-react';

export interface Ward {
  id: string;
  name: string;
  type: 'General' | 'Children' | 'Critical' | 'VIP' | 'Emergency';
  capacity: number;
  floor: string;
}

interface WardSetupProps {
  wards: Ward[];
  setWards: React.Dispatch<React.SetStateAction<Ward[]>>;
}

const WardSetup: React.FC<WardSetupProps> = ({ wards, setWards }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingWardId, setEditingWardId] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: '',
    type: 'General' as Ward['type'],
    capacity: '',
    floor: ''
  });

  const filteredWards = useMemo(() => {
    return wards.filter(w => 
      w.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      w.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
      w.floor.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [wards, searchQuery]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.capacity) return;

    if (editingWardId) {
      setWards(prev => prev.map(w => w.id === editingWardId ? { 
        ...w, 
        name: form.name, 
        type: form.type, 
        capacity: Number(form.capacity), 
        floor: form.floor 
      } : w));
      setEditingWardId(null);
    } else {
      const newWard: Ward = {
        id: Math.random().toString(36).substr(2, 9),
        name: form.name,
        type: form.type,
        capacity: Number(form.capacity),
        floor: form.floor || 'G'
      };
      setWards(prev => [...prev, newWard]);
    }
    setForm({ name: '', type: 'General', capacity: '', floor: '' });
  };

  const handleEdit = (ward: Ward) => {
    setEditingWardId(ward.id);
    setForm({
      name: ward.name,
      type: ward.type,
      capacity: ward.capacity.toString(),
      floor: ward.floor
    });
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Are you sure you want to delete this ward?')) {
      setWards(prev => prev.filter(w => w.id !== id));
      if (editingWardId === id) {
        setEditingWardId(null);
        setForm({ name: '', type: 'General', capacity: '', floor: '' });
      }
    }
  };

  const getBadgeColor = (type: string) => {
    switch (type) {
      case 'Critical': return 'bg-red-50 text-red-700 border-red-100';
      case 'Children': return 'bg-orange-50 text-orange-700 border-orange-100';
      case 'VIP': return 'bg-purple-50 text-purple-700 border-purple-100';
      case 'Emergency': return 'bg-pink-50 text-pink-700 border-pink-100';
      default: return 'bg-slate-50 text-slate-700 border-slate-100';
    }
  };

  return (
    <div className="p-4 md:p-6 max-w-[1600px] mx-auto flex flex-col lg:flex-row gap-6">
      {/* Left Column: Ward List */}
      <div className="flex-1 space-y-4">
        <div className="flex items-center space-x-2">
          <Bed size={20} className="text-[#8B0000]" />
          <h3 className="text-lg font-black text-[#8B0000] uppercase tracking-tight">Wards Setup</h3>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-4 border-b border-slate-50">
            <div className="relative">
              <input 
                type="text" 
                placeholder="Search wards by name, type or floor..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-[#8B0000] outline-none text-sm font-medium transition-all"
              />
              <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-300" />
            </div>
          </div>

          <div className="divide-y divide-slate-50 max-h-[calc(100vh-300px)] overflow-y-auto custom-scrollbar">
            {filteredWards.map((ward) => (
              <div key={ward.id} className="p-5 hover:bg-slate-50/50 transition-colors flex items-center justify-between group">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-3 mb-1">
                    <h4 className="font-black text-slate-800 text-sm uppercase truncate">
                      {ward.name}
                    </h4>
                    <span className={`text-[9px] font-black px-2 py-0.5 rounded border uppercase tracking-wider ${getBadgeColor(ward.type)}`}>
                      {ward.type}
                    </span>
                  </div>
                  <div className="flex items-center space-x-4 text-[11px] font-bold text-slate-400 uppercase tracking-tight">
                    <div className="flex items-center">
                      <Bed size={12} className="mr-1.5 opacity-60" />
                      {ward.capacity} Beds
                    </div>
                    <div className="flex items-center">
                      <MapPin size={12} className="mr-1.5 opacity-60" />
                      {ward.floor} Floor
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button 
                    onClick={() => handleEdit(ward)}
                    className="p-2.5 text-blue-500 hover:bg-blue-50 rounded-xl transition-all active:scale-90"
                    title="Edit Ward"
                  >
                    <Edit2 size={18} />
                  </button>
                  <button 
                    onClick={() => handleDelete(ward.id)}
                    className="p-2.5 text-slate-300 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all active:scale-90"
                    title="Delete Ward"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            ))}
            {filteredWards.length === 0 && (
              <div className="p-16 text-center text-slate-400">
                <Bed size={40} className="mx-auto mb-4 opacity-10" />
                <p className="text-xs font-black uppercase tracking-widest">No wards found</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Right Column: Form */}
      <div className="w-full lg:w-96 shrink-0">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden sticky top-24">
          <div className="p-5 border-b border-slate-100 bg-slate-50/50">
            <h3 className="text-base font-black text-[#8B0000] uppercase tracking-tight">
              {editingWardId ? 'Edit Ward' : 'Add New Ward'}
            </h3>
          </div>
          
          <form onSubmit={handleSubmit} className="p-6 space-y-5">
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Ward Name</label>
              <input 
                type="text" 
                value={form.name}
                onChange={(e) => setForm({...form, name: e.target.value})}
                placeholder="e.g. Male Medical Ward"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner uppercase" 
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Ward Type</label>
              <select 
                value={form.type}
                onChange={(e) => setForm({...form, type: e.target.value as any})}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold bg-white appearance-none"
              >
                <option value="General">General</option>
                <option value="Children">Children</option>
                <option value="Critical">Critical</option>
                <option value="Emergency">Emergency</option>
                <option value="VIP">VIP</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Bed Capacity</label>
                <input 
                  type="number" 
                  value={form.capacity}
                  onChange={(e) => setForm({...form, capacity: e.target.value})}
                  placeholder="0"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner" 
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Floor/Location</label>
                <input 
                  type="text" 
                  value={form.floor}
                  onChange={(e) => setForm({...form, floor: e.target.value})}
                  placeholder="1st"
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner uppercase" 
                />
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              {editingWardId && (
                <button 
                  type="button"
                  onClick={() => { setEditingWardId(null); setForm({ name: '', type: 'General', capacity: '', floor: '' }); }}
                  className="flex-1 py-3.5 rounded-xl border-2 border-slate-100 text-slate-400 font-black text-xs uppercase tracking-widest hover:bg-slate-50 transition-all"
                >
                  Cancel
                </button>
              )}
              <button 
                type="submit"
                className="flex-[2] py-3.5 rounded-xl bg-[#8B0000] text-white font-black text-xs uppercase tracking-widest shadow-xl shadow-red-900/20 active:scale-95 transition-all flex items-center justify-center space-x-3"
              >
                {editingWardId ? <Check size={16} /> : <Plus size={16} />}
                <span>{editingWardId ? 'Update Ward' : 'Add Ward'}</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #E2E8F0; border-radius: 10px; }
      `}</style>
    </div>
  );
};

export default WardSetup;
