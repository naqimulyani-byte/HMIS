
import React, { useState } from 'react';
import { UserPlus, Printer, Edit2, Search, X, Check } from 'lucide-react';
import { PRIMARY_COLOR, SPECIALITIES } from '../constants';
import { HospitalConfig } from '../types';
import { AppPatient } from '../App';

interface RegistrationProps {
  hospitalConfig: HospitalConfig;
  patients: AppPatient[];
  setPatients: React.Dispatch<React.SetStateAction<AppPatient[]>>;
}

const Registration: React.FC<RegistrationProps> = ({ hospitalConfig, patients, setPatients }) => {
  const [formData, setFormData] = useState({
    id: '',
    mrNo: '',
    fullName: '',
    guardianName: '',
    gender: 'Male',
    yy: '0',
    mm: '0',
    dd: '0',
    contact: '',
    cnic: '',
    address: '',
    speciality: SPECIALITIES[0]
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [isEditing, setIsEditing] = useState(false);

  const executeSearch = () => {
    if (!searchQuery.trim()) return;
    
    const term = searchQuery.toLowerCase().trim();
    const patient = patients.find(p => 
      p.mrNo.toLowerCase() === term || 
      p.cnic.toLowerCase() === term || 
      p.name.toLowerCase().includes(term)
    );

    if (patient) {
      populateForm(patient);
    } else {
      alert('Patient not found with MR#, CNIC, or Name: ' + searchQuery);
    }
  };

  const populateForm = (patient: AppPatient) => {
    setFormData({
      id: patient.id,
      mrNo: patient.mrNo,
      fullName: patient.name,
      guardianName: patient.guardianName || '',
      gender: patient.gender as any,
      yy: patient.yy,
      mm: patient.mm,
      dd: patient.dd,
      contact: patient.contact || '',
      cnic: patient.cnic || '',
      address: patient.address || '',
      speciality: patient.speciality || SPECIALITIES[0]
    });
    setIsEditing(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSaveAndPrint = () => {
    if (!formData.fullName) {
      alert('Full Name is required');
      return;
    }

    const mrNo = isEditing ? formData.mrNo : `26${Math.floor(Math.random() * 90000000 + 10000000)}`;
    const newPatient: AppPatient = {
      id: isEditing ? formData.id : Math.random().toString(),
      mrNo,
      name: formData.fullName.toUpperCase(),
      guardianName: formData.guardianName,
      gender: formData.gender,
      yy: formData.yy,
      mm: formData.mm,
      dd: formData.dd,
      contact: formData.contact,
      cnic: formData.cnic,
      address: formData.address,
      speciality: formData.speciality,
      status: 'Waiting'
    };

    if (isEditing) {
      setPatients(patients.map(p => p.id === formData.id ? newPatient : p));
    } else {
      setPatients([newPatient, ...patients]);
    }

    triggerPrescriptionPrint(newPatient);
    handleClear();
  };

  const handleClear = () => {
    setFormData({
      id: '',
      mrNo: '',
      fullName: '',
      guardianName: '',
      gender: 'Male',
      yy: '0',
      mm: '0',
      dd: '0',
      contact: '',
      cnic: '',
      address: '',
      speciality: SPECIALITIES[0]
    });
    setIsEditing(false);
    setSearchQuery('');
  };

  const triggerPrescriptionPrint = (patient: AppPatient) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const getDept = (spec: string) => {
      if (spec.includes('Eye')) return 'Ophthalmology Department';
      if (spec.includes('Medical')) return 'General Medicine Department';
      if (spec.includes('Derma')) return 'Dermatology Department';
      if (spec.includes('Ortho')) return 'Orthopedics Department';
      if (spec.includes('Pediatrics')) return 'Pediatrics Department';
      return 'General OPD Department';
    };

    const now = new Date();
    const formattedDate = now.toLocaleDateString('en-GB') + ' ' + now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });

    const logoHtml = hospitalConfig.logo 
      ? `<img src="${hospitalConfig.logo}" style="width: 60px; height: 60px; object-fit: contain; margin-right: 15px;">`
      : `<div class="logo-placeholder">LOGO</div>`;

    const html = `
      <html>
        <head>
          <title>Prescription Slip - ${patient.mrNo}</title>
          <style>
            @page { size: A4; margin: 10mm; }
            body { font-family: 'Segoe UI', sans-serif; padding: 20px; font-size: 12px; }
            .header { display: flex; justify-content: space-between; border-bottom: 2px solid #000; padding-bottom: 10px; }
            .patient-box { background: #f5f5f5; padding: 15px; margin-top: 20px; border: 1px solid #ddd; }
            .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
            .footer { position: fixed; bottom: 20px; width: 100%; text-align: center; font-size: 10px; color: #888; }
          </style>
        </head>
        <body onload="window.print(); window.close();">
          <div class="header">
            <div>
              <h1 style="margin:0; font-size:18px;">${hospitalConfig.name}</h1>
              <p style="margin:2px 0;">${hospitalConfig.address}</p>
            </div>
            <div style="text-align:right;">
              <h2 style="margin:0; font-size:14px;">${getDept(patient.speciality)}</h2>
              <p style="margin:2px 0;">MR#: ${patient.mrNo}</p>
            </div>
          </div>
          <div class="patient-box">
            <div class="grid">
              <div><strong>Name:</strong> ${patient.name}</div>
              <div><strong>Age/Gender:</strong> ${patient.yy}Y / ${patient.gender}</div>
              <div><strong>Guardian:</strong> ${patient.guardianName}</div>
              <div><strong>Date:</strong> ${formattedDate}</div>
            </div>
          </div>
          <div style="margin-top:40px;">
            <p><strong>Diagnosis:</strong> _________________________________________________</p>
            <p style="font-size:30px; margin:20px 0;">Rx</p>
            <div style="border-bottom:1px dotted #ccc; height:30px; width:100%;"></div>
            <div style="border-bottom:1px dotted #ccc; height:30px; width:100%;"></div>
            <div style="border-bottom:1px dotted #ccc; height:30px; width:100%;"></div>
          </div>
          <div class="footer">Powered by HealthBridge HMIS</div>
        </body>
      </html>
    `;
    printWindow.document.write(html);
    printWindow.document.close();
  };

  return (
    <div className="p-3 md:p-6 max-w-[1600px] mx-auto space-y-4 md:space-y-6 pb-20 lg:pb-6">
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-4 md:p-5 border-b border-slate-100 flex justify-between items-center">
          <h3 className="text-xs md:text-base font-black text-[#8B0000] uppercase tracking-tight flex items-center">
            {isEditing ? 'Update Registration' : 'New Registration'}
          </h3>
          {isEditing && (
            <button onClick={handleClear} className="text-gray-400 hover:text-red-800 transition-colors">
              <X size={18} />
            </button>
          )}
        </div>
        
        <div className="p-4 md:p-6">
          <div className="space-y-4 md:space-y-6">
            <div className="grid grid-cols-12 gap-3 md:gap-4">
              <div className="col-span-12 sm:col-span-6 md:col-span-3">
                <input type="text" placeholder="Full Name" className="w-full px-4 py-2.5 rounded-lg border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold text-slate-700 uppercase" value={formData.fullName} onChange={e => setFormData({...formData, fullName: e.target.value})} />
              </div>
              <div className="col-span-12 sm:col-span-6 md:col-span-3">
                <input type="text" placeholder="Guardian Name" className="w-full px-4 py-2.5 rounded-lg border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-medium text-slate-700" value={formData.guardianName} onChange={e => setFormData({...formData, guardianName: e.target.value})} />
              </div>
              <div className="col-span-12 sm:col-span-6 md:col-span-3 relative">
                <label className="absolute -top-2 left-3 bg-white px-1 text-[10px] font-bold text-slate-400">Gender</label>
                <select className="w-full px-4 py-2.5 rounded-lg border border-slate-200 bg-white text-sm font-medium" value={formData.gender} onChange={e => setFormData({...formData, gender: e.target.value as any})}>
                  <option>Male</option>
                  <option>Female</option>
                </select>
              </div>
              <div className="col-span-12 sm:col-span-6 md:col-span-3 flex gap-2">
                <input type="text" placeholder="YY" className="w-full px-2 py-2.5 rounded-lg border border-slate-200 text-center text-sm font-bold" value={formData.yy} onChange={e => setFormData({...formData, yy: e.target.value})} />
                <input type="text" placeholder="MM" className="w-full px-2 py-2.5 rounded-lg border border-slate-200 text-center text-sm font-bold" value={formData.mm} onChange={e => setFormData({...formData, mm: e.target.value})} />
              </div>
            </div>

            <div className="grid grid-cols-12 gap-3 md:gap-4">
              <div className="col-span-12 sm:col-span-6 md:col-span-3">
                <input type="text" placeholder="Contact" className="w-full px-4 py-2.5 rounded-lg border border-slate-200 text-sm" value={formData.contact} onChange={e => setFormData({...formData, contact: e.target.value})} />
              </div>
              <div className="col-span-12 sm:col-span-6 md:col-span-3">
                <input type="text" placeholder="CNIC" className="w-full px-4 py-2.5 rounded-lg border border-slate-200 text-sm" value={formData.cnic} onChange={e => setFormData({...formData, cnic: e.target.value})} />
              </div>
              <div className="col-span-12 sm:col-span-6 md:col-span-6">
                <input type="text" placeholder="Address" className="w-full px-4 py-2.5 rounded-lg border border-slate-200 text-sm" value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} />
              </div>
            </div>

            <div className="flex flex-col gap-4 pt-4 border-t border-slate-50 mt-2">
              <div className="relative w-full">
                <input type="text" placeholder="Search by MR#, Name or CNIC..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} onKeyDown={e => e.key === 'Enter' && executeSearch()} className="w-full pl-4 pr-10 py-3 rounded-xl border border-slate-200 outline-none text-sm font-medium" />
                <button type="button" onClick={executeSearch} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"><Search size={18} /></button>
              </div>
              <div className="flex flex-row gap-2 w-full">
                <button type="button" onClick={handleClear} className="flex-1 py-3 rounded-xl font-bold text-[#8B0000] border-2 border-[#8B0000] text-xs uppercase">Clear</button>
                <button type="button" onClick={handleSaveAndPrint} className="flex-[2] py-3 rounded-xl font-bold text-white bg-[#8B0000] shadow-lg text-xs uppercase flex items-center justify-center space-x-2">
                  <Printer size={16} /> <span>{isEditing ? 'Update Patient' : 'Save & Print Slip'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50/30 flex justify-between items-center">
           <h4 className="text-[11px] font-black text-slate-500 uppercase tracking-widest">Recent Registrations</h4>
           <span className="text-[10px] font-bold text-slate-400">{patients.length} Registered</span>
        </div>
        <div className="overflow-x-auto">
           <table className="w-full text-left">
              <thead>
                 <tr className="bg-slate-50/50 border-b border-slate-100">
                    <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase">MR No</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase">Patient Name</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase">Guardian</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase">Gender/Age</th>
                    <th className="px-6 py-4 text-[10px] font-black text-slate-500 uppercase text-right">Action</th>
                 </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                 {patients.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50/30 transition-colors">
                       <td className="px-6 py-4 font-bold text-[#8B0000] text-sm">{p.mrNo}</td>
                       <td className="px-6 py-4 font-black text-slate-800 text-sm uppercase">{p.name}</td>
                       <td className="px-6 py-4 text-xs font-medium text-slate-500 uppercase">{p.guardianName}</td>
                       <td className="px-6 py-4 text-xs text-slate-400">{p.gender} / {p.yy}Y</td>
                       <td className="px-6 py-4 text-right">
                          <button onClick={() => populateForm(p)} className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg"><Edit2 size={16} /></button>
                       </td>
                    </tr>
                 ))}
              </tbody>
           </table>
        </div>
      </div>
    </div>
  );
};

export default Registration;
