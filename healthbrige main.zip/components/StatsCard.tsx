
import React from 'react';

interface StatsCardProps {
  title: string;
  count: number;
  gross: number;
  disc: number;
  refund: number;
  net: number;
  colorClass: string;
  badgeClass: string;
}

const StatsCard: React.FC<StatsCardProps> = ({ 
  title, 
  count, 
  gross, 
  disc, 
  refund, 
  net, 
  colorClass, 
  badgeClass 
}) => {
  return (
    <div className={`bg-white border-l-4 rounded-lg shadow-sm p-3 ${colorClass} transition-transform hover:scale-[1.02] cursor-default`}>
      <div className="flex justify-between items-start mb-2">
        <h4 className="text-xs font-bold text-gray-700 truncate">{title}</h4>
        <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${badgeClass}`}>
          {count}
        </span>
      </div>
      <div className="grid grid-cols-2 gap-y-1 text-[10px]">
        <div className="text-gray-500">Gross</div>
        <div className="text-right font-medium text-gray-800">{gross.toLocaleString()}</div>
        
        <div className="text-gray-500">Disc.</div>
        <div className="text-right font-medium text-gray-800">{disc.toLocaleString()}</div>
        
        <div className="text-gray-500">Refund</div>
        <div className="text-right font-medium text-red-500">-{refund.toLocaleString()}</div>
        
        <div className="col-span-2 border-t border-gray-100 my-1 pt-1 flex justify-between">
          <span className="font-bold text-gray-600">NET</span>
          <span className="font-bold text-red-800">{net.toLocaleString()}</span>
        </div>
      </div>
    </div>
  );
};

export default StatsCard;
