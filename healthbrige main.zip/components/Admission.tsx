
import React, { useState } from 'react';
import { Bed, Search, Calendar, X, Check, LogOut, Eye, Trash2, UserCheck } from 'lucide-react';
import { PRIMARY_COLOR } from '../constants';
import { AppPatient } from '../App';

interface AdmittedPatient {
  id: string;
  patientId: string;
  mrNo: string;
  name: string;
  ward: string;
  bedNo: string;
  doctor: string;
  admissionDate: string;
  status: 'Admitted' | 'Discharged';
  gender: string;
  age: string;
  diagnosis?: string;
}

interface AdmissionProps {
  patients: AppPatient[];
}

const Admission: React.FC<AdmissionProps> = ({ patients }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [hasSearched, setHasSearched] = useState(false);
  const [searchResults, setSearchResults] = useState<AppPatient[]>([]);
  const [showAdmissionModal, setShowAdmissionModal] = useState(false);
  const [showDischargeModal, setShowDischargeModal] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<AppPatient | AdmittedPatient | null>(null);
  const [statusFilter, setStatusFilter] = useState('All');

  const [admittedPatients, setAdmittedPatients] = useState<AdmittedPatient[]>([
    { id: 'a1', patientId: '2', mrNo: '2601010002', name: 'SAIF ULLAH', ward: 'General Ward (Male)', bedNo: 'B-102', doctor: 'DR. AHMAD KHAN', admissionDate: '01/02/2026 10:30 AM', status: 'Admitted', gender: 'Male', age: '25 Years', diagnosis: 'Acute Appendicitis' },
  ]);

  const [admissionForm, setAdmissionForm] = useState({ ward: 'General Ward (Male)', bedNo: '', doctor: '', diagnosis: '' });
  const [dischargeForm, setDischargeForm] = useState({ finalDiagnosis: '' });

  const handleSearch = () => {
    if (!searchQuery.trim()) return;
    setHasSearched(true);
    // SEARCH IN GLOBAL PATIENTS LIST
    const results = patients.filter(p => 
      p.mrNo.includes(searchQuery) || 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.cnic.includes(searchQuery)
    );
    setSearchResults(results);
  };

  const openAdmission = (patient: AppPatient) => {
    setSelectedPatient(patient);
    setShowAdmissionModal(true);
  };

  const handleFinalizeAdmission = () => {
    if (!selectedPatient) return;
    const now = new Date();
    const formattedDate = now.toLocaleDateString('en-GB') + ' ' + now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: true });
    
    const newAdmission: AdmittedPatient = { 
      id: Math.random().toString(36).substr(2, 9), 
      patientId: selectedPatient.id, 
      mrNo: selectedPatient.mrNo, 
      name: 'name' in selectedPatient ? selectedPatient.name : '', 
      ward: admissionForm.ward, 
      bedNo: admissionForm.bedNo || 'TBD', 
      doctor: admissionForm.doctor || 'Unassigned', 
      admissionDate: formattedDate, 
      status: 'Admitted', 
      gender: 'gender' in selectedPatient ? selectedPatient.gender : '', 
      age: 'yy' in selectedPatient ? `${selectedPatient.yy} Years` : '', 
      diagnosis: admissionForm.diagnosis 
    };

    setAdmittedPatients([newAdmission, ...admittedPatients]);
    setShowAdmissionModal(false);
    setHasSearched(false);
    setSearchQuery('');
  };

  const handleOpenDischarge = (patient: AdmittedPatient) => {
    setSelectedPatient(patient);
    setDischargeForm({ finalDiagnosis: patient.diagnosis || '' });
    setShowDischargeModal(true);
  };

  const handleFinalizeDischarge = () => {
    if (!selectedPatient) return;
    setAdmittedPatients(prev => prev.map(p => p.id === selectedPatient.id ? { ...p, status: 'Discharged' as const, diagnosis: dischargeForm.finalDiagnosis } : p));
    setShowDischargeModal(false);
  };

  const filteredAdmissions = admittedPatients.filter(p => {
    if (statusFilter === 'All') return true;
    if (statusFilter === 'Active Admissions') return p.status === 'Admitted';
    if (statusFilter === 'Discharged Patients') return p.status === 'Discharged';
    return true;
  });

  return (
    <div className="p-4 md:p-6 max-w-[1600px] mx-auto space-y-4 md:space-y-6 pb-24 md:pb-6">
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center">
            <Bed size={22} className="text-[#8B0000] mr-3" />
            <h3 className="text-lg font-black text-[#8B0000] uppercase tracking-tight">Ward Admission</h3>
          </div>
        </div>
        
        <div className="p-5 bg-slate-50/30">
          <div className="flex flex-wrap items-center gap-4">
            <div className="relative flex-1 min-w-[300px]">
              <input type="text" placeholder="Find Registered Patient to Admit (Name, MR# or CNIC)..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSearch()} className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm shadow-sm" />
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            </div>
            <button onClick={handleSearch} className="px-8 py-2.5 rounded-xl bg-[#8B0000] text-white font-black text-xs uppercase tracking-widest active:scale-95 transition-all">SEARCH</button>
            {hasSearched && <button onClick={() => {setHasSearched(false); setSearchQuery('');}} className="p-2.5 rounded-xl bg-slate-100 text-slate-500"><X size={18} /></button>}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        {hasSearched ? (
          <div className="p-6">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Registration Search Results ({searchResults.length})</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {searchResults.map(p => (
                <div key={p.id} className="bg-white border border-slate-100 rounded-2xl p-5 flex justify-between items-center group hover:border-[#8B0000] transition-all">
                  <div>
                    <div className="text-[10px] font-black text-[#8B0000] uppercase">{p.mrNo}</div>
                    <h5 className="font-black text-slate-800 uppercase leading-none mt-1">{p.name}</h5>
                    <div className="text-[9px] font-bold text-slate-400 uppercase mt-1">{p.gender} • {p.yy}Y</div>
                  </div>
                  <button onClick={() => openAdmission(p)} className="p-2.5 bg-red-50 text-[#8B0000] rounded-xl hover:bg-[#8B0000] hover:text-white transition-all"><UserCheck size={20} /></button>
                </div>
              ))}
              {searchResults.length === 0 && <div className="col-span-full py-10 text-center text-slate-300 uppercase font-black text-xs">No registered patients found matching "{searchQuery}"</div>}
            </div>
          </div>
        ) : (
          <>
            <div className="p-5 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
              <h4 className="text-[11px] font-black text-slate-500 uppercase tracking-widest">Active Ward Admissions</h4>
              <select className="bg-white border border-slate-200 rounded-lg px-3 py-1.5 text-[10px] font-black uppercase" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                <option>All</option>
                <option>Active Admissions</option>
                <option>Discharged Patients</option>
              </select>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50/50 border-b border-slate-100 text-[10px] font-black text-slate-400 uppercase">
                    <th className="px-6 py-4">MR No</th>
                    <th className="px-6 py-4">Patient Details</th>
                    <th className="px-6 py-4">Ward/Bed</th>
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {filteredAdmissions.map(adm => (
                    <tr key={adm.id} className="hover:bg-slate-50/30">
                      <td className="px-6 py-4 font-bold text-[#8B0000] text-sm">{adm.mrNo}</td>
                      <td className="px-6 py-4">
                        <div className="font-black text-slate-800 text-xs uppercase">{adm.name}</div>
                        <div className="text-[9px] text-slate-400 uppercase">{adm.gender} • {adm.age}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-xs font-bold text-slate-700">{adm.ward}</div>
                        <div className="text-[9px] font-black text-[#8B0000]">BED: {adm.bedNo}</div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`text-[8px] font-black px-2 py-1 rounded uppercase ${adm.status === 'Admitted' ? 'bg-green-50 text-green-600' : 'bg-slate-100 text-slate-400'}`}>{adm.status}</span>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end space-x-2">
                           <button onClick={() => handleOpenDischarge(adm)} className="p-2 text-orange-600 hover:bg-orange-50 rounded-lg"><LogOut size={16} /></button>
                           <button className="p-2 text-slate-300 hover:text-red-600 rounded-lg"><Trash2 size={16} /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      {/* Admission Modal */}
      {showAdmissionModal && selectedPatient && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-xl overflow-hidden animate-in zoom-in duration-200">
            <div className="bg-[#8B0000] p-4 flex justify-between items-center text-white">
              <h4 className="font-black text-base uppercase">Admit to Ward</h4>
              <button onClick={() => setShowAdmissionModal(false)}><X size={24} /></button>
            </div>
            <div className="p-6 space-y-4">
              <div className="bg-red-50 p-4 rounded-xl">
                 <div className="text-[10px] font-black text-red-800 uppercase">MR# {selectedPatient.mrNo}</div>
                 <div className="text-lg font-black text-slate-800 uppercase">{'name' in selectedPatient ? selectedPatient.name : ''}</div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1"><label className="text-[10px] font-black text-slate-400 uppercase">Select Ward</label><select className="w-full p-2.5 rounded-lg border border-slate-200 text-sm font-bold" value={admissionForm.ward} onChange={e => setAdmissionForm({...admissionForm, ward: e.target.value})}><option>General Ward (Male)</option><option>General Ward (Female)</option><option>Emergency ICU</option></select></div>
                <div className="space-y-1"><label className="text-[10px] font-black text-slate-400 uppercase">Bed No</label><input type="text" className="w-full p-2.5 rounded-lg border border-slate-200 text-sm font-bold" value={admissionForm.bedNo} onChange={e => setAdmissionForm({...admissionForm, bedNo: e.target.value})} placeholder="e.g. B-01" /></div>
              </div>
              <div className="space-y-1"><label className="text-[10px] font-black text-slate-400 uppercase">Doctor</label><input type="text" className="w-full p-2.5 rounded-lg border border-slate-200 text-sm font-bold" value={admissionForm.doctor} onChange={e => setAdmissionForm({...admissionForm, doctor: e.target.value})} placeholder="Consultant Name" /></div>
              <button onClick={handleFinalizeAdmission} className="w-full py-4 bg-[#8B0000] text-white font-black uppercase text-xs tracking-widest rounded-xl shadow-lg active:scale-95 transition-all mt-4">Confirm Admission</button>
            </div>
          </div>
        </div>
      )}

      {/* Discharge Modal */}
      {showDischargeModal && selectedPatient && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-xl overflow-hidden animate-in zoom-in duration-200 border-t-8 border-orange-500">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
               <h4 className="font-black text-orange-600 text-base uppercase">Process Discharge</h4>
               <button onClick={() => setShowDischargeModal(false)} className="text-slate-300"><X size={24} /></button>
            </div>
            <div className="p-8 space-y-6">
               <div className="space-y-1.5"><label className="text-[10px] font-black text-slate-400 uppercase">Final Diagnosis *</label><textarea rows={3} value={dischargeForm.finalDiagnosis} onChange={e => setDischargeForm({...dischargeForm, finalDiagnosis: e.target.value})} className="w-full p-4 rounded-2xl border border-slate-200 outline-none text-sm font-bold focus:border-orange-500 shadow-inner resize-none" placeholder="Enter patient diagnosis summary..." /></div>
               <button onClick={handleFinalizeDischarge} disabled={!dischargeForm.finalDiagnosis} className="w-full py-5 bg-orange-600 text-white font-black uppercase text-xs tracking-widest rounded-2xl shadow-xl active:scale-95 transition-all disabled:opacity-50">Confirm Patient Discharge</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Admission;
