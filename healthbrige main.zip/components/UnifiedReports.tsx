
import React, { useState, useMemo } from 'react';
import { 
  FileText, Search, Calendar, Filter, Download, Printer, 
  Beaker, Scan, Stethoscope, Bed, RotateCcw, 
  BarChart3, PieChart, ChevronRight, X, ChevronDown, LayoutGrid
} from 'lucide-react';
import { PRIMARY_COLOR } from '../constants';

type ReportType = 'lab' | 'radiology' | 'procedure' | 'admission' | 'refund' | 'lab-stat' | 'rad-stat';

interface ReportRecord {
  id: string;
  receiptNo: string;
  date: string;
  mrNo: string;
  patientName: string;
  itemName: string;
  fee: number;
  paymentStatus: string;
  refunded: string;
}

const UnifiedReports: React.FC = () => {
  const [activeReport, setActiveReport] = useState<ReportType>('lab');
  const [fromDate, setFromDate] = useState('2026-01-11');
  const [toDate, setToDate] = useState('2026-01-11');
  const [searchQuery, setSearchQuery] = useState('');
  const [isFiltered, setIsFiltered] = useState(false);
  const [showMobileCategories, setShowMobileCategories] = useState(false);

  // Mock data for different reports
  const mockData: Record<string, ReportRecord[]> = {
    lab: [
      { id: '1', receiptNo: 'LR2601110001', date: '11/01/2026', mrNo: '2601010003', patientName: 'HAROON', itemName: 'CBC, LFT, Blood Glucose', fee: 2050, paymentStatus: 'Paid', refunded: '-' },
      { id: '2', receiptNo: 'LR2601110002', date: '11/01/2026', mrNo: '2601010002', patientName: 'SAIF ULLAH', itemName: 'Lipid Profile', fee: 1200, paymentStatus: 'Paid', refunded: '-' },
    ],
    radiology: [
      { id: '3', receiptNo: 'RR2601110001', date: '11/01/2026', mrNo: '2601010002', patientName: 'SAIF ULLAH', itemName: 'X-Ray Chest PA', fee: 800, paymentStatus: 'Paid', refunded: '-' },
    ],
    procedure: [
      { id: '4', receiptNo: 'PR2601110001', date: '11/01/2026', mrNo: '2601010003', patientName: 'HAROON', itemName: 'Minor Dressing', fee: 300, paymentStatus: 'Paid', refunded: '-' },
    ],
    admission: [
      { id: '5', receiptNo: 'ADM260111001', date: '11/01/2026', mrNo: '2601010001', patientName: 'SAJJAAD', itemName: 'Gen. Ward Admission', fee: 500, paymentStatus: 'Paid', refunded: '-' },
    ],
    refund: [
      { id: '6', receiptNo: 'RF2601110001', date: '11/01/2026', mrNo: '2601010003', patientName: 'HAROON', itemName: 'CBC Refund', fee: 700, paymentStatus: 'Refunded', refunded: 'Yes' },
    ],
  };

  const categories = [
    { id: 'lab', label: 'Lab Reports', icon: <Beaker size={18} />, group: 'FINANCIAL' },
    { id: 'radiology', label: 'Radiology Reports', icon: <Scan size={18} />, group: 'FINANCIAL' },
    { id: 'procedure', label: 'Procedure Reports', icon: <Stethoscope size={18} />, group: 'FINANCIAL' },
    { id: 'admission', label: 'Admission Reports', icon: <Bed size={18} />, group: 'FINANCIAL' },
    { id: 'refund', label: 'Refund Reports', icon: <RotateCcw size={18} />, group: 'FINANCIAL' },
    { id: 'lab-stat', label: 'Lab Statistics', icon: <BarChart3 size={18} />, group: 'STATISTICAL' },
    { id: 'rad-stat', label: 'Radiology Statistics', icon: <PieChart size={18} />, group: 'STATISTICAL' },
  ];

  const handleFilter = () => {
    setIsFiltered(true);
  };

  const filteredData = useMemo(() => {
    if (!isFiltered) return [];
    return mockData[activeReport]?.filter(item => 
      item.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.mrNo.includes(searchQuery) ||
      item.receiptNo.includes(searchQuery)
    ) || [];
  }, [activeReport, searchQuery, isFiltered]);

  const stats = useMemo(() => {
    const gross = filteredData.reduce((acc, curr) => acc + curr.fee, 0);
    return { gross, net: gross };
  }, [filteredData]);

  const handleExportCSV = () => {
    if (filteredData.length === 0) return;
    const headers = ["Receipt #", "Date", "MR #", "Patient Name", "Item Name", "Fee", "Status", "Refunded"];
    const rows = filteredData.map(item => [item.receiptNo, item.date, item.mrNo, item.patientName, item.itemName.replace(/,/g, '|'), item.fee, item.paymentStatus, item.refunded]);
    const csvContent = [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `${activeReport}_report.csv`);
    link.click();
  };

  const handlePrintReport = () => {
    if (filteredData.length === 0) return;
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    const reportName = categories.find(c => c.id === activeReport)?.label || 'Report';
    const html = `<html><head><title>${reportName}</title><style>@page { size: A4 landscape; margin: 10mm; } body { font-family: sans-serif; padding: 20px; font-size: 10px; } table { width: 100%; border-collapse: collapse; margin-top: 20px; } th, td { border: 1px solid #ddd; padding: 8px; text-align: left; } th { background: #f8f8f8; }</style></head><body onload="window.print();"><h1>${reportName}</h1><table><thead><tr><th>Receipt #</th><th>Date</th><th>MR #</th><th>Patient</th><th>Items</th><th>Fee</th></tr></thead><tbody>${filteredData.map(i => `<tr><td>${i.receiptNo}</td><td>${i.date}</td><td>${i.mrNo}</td><td>${i.patientName}</td><td>${i.itemName}</td><td>${i.fee}</td></tr>`).join('')}</tbody></table></body></html>`;
    printWindow.document.write(html);
    printWindow.document.close();
  };

  const activeCategory = categories.find(c => c.id === activeReport);

  return (
    <div className="p-3 md:p-6 max-w-[1600px] mx-auto flex flex-col lg:flex-row gap-4 md:gap-6 h-[calc(100vh-80px)] md:h-[calc(100vh-120px)] overflow-hidden">
      
      {/* Sidebar: Mobile Header Trigger */}
      <div className="lg:hidden shrink-0">
        <button 
          onClick={() => setShowMobileCategories(!showMobileCategories)}
          className="w-full bg-white border border-slate-200 p-4 rounded-2xl flex items-center justify-between shadow-sm active:bg-slate-50 transition-all"
        >
          <div className="flex items-center space-x-3">
             <div className="w-10 h-10 bg-red-50 rounded-xl flex items-center justify-center text-[#8B0000]">
                {activeCategory?.icon}
             </div>
             <div className="text-left">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block leading-none mb-1">Select Report Type</span>
                <span className="text-sm font-black text-slate-800 uppercase">{activeCategory?.label}</span>
             </div>
          </div>
          <ChevronDown className={`text-slate-400 transition-transform ${showMobileCategories ? 'rotate-180' : ''}`} />
        </button>

        {showMobileCategories && (
          <div className="mt-2 bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden animate-in slide-in-from-top-2 duration-200 z-[60] absolute left-4 right-4 max-h-[60vh] overflow-y-auto custom-scrollbar">
             {['FINANCIAL', 'STATISTICAL'].map(group => (
               <div key={group} className="p-2">
                 <h4 className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] px-3 py-2">{group} REPORTS</h4>
                 {categories.filter(c => c.group === group).map(cat => (
                   <button
                     key={cat.id}
                     onClick={() => {
                       setActiveReport(cat.id as ReportType);
                       setShowMobileCategories(false);
                       setIsFiltered(false);
                     }}
                     className={`w-full flex items-center space-x-3 p-3 rounded-xl transition-all ${
                       activeReport === cat.id ? 'bg-[#8B0000] text-white' : 'text-slate-600 hover:bg-slate-50'
                     }`}
                   >
                     <div className={activeReport === cat.id ? 'text-white' : 'text-slate-400'}>{cat.icon}</div>
                     <span className="text-xs font-black uppercase">{cat.label}</span>
                   </button>
                 ))}
               </div>
             ))}
          </div>
        )}
      </div>

      {/* Desktop Sidebar: Report Categories */}
      <div className="hidden lg:flex w-80 shrink-0 flex-col space-y-4">
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-full">
          <div className="p-5 border-b border-slate-100 flex items-center">
            <FileText size={18} className="text-[#8B0000] mr-2" />
            <h3 className="text-sm font-black text-[#8B0000] uppercase tracking-tight">Report Categories</h3>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar">
            {['FINANCIAL', 'STATISTICAL'].map(group => (
              <div key={group} className="space-y-2">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-2">{group} REPORTS</h4>
                <div className="space-y-1">
                  {categories.filter(c => c.group === group).map(cat => (
                    <button
                      key={cat.id}
                      onClick={() => {
                        setActiveReport(cat.id as ReportType);
                        setIsFiltered(false);
                      }}
                      className={`w-full flex items-center justify-between p-3.5 rounded-2xl transition-all group ${
                        activeReport === cat.id ? 'bg-[#8B0000] text-white shadow-lg' : 'text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <div className={activeReport === cat.id ? 'text-white' : 'text-slate-400'}>{cat.icon}</div>
                        <span className="text-[13px] font-black uppercase">{cat.label}</span>
                      </div>
                      <ChevronRight size={14} className={activeReport === cat.id ? 'text-white/50' : 'text-slate-300'} />
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Report Area */}
      <div className="flex-1 flex flex-col h-full min-w-0">
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 flex flex-col h-full overflow-hidden relative">
          
          {/* Header & Main Filters */}
          <div className="p-4 md:p-6 border-b border-slate-100 space-y-4 md:space-y-6 shrink-0">
            <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
              <div className="flex items-center space-x-3 md:space-x-4">
                <div className="w-10 h-10 md:w-12 md:h-12 bg-red-50 rounded-2xl flex items-center justify-center text-[#8B0000] border border-red-100">
                  {activeCategory?.icon}
                </div>
                <div>
                  <h2 className="text-lg md:text-2xl font-black text-slate-800 uppercase tracking-tight leading-none">
                    {activeCategory?.label}
                  </h2>
                  <p className="text-[9px] md:text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">
                    Activity for {fromDate.split('-').reverse().join('/')} — {toDate.split('-').reverse().join('/')}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2 w-full sm:w-auto">
                 <button onClick={handlePrintReport} className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl border border-slate-200 text-slate-500 font-black text-[10px] uppercase tracking-widest hover:bg-slate-50 flex items-center justify-center space-x-2">
                   <Printer size={14} /> <span className="hidden sm:inline">Print</span><span className="sm:hidden">Print</span>
                 </button>
                 <button onClick={handleExportCSV} className="flex-1 sm:flex-none px-4 py-2.5 rounded-xl bg-[#8B0000] text-white font-black text-[10px] uppercase tracking-widest shadow-xl flex items-center justify-center space-x-2">
                   <Download size={14} /> <span className="hidden sm:inline">Export CSV</span><span className="sm:hidden">CSV</span>
                 </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end bg-slate-50/50 p-4 md:p-5 rounded-[1.5rem] md:rounded-[2rem] border border-slate-100">
              <div className="md:col-span-3 space-y-1">
                <label className="text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">From Date</label>
                <input 
                  type="date" value={fromDate} onChange={(e) => {setFromDate(e.target.value); setIsFiltered(false);}}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs md:text-sm font-bold bg-white" 
                />
              </div>
              <div className="md:col-span-3 space-y-1">
                <label className="text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">To Date</label>
                <input 
                  type="date" value={toDate} onChange={(e) => {setToDate(e.target.value); setIsFiltered(false);}}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs md:text-sm font-bold bg-white" 
                />
              </div>
              <div className="md:col-span-4 space-y-1">
                <label className="text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Search Anything</label>
                <input 
                  type="text" placeholder="Patient Name, MR#, Receipt#..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-xs md:text-sm font-medium bg-white" 
                />
              </div>
              <div className="md:col-span-2">
                <button 
                  onClick={handleFilter}
                  className="w-full py-2.5 md:py-3.5 rounded-xl bg-[#8B0000] text-white font-black text-[10px] uppercase tracking-widest shadow-lg flex items-center justify-center space-x-2 active:scale-95 transition-all"
                >
                  <Filter size={14} />
                  <span>Filter</span>
                </button>
              </div>
            </div>
          </div>

          {/* Report Content Table */}
          <div className="flex-1 overflow-x-auto overflow-y-auto custom-scrollbar">
            {isFiltered ? (
              <table className="w-full text-left min-w-[800px]">
                <thead className="sticky top-0 bg-white z-10">
                  <tr className="border-b border-slate-100 text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    <th className="px-6 py-4">Receipt #</th>
                    <th className="px-6 py-4">Date</th>
                    <th className="px-6 py-4">MR #</th>
                    <th className="px-6 py-4">Patient</th>
                    <th className="px-6 py-4">Item Name</th>
                    <th className="px-6 py-4 text-right">Fee</th>
                    <th className="px-6 py-4 text-center">Payment</th>
                    <th className="px-6 py-4 text-center">Ref.</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {filteredData.map((row) => (
                    <tr key={row.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4 font-black text-[#8B0000] text-xs tracking-tighter">{row.receiptNo}</td>
                      <td className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase">{row.date}</td>
                      <td className="px-6 py-4 text-[10px] font-black text-slate-800">{row.mrNo}</td>
                      <td className="px-6 py-4 font-black text-slate-800 text-xs uppercase">{row.patientName}</td>
                      <td className="px-6 py-4 text-[10px] font-bold text-slate-600 uppercase truncate max-w-[200px]">{row.itemName}</td>
                      <td className="px-6 py-4 text-right font-black text-slate-800 text-xs">Rs. {row.fee.toLocaleString()}</td>
                      <td className="px-6 py-4 text-center">
                        <span className={`text-[8px] font-black px-2 py-0.5 rounded uppercase tracking-wider ${row.paymentStatus === 'Paid' || row.paymentStatus === 'Completed' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>
                          {row.paymentStatus}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-center text-[10px] font-bold text-slate-400">{row.refunded}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-10 space-y-4">
                <div className="w-16 h-16 md:w-24 md:h-24 bg-slate-50 rounded-full flex items-center justify-center text-slate-200 border border-slate-100">
                  <Filter size={32} />
                </div>
                <div>
                  <h4 className="text-lg md:text-xl font-black text-slate-800 uppercase tracking-tight">Generate Report</h4>
                  <p className="text-slate-400 font-medium mt-1 max-w-xs mx-auto text-xs md:text-sm uppercase tracking-tight">Select range & click filter</p>
                </div>
              </div>
            )}
          </div>

          {/* Footer Stats - Mobile Stacked */}
          <div className="p-4 md:p-6 bg-slate-50 border-t border-slate-100 shrink-0 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-[9px] md:text-[10px] font-black text-slate-400 uppercase tracking-widest text-center sm:text-left">
              Showing <span className="text-slate-800">{filteredData.length}</span> records for the period.
            </div>
            
            <div className="flex items-center space-x-6 md:space-x-12 w-full sm:w-auto justify-around sm:justify-end">
               <div className="text-right">
                  <span className="text-[8px] md:text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-1">Gross</span>
                  <span className="text-lg md:text-2xl font-black text-slate-800 leading-none">{stats.gross.toLocaleString()}</span>
               </div>
               <div className="text-right border-l border-slate-200 pl-6 md:pl-12">
                  <span className="text-[8px] md:text-[9px] font-black text-[#8B0000] uppercase tracking-widest block mb-1">Net</span>
                  <span className="text-lg md:text-2xl font-black text-[#8B0000] leading-none">{stats.net.toLocaleString()}</span>
               </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #E2E8F0; border-radius: 10px; }
      `}</style>
    </div>
  );
};

export default UnifiedReports;
