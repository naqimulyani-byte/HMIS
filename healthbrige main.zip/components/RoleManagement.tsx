
import React, { useState } from 'react';
import { Shield, Plus, Check, ShieldCheck, X } from 'lucide-react';
import { PRIMARY_COLOR } from '../constants';
import { Role } from '../types';

interface Permission {
  id: string;
  label: string;
  category: string;
}

interface RoleManagementProps {
  roles: Role[];
  setRoles: React.Dispatch<React.SetStateAction<Role[]>>;
}

const RoleManagement: React.FC<RoleManagementProps> = ({ roles, setRoles }) => {
  const [selectedRoleId, setSelectedRoleId] = useState<string | null>(roles[0]?.id || null);
  const [isAddingRole, setIsAddingRole] = useState(false);
  const [newRoleName, setNewRoleName] = useState('');
  const [newRoleDesc, setNewRoleDesc] = useState('');

  const permissionsList: Permission[] = [
    { id: 'ref_reports', label: 'Refund Reports', category: 'ADMIN' },
    { id: 'role_mgmt', label: 'Role & Permission Management', category: 'ADMIN' },
    { id: 'audit_logs', label: 'System Audit Logs', category: 'ADMIN' },
    { id: 'user_mgmt', label: 'User Management', category: 'ADMIN' },
    { id: 'lab_rep_view', label: 'Lab Reports View', category: 'CLINICAL' },
    { id: 'lab_res_entry', label: 'Lab Results Entry', category: 'CLINICAL' },
    { id: 'hosp_settings', label: 'Hospital Settings', category: 'CONFIGURATION' },
    { id: 'lab_setup', label: 'Lab Service Setup', category: 'CONFIGURATION' },
    { id: 'panel_setup', label: 'Panel Setup', category: 'CONFIGURATION' },
    { id: 'proc_setup', label: 'Procedure Setup', category: 'CONFIGURATION' },
    { id: 'rad_setup', label: 'Radiology Service Setup', category: 'CONFIGURATION' },
    { id: 'spec_setup', label: 'Speciality Setup', category: 'CONFIGURATION' },
    { id: 'ward_setup', label: 'Ward Setup', category: 'CONFIGURATION' },
    { id: 'proc_refunds', label: 'Process Refunds', category: 'COUNTER' },
    { id: 'view_dash', label: 'View Dashboard', category: 'GENERAL' },
    { id: 'lab_counter', label: 'Lab Counter', category: 'RECEPTION' },
    { id: 'pt_adm', label: 'Patient Admission', category: 'RECEPTION' },
    { id: 'pt_reg', label: 'Patient Registration', category: 'RECEPTION' },
    { id: 'proc_counter', label: 'Procedure Counter', category: 'RECEPTION' },
    { id: 'rad_counter', label: 'Radiology Counter', category: 'RECEPTION' },
    { id: 'uni_reports', label: 'Unified Reports', category: 'REPORTS' },
  ];

  const categories = Array.from(new Set(permissionsList.map(p => p.category)));

  const handleCreateRole = () => {
    if (!newRoleName) return;
    const newRole: Role = { id: Date.now().toString(), name: newRoleName, description: newRoleDesc.toUpperCase() || 'CUSTOM ROLE', permissions: [] };
    setRoles([...roles, newRole]);
    setSelectedRoleId(newRole.id);
    setIsAddingRole(false);
    setNewRoleName('');
    setNewRoleDesc('');
  };

  const togglePermission = (roleId: string, permissionId: string) => {
    setRoles(prevRoles => prevRoles.map(role => {
      if (role.id === roleId) {
        const hasPermission = role.permissions.includes(permissionId);
        return { ...role, permissions: hasPermission ? role.permissions.filter(p => p !== permissionId) : [...role.permissions, permissionId] };
      }
      return role;
    }));
  };

  const selectedRole = roles.find(r => r.id === selectedRoleId);

  return (
    <div className="p-6 max-w-[1600px] mx-auto h-[calc(100vh-100px)] flex flex-col space-y-4">
      <div className="flex gap-6 h-full overflow-hidden">
        <div className="w-80 flex flex-col space-y-4 shrink-0">
          <div className="bg-white rounded-3xl shadow-[0_4px_20px_rgb(0,0,0,0.03)] border border-slate-200/60 flex flex-col h-full overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center"><Shield size={18} className="text-[#8B0000] mr-2" /><h4 className="text-[13px] font-black text-[#8B0000] uppercase tracking-wider">System Roles</h4></div>
            <div className="p-4 space-y-4 flex-1 overflow-y-auto">
              <button onClick={() => setIsAddingRole(true)} className="w-full py-3 rounded-2xl bg-white border-2 border-[#8B0000] text-[#8B0000] font-black text-[11px] hover:bg-red-50 transition-all flex items-center justify-center space-x-2 active:scale-[0.98] mb-4 uppercase tracking-widest shadow-lg shadow-red-900/5">
                <Plus size={16} />
                <span>Create New Role</span>
              </button>
              <div className="space-y-3">
                {roles.map(role => (
                  <button key={role.id} onClick={() => setSelectedRoleId(role.id)} className={`w-full text-left p-5 rounded-2xl border-2 transition-all duration-300 relative group ${selectedRoleId === role.id ? 'border-[#8B0000] bg-white shadow-lg' : 'border-transparent bg-slate-50/50 hover:bg-white hover:border-slate-200'}`}>
                    <div className="flex flex-col"><span className={`font-black text-base tracking-tight ${selectedRoleId === role.id ? 'text-[#8B0000]' : 'text-slate-800'}`}>{role.name}</span><span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">{role.description}</span></div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="flex-1 min-w-0">
          <div className="bg-white rounded-3xl shadow-[0_4px_20px_rgb(0,0,0,0.03)] border border-slate-200/60 h-full flex flex-col overflow-hidden relative">
            <div className="p-5 border-b border-slate-100 flex items-center"><ShieldCheck size={18} className="text-[#8B0000] mr-2" /><h4 className="text-[13px] font-black text-[#8B0000] uppercase tracking-wider">Role Permissions</h4></div>
            <div className="flex-1 overflow-y-auto p-10 bg-white pb-32">
              {selectedRole && (
                <div className="max-w-4xl space-y-12">
                  {categories.map(category => (
                    <div key={category} className="space-y-6">
                      <h5 className="text-[12px] font-black text-[#8B0000] uppercase tracking-[0.2em]">{category}</h5>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-5 pl-2">
                        {permissionsList.filter(p => p.category === category).map(permission => {
                          const isChecked = selectedRole.permissions.includes(permission.id);
                          return (
                            <label key={permission.id} className="group flex items-center cursor-pointer select-none" onClick={() => togglePermission(selectedRole.id, permission.id)}>
                              <div className={`w-7 h-7 rounded-lg flex items-center justify-center border-2 transition-all mr-4 shadow-sm ${isChecked ? 'bg-[#8B0000] border-[#8B0000]' : 'bg-white border-slate-200 group-hover:border-[#8B0000]/30'}`}>{isChecked && <Check size={16} className="text-white stroke-[3px]" />}</div>
                              <span className={`text-[14px] transition-colors ${isChecked ? 'font-bold text-slate-900' : 'font-medium text-slate-500 group-hover:text-slate-800'}`}>{permission.label}</span>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {selectedRole && (
              <div className="absolute bottom-0 right-0 left-0 p-8 flex justify-end pointer-events-none">
                <button className="pointer-events-auto px-10 py-4 rounded-2xl bg-white border-2 border-[#8B0000] text-[#8B0000] font-black text-[13px] uppercase tracking-widest shadow-2xl shadow-red-900/5 active:scale-95 transition-all flex items-center space-x-2 hover:bg-red-50">
                  <SaveIcon size={18} />
                  <span>Save Permissions</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {isAddingRole && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-md z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-[32px] shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in duration-300">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50"><h4 className="font-black text-[#8B0000] text-sm uppercase flex items-center"><Shield size={18} className="mr-2" />NEW ROLE</h4><button onClick={() => setIsAddingRole(false)} className="p-2 text-slate-400"><X size={20} /></button></div>
            <div className="p-8 space-y-6">
              <input type="text" value={newRoleName} onChange={(e) => setNewRoleName(e.target.value)} placeholder="ROLE NAME" className="w-full px-5 py-4 rounded-2xl border border-slate-100 bg-slate-50 focus:border-[#8B0000] outline-none text-sm font-black uppercase transition-all" />
              <div className="flex flex-col space-y-3 pt-4">
                <button onClick={handleCreateRole} className="w-full py-5 rounded-2xl bg-white border-2 border-[#8B0000] text-[#8B0000] font-black text-[13px] uppercase tracking-widest shadow-xl shadow-red-900/5 hover:bg-red-50 active:scale-95 transition-all">Create Account Role</button>
                <button onClick={() => setIsAddingRole(false)} className="w-full py-5 rounded-2xl text-slate-500 font-black text-[11px] uppercase tracking-widest">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const SaveIcon = ({ size }: { size: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>
);

export default RoleManagement;
