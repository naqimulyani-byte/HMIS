
import React, { useState } from 'react';
import { Beaker, Search, Calendar, X, Check, Save, FileText, ChevronRight, ClipboardList, Clock } from 'lucide-react';
import { PRIMARY_COLOR } from '../constants';

interface TestParameter {
  name: string;
  unit: string;
  refRange: string;
  result?: string;
  remarks?: string;
}

interface LabResultOrder {
  id: string;
  patientName: string;
  mrNo: string;
  receiptNo: string;
  gender: string;
  age: string;
  date: string; // Format: "DD/MM/YYYY HH:mm AM/PM"
  tests: {
    name: string;
    status: 'Pending' | 'Completed';
    resultedDate?: string;
    parameters: TestParameter[];
  }[];
}

const TEST_DEFINITIONS: Record<string, TestParameter[]> = {
  'Liver Function Test (LFT)': [
    { name: 'SGOT/AST', unit: 'U/L', refRange: '0 - 40' },
    { name: 'SGPT/ALT', unit: 'U/L', refRange: '0 - 40' },
    { name: 'Bilirubin Total', unit: 'mg/dL', refRange: '0.1 - 1.2' },
  ],
  'CBC': [
    { name: 'Hemoglobin', unit: 'g/dL', refRange: '13.5 - 17.5' },
    { name: 'TLC', unit: 'x10^3/uL', refRange: '4.0 - 11.0' },
    { name: 'Platelets', unit: 'x10^3/uL', refRange: '150 - 450' },
  ]
};

const LabResults: React.FC = () => {
  // Use 2026-02-01 as default to match mock data
  const [filterDate, setFilterDate] = useState('2026-02-01');
  const [searchInput, setSearchInput] = useState('');
  const [activeSearchQuery, setActiveSearchQuery] = useState('');
  const [showOrderDetails, setShowOrderDetails] = useState(false);
  const [showEntryModal, setShowEntryModal] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<LabResultOrder | null>(null);
  const [activeTestIndex, setActiveTestIndex] = useState<number | null>(null);

  const [orders, setOrders] = useState<LabResultOrder[]>([
    { 
      id: 'o1', 
      patientName: 'HAROON', 
      mrNo: '2601010003', 
      receiptNo: 'LR2601020001', 
      gender: 'Male', 
      age: '5 Years', 
      // Adjusted date to 01/02/2026 to match default filterDate '2026-02-01'
      date: '01/02/2026 09:19 PM', 
      tests: [
        { name: 'Liver Function Test (LFT)', status: 'Pending', parameters: [...TEST_DEFINITIONS['Liver Function Test (LFT)']] }, 
        { name: 'CBC', status: 'Pending', parameters: [...TEST_DEFINITIONS['CBC']] }
      ] 
    }
  ]);

  const handleSearch = () => {
    setActiveSearchQuery(searchInput.trim());
  };

  const filteredOrders = orders.filter(o => {
    // 1. Date filter logic
    // o.date is "DD/MM/YYYY ..."
    const datePart = o.date.split(' ')[0]; // "01/02/2026"
    const [d, m, y] = datePart.split('/');
    const orderDateFormatted = `${y}-${m}-${d}`; // "2026-02-01"
    const matchesDate = orderDateFormatted === filterDate;

    // 2. Search query logic (if activeSearchQuery is empty, match all)
    const matchesSearch = activeSearchQuery === '' || 
      o.patientName.toLowerCase().includes(activeSearchQuery.toLowerCase()) || 
      o.mrNo.includes(activeSearchQuery) || 
      o.receiptNo.includes(activeSearchQuery);

    return matchesDate && matchesSearch;
  });

  const handleEnterResults = (order: LabResultOrder) => { 
    setSelectedOrder(order); 
    setShowOrderDetails(true); 
  };

  const handleAddResults = (testIndex: number) => { 
    setActiveTestIndex(testIndex); 
    setShowEntryModal(true); 
  };

  const handleSaveResults = (params: TestParameter[]) => {
    if (selectedOrder && activeTestIndex !== null) {
      const now = new Date();
      const formattedDate = now.toLocaleDateString('en-GB') + ' ' + now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: true });
      const updatedOrders = orders.map(o => {
        if (o.id === selectedOrder.id) {
          const updatedTests = [...o.tests];
          updatedTests[activeTestIndex] = { ...updatedTests[activeTestIndex], parameters: params, status: 'Completed' as const, resultedDate: formattedDate };
          const updatedOrder = { ...o, tests: updatedTests };
          setSelectedOrder(updatedOrder);
          return updatedOrder;
        }
        return o;
      });
      setOrders(updatedOrders);
      setShowEntryModal(false);
      setActiveTestIndex(null);
    }
  };

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200/60 p-6">
        <div className="flex items-center space-x-2 mb-6">
          <Beaker size={20} className="text-[#8B0000]" />
          <h3 className="text-lg font-black text-[#8B0000] uppercase tracking-tight">Lab Results</h3>
        </div>
        <div className="flex flex-wrap items-end gap-4">
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">From Date</label>
            <div className="relative">
              <input 
                type="date" 
                value={filterDate} 
                onChange={(e) => setFilterDate(e.target.value)}
                className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm font-bold outline-none focus:border-[#8B0000] cursor-pointer" 
              />
              <Calendar size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>
          </div>
          <div className="space-y-1.5 flex-1 min-w-[300px]">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Search</label>
            <div className="relative">
              <input 
                type="text" 
                placeholder="Patient Name / MR# / Receipt#" 
                value={searchInput} 
                onChange={(e) => setSearchInput(e.target.value)} 
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-medium" 
              />
              <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            </div>
          </div>
          <button 
            onClick={handleSearch}
            className="px-10 py-2.5 rounded-xl bg-white border-2 border-[#8B0000] text-[#8B0000] font-black text-xs uppercase tracking-widest shadow-lg shadow-red-900/5 hover:bg-red-50 transition-all active:scale-95"
          >
            Search
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {filteredOrders.length > 0 ? (
          filteredOrders.map(order => {
            const comp = order.tests.filter(t => t.status === 'Completed').length;
            const tot = order.tests.length;
            return (
              <div key={order.id} className="bg-white rounded-2xl border border-slate-200/60 p-5 flex items-center justify-between group hover:border-[#8B0000]/20 transition-all shadow-sm animate-in fade-in slide-in-from-bottom-2">
                <div className="space-y-2">
                  <h4 className="font-black text-gray-800 text-xl tracking-tight uppercase">{order.patientName}</h4>
                  <div className="flex items-center space-x-2">
                    <span className="bg-[#8B0000] text-white text-[10px] font-black px-2.5 py-1 rounded-full uppercase">MR# {order.mrNo}</span>
                    <span className={`text-[10px] font-black px-2.5 py-1 rounded-full ${comp === tot ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                      Results {comp === tot ? 'Completed' : 'Pending'} ({comp}/{tot})
                    </span>
                  </div>
                </div>
                <button 
                  onClick={() => handleEnterResults(order)} 
                  className="px-8 py-3 rounded-xl border-2 border-[#8B0000] bg-white text-[#8B0000] font-black text-sm uppercase tracking-tight hover:bg-red-50 transition-all active:scale-95"
                >
                  Enter Results
                </button>
              </div>
            );
          })
        ) : (
          <div className="bg-white rounded-2xl border border-dashed border-slate-200 p-20 flex flex-col items-center justify-center text-center">
             <ClipboardList size={48} className="text-slate-200 mb-4" />
             <h4 className="font-black text-slate-400 uppercase tracking-widest text-sm">No Matching Orders Found</h4>
             <p className="text-[10px] font-bold text-slate-300 uppercase tracking-tighter mt-1">Try a different date or clear your search criteria</p>
          </div>
        )}
      </div>

      {showOrderDetails && selectedOrder && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl overflow-hidden animate-in zoom-in duration-200">
            <div className="bg-[#8B0000] p-5 flex justify-between items-center text-white">
              <h4 className="font-black text-lg uppercase tracking-tight">Order Details</h4>
              <button onClick={() => setShowOrderDetails(false)} className="hover:bg-white/10 p-1 rounded-full transition-colors">
                <X size={24} />
              </button>
            </div>
            <div className="p-6 space-y-4">
              {selectedOrder.tests.map((test, idx) => (
                <div key={idx} className="p-4 border border-slate-100 rounded-xl flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div>
                    <h5 className="font-black text-slate-800 text-base">{test.name}</h5>
                    <span className={`text-[10px] font-black uppercase tracking-widest ${test.status === 'Completed' ? 'text-green-600' : 'text-amber-500'}`}>
                      {test.status}
                    </span>
                  </div>
                  <button 
                    onClick={() => handleAddResults(idx)} 
                    className="px-6 py-2.5 rounded-lg bg-white border-2 border-[#8B0000] text-[#8B0000] font-black text-xs uppercase tracking-tight hover:bg-red-50 shadow-sm"
                  >
                    {test.status === 'Completed' ? 'Edit' : 'Add'} Results
                  </button>
                </div>
              ))}
            </div>
            <div className="p-6 border-t border-slate-100 flex justify-end">
              <button 
                onClick={() => setShowOrderDetails(false)} 
                className="px-8 py-2.5 rounded-xl border border-slate-200 text-slate-500 font-black text-xs uppercase tracking-widest hover:bg-slate-50"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {showEntryModal && selectedOrder && activeTestIndex !== null && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-[110] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl overflow-hidden animate-in slide-in-from-bottom-4 flex flex-col max-h-[90vh]">
            <div className="bg-[#8B0000] p-5 flex justify-between items-center text-white shrink-0">
              <h4 className="font-black text-lg uppercase leading-none">Result Entry: {selectedOrder.tests[activeTestIndex].name}</h4>
              <button onClick={() => setShowEntryModal(false)} className="hover:bg-white/10 p-1 rounded-full transition-colors">
                <X size={24} />
              </button>
            </div>
            <div className="p-8 overflow-y-auto custom-scrollbar">
              <div className="space-y-6">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-slate-100 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                      <th className="py-2">Parameter</th>
                      <th className="py-2">Ref. Range</th>
                      <th className="py-2">Unit</th>
                      <th className="py-2 w-32">Result</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {selectedOrder.tests[activeTestIndex].parameters.map((param, pIdx) => (
                      <tr key={pIdx}>
                        <td className="py-4 text-sm font-bold text-slate-700">{param.name}</td>
                        <td className="py-4 text-xs text-slate-500 italic">{param.refRange}</td>
                        <td className="py-4 text-xs font-bold text-slate-400 uppercase">{param.unit}</td>
                        <td className="py-4">
                          <input 
                            type="text" 
                            defaultValue={param.result || ''}
                            onBlur={(e) => {
                              const newParams = [...selectedOrder.tests[activeTestIndex].parameters];
                              newParams[pIdx].result = e.target.value;
                            }}
                            placeholder="..."
                            className="w-full px-3 py-2 rounded-lg border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold"
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-8 flex justify-end space-x-3 pt-6 border-t border-slate-100">
                <button 
                  onClick={() => setShowEntryModal(false)} 
                  className="px-8 py-3 rounded-xl border border-slate-200 text-slate-500 font-black text-xs uppercase tracking-widest hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => handleSaveResults(selectedOrder.tests[activeTestIndex].parameters)} 
                  className="px-10 py-3 rounded-xl bg-white border-2 border-[#8B0000] text-[#8B0000] font-black text-xs uppercase tracking-widest shadow-xl shadow-red-900/5 active:scale-95 transition-all flex items-center space-x-2 hover:bg-red-50"
                >
                  <Save size={18} />
                  <span>Save Results</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #f8fafc; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #cbd5e0; }
      `}</style>
    </div>
  );
};

export default LabResults;
