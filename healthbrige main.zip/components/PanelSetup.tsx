
import React, { useState } from 'react';
import { ClipboardList, Plus, Edit2, Trash2, Power, Save, X, Check } from 'lucide-react';
import { PanelCategory } from '../types';

interface PanelSetupProps {
  panels: PanelCategory[];
  setPanels: React.Dispatch<React.SetStateAction<PanelCategory[]>>;
}

const COLOR_OPTIONS = [
  { name: 'Red', border: 'border-red-800', badge: 'bg-red-50 text-red-800' },
  { name: 'Gray', border: 'border-gray-500', badge: 'bg-gray-100 text-gray-700' },
  { name: 'Pink', border: 'border-pink-400', badge: 'bg-pink-50 text-pink-600' },
  { name: 'Blue', border: 'border-blue-600', badge: 'bg-blue-50 text-blue-700' },
  { name: 'Purple', border: 'border-purple-600', badge: 'bg-purple-50 text-purple-700' },
  { name: 'Green', border: 'border-green-600', badge: 'bg-green-50 text-green-700' },
  { name: 'Orange', border: 'border-orange-600', badge: 'bg-orange-50 text-orange-700' },
];

const PanelSetup: React.FC<PanelSetupProps> = ({ panels, setPanels }) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    discount: '0',
    colorIndex: 0,
    description: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;

    const selectedColor = COLOR_OPTIONS[formData.colorIndex];
    
    if (editingId) {
      setPanels(prev => prev.map(p => p.id === editingId ? {
        ...p,
        name: formData.name,
        discount: Number(formData.discount),
        color: selectedColor.border,
        badge: selectedColor.badge,
        description: formData.description
      } : p));
      setEditingId(null);
    } else {
      const newPanel: PanelCategory = {
        id: Math.random().toString(36).substr(2, 9),
        name: formData.name,
        discount: Number(formData.discount),
        color: selectedColor.border,
        badge: selectedColor.badge,
        description: formData.description,
        isActive: true
      };
      setPanels(prev => [...prev, newPanel]);
    }
    handleClear();
  };

  const handleEdit = (panel: PanelCategory) => {
    const colorIdx = COLOR_OPTIONS.findIndex(c => c.badge === panel.badge);
    setEditingId(panel.id);
    setFormData({
      name: panel.name,
      discount: panel.discount.toString(),
      colorIndex: colorIdx === -1 ? 0 : colorIdx,
      description: panel.description || ''
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleToggleStatus = (id: string) => {
    setPanels(prev => prev.map(p => p.id === id ? { ...p, isActive: !p.isActive } : p));
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Permanently delete this panel category?')) {
      setPanels(prev => prev.filter(p => p.id !== id));
      if (editingId === id) setEditingId(null);
    }
  };

  const handleClear = () => {
    setFormData({ name: '', discount: '0', colorIndex: 0, description: '' });
    setEditingId(null);
  };

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-8">
      {/* Add/Edit Form Card */}
      <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden animate-in fade-in slide-in-from-top-4 duration-500">
        <div className="p-5 border-b border-slate-50 bg-slate-50/50 flex justify-between items-center">
          <h3 className="text-base font-black text-[#8B0000] uppercase tracking-tight flex items-center">
            <ClipboardList size={20} className="mr-2" />
            {editingId ? 'Update Panel Category' : 'Add Panel Category'}
          </h3>
          {editingId && (
            <button onClick={handleClear} className="text-slate-400 hover:text-red-800 transition-colors">
              <X size={20} />
            </button>
          )}
        </div>
        
        <form onSubmit={handleSubmit} className="p-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-end">
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Category Name</label>
              <input 
                type="text" 
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
                placeholder="Category Name"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold uppercase"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Discount %</label>
              <input 
                type="number" 
                value={formData.discount}
                onChange={e => setFormData({...formData, discount: e.target.value})}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Badge Color</label>
              <select 
                value={formData.colorIndex}
                onChange={e => setFormData({...formData, colorIndex: Number(e.target.value)})}
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold bg-white appearance-none cursor-pointer"
              >
                {COLOR_OPTIONS.map((c, i) => <option key={i} value={i}>{c.name}</option>)}
              </select>
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Description</label>
              <input 
                type="text" 
                value={formData.description}
                onChange={e => setFormData({...formData, description: e.target.value})}
                placeholder="Description"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold"
              />
            </div>
          </div>

          <div className="mt-8 flex justify-end space-x-3 border-t border-slate-50 pt-6">
            <button 
              type="button" 
              onClick={handleClear}
              className="px-8 py-3 rounded-xl font-bold text-slate-400 bg-slate-50 hover:bg-slate-100 transition-all text-xs uppercase tracking-widest"
            >
              Clear
            </button>
            <button 
              type="submit"
              className="px-12 py-3 rounded-xl bg-[#8B0000] text-white font-black text-xs uppercase tracking-widest shadow-xl shadow-red-900/20 active:scale-95 transition-all flex items-center justify-center space-x-2"
            >
              <Save size={16} />
              <span>{editingId ? 'Update Panel' : 'Save'}</span>
            </button>
          </div>
        </form>
      </div>

      {/* List Card */}
      <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-5 border-b border-slate-50 bg-slate-50/50">
          <h4 className="text-[11px] font-black text-slate-500 uppercase tracking-widest">Panel Categories</h4>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-100 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                <th className="px-8 py-5">Category</th>
                <th className="px-8 py-5 text-center">Discount</th>
                <th className="px-8 py-5 text-center">Badge</th>
                <th className="px-8 py-5 text-center">Status</th>
                <th className="px-8 py-5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {panels.filter(p => p.id !== '1').map((panel) => (
                <tr key={panel.id} className={`hover:bg-slate-50/50 transition-colors group ${!panel.isActive ? 'opacity-60' : ''}`}>
                  <td className="px-8 py-5">
                    <div className="flex flex-col">
                      <span className="font-black text-slate-800 text-sm uppercase">{panel.name}</span>
                      {panel.description && <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter mt-0.5">{panel.description}</span>}
                    </div>
                  </td>
                  <td className="px-8 py-5 text-center">
                    <span className="text-sm font-black text-red-800">{panel.discount}%</span>
                  </td>
                  <td className="px-8 py-5 text-center">
                    <span className={`text-[9px] font-black px-3 py-1 rounded-full uppercase tracking-widest border border-current opacity-80 ${panel.badge}`}>
                      {panel.name}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-center">
                    <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-widest ${panel.isActive ? 'bg-green-50 text-green-600' : 'bg-slate-100 text-slate-400'}`}>
                      {panel.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <button 
                        onClick={() => handleEdit(panel)}
                        className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition-all active:scale-90"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button 
                        onClick={() => handleToggleStatus(panel.id)}
                        className={`p-2 transition-all active:scale-90 rounded-lg ${panel.isActive ? 'text-orange-500 hover:bg-orange-50' : 'text-slate-300 hover:bg-slate-100'}`}
                      >
                        <Power size={16} />
                      </button>
                      <button 
                        onClick={() => handleDelete(panel.id)}
                        className="p-2 text-slate-300 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all active:scale-90"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default PanelSetup;
