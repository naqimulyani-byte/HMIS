
import React, { useState } from 'react';
import { Stethoscope, Search, Plus, Calendar, X, Check, Printer, User, Filter, Activity, Edit2, Trash2, Clock } from 'lucide-react';
import { PRIMARY_COLOR, PANEL_CATEGORIES } from '../constants';

interface ProcedureOrder {
  id: string;
  receiptNo: string;
  trxNo: string;
  mrNo: string;
  patientName: string;
  procedures: string[];
  panel: string;
  grossAmount: number;
  discount: number;
  netAmount: number;
  date: string;
  status: 'Pending' | 'Completed';
}

const AVAILABLE_PROCEDURES = [
  { id: 'p1', name: 'Minor Procedure', fee: 1000 },
  { id: 'p2', name: 'Physiotherapy', fee: 1000 },
  { id: 'p3', name: 'Dressing', fee: 300 },
  { id: 'p4', name: 'Stitches (Simple)', fee: 500 },
  { id: 'p5', name: 'ECG', fee: 400 },
  { id: 'p6', name: 'Nebulization', fee: 150 },
  { id: 'p7', name: 'Suction', fee: 200 },
];

const ProcedureCounter: React.FC = () => {
  const [fromDate, setFromDate] = useState('2026-01-10');
  const [toDate, setToDate] = useState('2026-01-10');
  const [searchQuery, setSearchQuery] = useState('');
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [modalStep, setModalStep] = useState<'search' | 'select'>('search');
  
  // Search state in modal
  const [orderSearchQuery, setOrderSearchQuery] = useState('');
  const [procSearchQuery, setProcSearchQuery] = useState('');

  // New Order State
  const [editingOrderId, setEditingOrderId] = useState<string | null>(null);
  const [selectedPatient, setSelectedPatient] = useState<any>(null);
  const [selectedProcs, setSelectedProcs] = useState<string[]>([]);
  const [selectedPanel, setSelectedPanel] = useState(PANEL_CATEGORIES[3]); // Default: Paying

  // Mock data for existing orders
  const [orders, setOrders] = useState<ProcedureOrder[]>([
    {
      id: 'o1',
      receiptNo: 'PRR260110001',
      trxNo: '---',
      mrNo: '2601010003',
      patientName: 'HAROON',
      procedures: ['Minor Procedure'],
      panel: 'Paying',
      grossAmount: 1000,
      discount: 0,
      netAmount: 1000,
      date: '10/01/2026 10:44 PM',
      status: 'Pending'
    }
  ]);

  // Mock registered patients (reusing from context)
  const registeredPatients = [
    { id: '1', mrNo: '2601010003', name: 'HAROON', gender: 'Male', age: '5 Years', dept: 'Ophthalmology Department', time: '01/01/2026 02:21 PM' },
    { id: '2', mrNo: '2601010002', name: 'SAIF ULLAH', gender: 'Male', age: '25 Years', dept: 'Pediatrics Medicine Department', time: '01/01/2026 02:04 PM' },
  ];

  const handlePatientSelect = (patient: any) => {
    setSelectedPatient(patient);
    setModalStep('select');
  };

  const toggleProc = (procId: string) => {
    setSelectedProcs(prev => 
      prev.includes(procId) ? prev.filter(id => id !== procId) : [...prev, procId]
    );
  };

  const calculateTotals = () => {
    const gross = selectedProcs.reduce((acc, id) => {
      const proc = AVAILABLE_PROCEDURES.find(p => p.id === id);
      return acc + (proc?.fee || 0);
    }, 0);
    const discountAmount = Math.round((gross * selectedPanel.discount) / 100);
    const net = gross - discountAmount;
    return { gross, discountAmount, net };
  };

  const handleFinalizeOrder = () => {
    const { gross, discountAmount, net } = calculateTotals();
    const now = new Date();
    const formattedDate = now.toLocaleDateString('en-GB') + ' ' + now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: true });
    
    if (editingOrderId) {
      setOrders(orders.map(o => {
        if (o.id === editingOrderId) {
          return {
            ...o,
            procedures: selectedProcs.map(id => AVAILABLE_PROCEDURES.find(p => p.id === id)?.name || ''),
            panel: selectedPanel.name,
            grossAmount: gross,
            discount: discountAmount,
            netAmount: net,
          };
        }
        return o;
      }));
    } else {
      const count = orders.length + 1;
      const newOrder: ProcedureOrder = {
        id: Math.random().toString(36).substr(2, 9),
        receiptNo: `PRR260110${String(count).padStart(4, '0')}`,
        trxNo: '---',
        mrNo: selectedPatient.mrNo,
        patientName: selectedPatient.name,
        procedures: selectedProcs.map(id => AVAILABLE_PROCEDURES.find(p => p.id === id)?.name || ''),
        panel: selectedPanel.name,
        grossAmount: gross,
        discount: discountAmount,
        netAmount: net,
        date: formattedDate,
        status: 'Pending'
      };
      setOrders([newOrder, ...orders]);
      triggerReceiptPrint(newOrder);
    }
    
    resetOrderForm();
    setShowOrderModal(false);
  };

  const resetOrderForm = () => {
    setSelectedPatient(null);
    setSelectedProcs([]);
    setSelectedPanel(PANEL_CATEGORIES[3]);
    setOrderSearchQuery('');
    setProcSearchQuery('');
    setModalStep('search');
    setEditingOrderId(null);
  };

  const handleDeleteOrder = (id: string) => {
    if (window.confirm('Are you sure you want to delete this procedure order?')) {
      setOrders(orders.filter(o => o.id !== id));
    }
  };

  const handleCompleteOrder = (id: string) => {
    setOrders(orders.map(o => o.id === id ? { ...o, status: 'Completed' as const, trxNo: `PTX${Math.floor(Math.random() * 90000 + 10000)}` } : o));
  };

  const handleEditOrder = (order: ProcedureOrder) => {
    const patient = registeredPatients.find(p => p.mrNo === order.mrNo);
    const procs = order.procedures.map(pName => AVAILABLE_PROCEDURES.find(ap => ap.name === pName)?.id).filter(Boolean) as string[];
    const panel = PANEL_CATEGORIES.find(pc => pc.name === order.panel) || PANEL_CATEGORIES[3];

    setSelectedPatient(patient || { name: order.patientName, mrNo: order.mrNo, age: 'N/A', dept: 'N/A' });
    setSelectedProcs(procs);
    setSelectedPanel(panel);
    setEditingOrderId(order.id);
    setModalStep('select');
    setShowOrderModal(true);
  };

  const triggerReceiptPrint = (order: ProcedureOrder) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    const html = `
      <html>
        <head>
          <title>Procedure Receipt - ${order.receiptNo}</title>
          <style>
            @page { size: 80mm 200mm; margin: 0; }
            body { font-family: 'Courier New', Courier, monospace; width: 70mm; margin: 5mm; font-size: 12px; }
            .center { text-align: center; }
            .header { border-bottom: 1px dashed #000; padding-bottom: 5px; margin-bottom: 10px; }
            .row { display: flex; justify-content: space-between; margin: 2px 0; }
            .bold { font-weight: bold; }
            .divider { border-top: 1px dashed #000; margin: 5px 0; }
            .total { font-size: 14px; font-weight: bold; margin-top: 10px; border-top: 1px solid #000; padding-top: 5px; }
          </style>
        </head>
        <body onload="window.print(); window.close();">
          <div class="header center">
            <div class="bold">DHQ HOSPITAL SUDHNUTI</div>
            <div>PROCEDURE RECEIPT</div>
            <div class="divider"></div>
          </div>
          <div class="row"><span>Receipt#</span> <span class="bold">${order.receiptNo}</span></div>
          <div class="row"><span>Patient</span> <span class="bold">${order.patientName}</span></div>
          <div class="row"><span>MR No</span> <span>${order.mrNo}</span></div>
          <div class="divider"></div>
          <div class="bold">PROCEDURES:</div>
          ${order.procedures.map(p => `<div class="row"><span>- ${p}</span></div>`).join('')}
          <div class="divider"></div>
          <div class="row total"><span>TOTAL:</span> <span>Rs. ${order.netAmount}</span></div>
        </body>
      </html>
    `;
    printWindow.document.write(html);
    printWindow.document.close();
  };

  const filteredOrders = orders.filter(o => 
    o.patientName.toLowerCase().includes(searchQuery.toLowerCase()) || 
    o.mrNo.includes(searchQuery) || 
    o.receiptNo.includes(searchQuery)
  );

  const filteredPatients = registeredPatients.filter(p => 
    p.name.toLowerCase().includes(orderSearchQuery.toLowerCase()) || 
    p.mrNo.includes(orderSearchQuery)
  );

  const filteredProcedures = AVAILABLE_PROCEDURES.filter(p => 
    p.name.toLowerCase().includes(procSearchQuery.toLowerCase())
  );

  const stats = {
    gross: orders.reduce((a, b) => a + b.grossAmount, 0),
    disc: orders.reduce((a, b) => a + b.discount, 0),
    refund: 0,
    net: orders.reduce((a, b) => a + b.netAmount, 0),
    count: orders.length
  };

  const { net: modalNet } = calculateTotals();

  return (
    <div className="p-3 md:p-6 max-w-[1600px] mx-auto space-y-4 md:space-y-6 pb-24 md:pb-6">
      {/* Search & Actions Header */}
      <div className="bg-white p-3 md:p-4 rounded-2xl shadow-sm border border-slate-200 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-2 w-full md:w-auto">
          <Activity size={20} className="text-[#8B0000]" />
          <h3 className="text-base md:text-lg font-black text-slate-800 uppercase tracking-tight leading-none">Procedure Counter</h3>
        </div>

        <div className="flex-1 flex flex-col sm:flex-row items-center gap-3 w-full">
          <div className="relative w-full">
            <input 
              type="text" 
              placeholder="Search by Name, MR, or Receipt..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-[#8B0000] outline-none shadow-inner bg-slate-50/30"
            />
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          </div>

          <div className="flex w-full sm:w-auto gap-2">
            <select className="bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-[10px] font-black uppercase text-slate-700 outline-none shadow-sm cursor-pointer hover:bg-slate-50 flex-1 sm:flex-none">
              <option>All Panels</option>
              {PANEL_CATEGORIES.map(p => <option key={p.id}>{p.name}</option>)}
            </select>

            <div className="hidden lg:flex items-center space-x-2 bg-white border border-slate-200 rounded-xl px-3 py-2 shadow-sm">
              <input 
                type="date" 
                value={fromDate} 
                onChange={(e) => setFromDate(e.target.value)}
                className="text-[10px] font-black outline-none bg-transparent uppercase" 
              />
              <span className="text-slate-300">-</span>
              <input 
                type="date" 
                value={toDate} 
                onChange={(e) => setToDate(e.target.value)}
                className="text-[10px] font-black outline-none bg-transparent uppercase" 
              />
              <Calendar size={14} className="text-slate-400" />
            </div>
          </div>
        </div>

        <button 
          onClick={() => { resetOrderForm(); setShowOrderModal(true); }}
          className="w-full md:w-auto px-6 py-2.5 rounded-xl bg-[#8B0000] text-white font-black text-sm uppercase tracking-widest flex items-center justify-center space-x-2 shadow-lg shadow-red-900/20 active:scale-95 transition-all"
        >
          <Plus size={18} />
          <span>New Order</span>
        </button>
      </div>

      {/* Stats Summary Panel */}
      <div className="bg-[#FAF6F6] border-l-4 border-[#8B0000] rounded-xl shadow-sm overflow-hidden">
        <div className="p-3 bg-[#FAF6F6] flex justify-between items-center border-b border-red-100">
          <div className="flex items-center text-[#8B0000] font-black text-[10px] md:text-[11px] uppercase tracking-wider">
            <Activity size={14} className="mr-2" />
            Total Procedures
          </div>
          <span className="bg-[#8B0000] text-white text-[10px] font-black px-2 py-0.5 rounded-md">
            {stats.count}
          </span>
        </div>
        <div className="p-4 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="flex flex-col">
            <span className="text-[9px] md:text-[10px] font-bold text-slate-400 uppercase tracking-widest">Gross</span>
            <span className="text-sm md:text-base font-black text-slate-700">{stats.gross.toLocaleString()}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[9px] md:text-[10px] font-bold text-slate-400 uppercase tracking-widest">Disc.</span>
            <span className="text-sm md:text-base font-black text-slate-700">{stats.disc.toLocaleString()}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[9px] md:text-[10px] font-bold text-red-800 uppercase tracking-widest">Refund</span>
            <span className="text-sm md:text-base font-black text-red-500">-{stats.refund}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[9px] md:text-[10px] font-black text-slate-500 uppercase tracking-widest">Net Revenue</span>
            <span className="text-sm md:text-lg font-black text-[#8B0000]">{stats.net.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Orders Listing */}
      <div className="space-y-3">
        {filteredOrders.length > 0 ? (
          filteredOrders.map(order => (
            <div key={order.id} className="bg-white rounded-2xl border border-slate-100 shadow-[0_2px_10px_rgb(0,0,0,0.02)] p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4 lg:gap-6 group hover:border-[#8B0000]/20 transition-all">
               <div className="flex items-center space-x-3 md:space-x-4">
                 <div className="w-10 h-10 md:w-12 md:h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-300 group-hover:text-[#8B0000] transition-colors shrink-0">
                    <User size={20} className="md:w-6 md:h-6" />
                 </div>
                 <div className="min-w-0 flex-1">
                   <h4 className="font-black text-slate-800 text-sm md:text-base uppercase leading-none mb-1 truncate">{order.patientName}</h4>
                   <div className="text-[9px] md:text-[10px] font-bold text-slate-400 uppercase tracking-tighter">
                     MR: {order.mrNo} <span className="mx-1 md:mx-2 opacity-30">•</span> {order.date}
                   </div>
                 </div>
               </div>

               <div className="flex flex-wrap items-center gap-x-4 md:gap-x-12 gap-y-3 border-t lg:border-t-0 pt-3 lg:pt-0">
                 <div className="flex flex-col items-start lg:items-center">
                    <span className="text-[8px] md:text-[9px] font-black text-slate-300 uppercase tracking-widest leading-none mb-1">Receipt No</span>
                    <span className="text-[10px] md:text-[11px] font-black text-[#8B0000] tracking-tight">{order.receiptNo}</span>
                 </div>
                 <div className="flex flex-col items-start lg:items-center">
                    <span className="text-[8px] md:text-[9px] font-black text-slate-300 uppercase tracking-widest leading-none mb-1">Trx. No</span>
                    <span className={`text-[10px] md:text-[11px] font-black tracking-tight ${order.status === 'Completed' ? 'text-green-600' : 'text-slate-400'}`}>
                      {order.trxNo}
                    </span>
                 </div>
                 <div className="flex flex-col items-start lg:items-center">
                    <span className="text-[8px] md:text-[9px] font-black text-slate-300 uppercase tracking-widest leading-none mb-1">Panel</span>
                    <span className="text-[10px] md:text-[11px] font-black text-blue-800 tracking-tight">{order.panel}</span>
                 </div>
                 
                 <div className={`flex items-center space-x-1.5 px-3 py-1 rounded-full border ${order.status === 'Completed' ? 'bg-green-50 text-green-700 border-green-100' : 'bg-red-50 text-red-800 border-red-100'}`}>
                    {order.status === 'Completed' ? <Check size={10} className="stroke-[3px]" /> : <Clock size={10} className="stroke-[3px]" />}
                    <span className="text-[8px] md:text-[9px] font-black uppercase tracking-widest">
                      {order.status === 'Completed' ? 'COMPLETED' : '1 PENDING'}
                    </span>
                 </div>

                 <div className="text-center lg:min-w-[80px]">
                    <div className="text-[8px] md:text-[9px] font-black text-slate-400 uppercase leading-none mb-1">{order.procedures.length} Items</div>
                    <div className="text-sm md:text-base font-black text-slate-800 leading-none">{order.netAmount.toLocaleString()}</div>
                 </div>

                 <div className="flex items-center space-x-2 ml-auto lg:ml-0">
                    <button 
                      onClick={() => handleEditOrder(order)}
                      className="p-1.5 md:p-2 rounded-lg border border-slate-100 text-blue-500 hover:bg-blue-50 active:scale-95 transition-all shadow-sm"
                    >
                       <Edit2 size={16} />
                    </button>
                    <button 
                      onClick={() => handleCompleteOrder(order.id)}
                      disabled={order.status === 'Completed'}
                      className={`p-1.5 md:p-2 rounded-lg border transition-all shadow-sm ${order.status === 'Completed' ? 'bg-slate-50 text-slate-300 border-slate-50' : 'bg-white border-slate-100 text-green-600 hover:bg-green-50 active:scale-95'}`}
                    >
                       <Check size={16} />
                    </button>
                    <button 
                      onClick={() => handleDeleteOrder(order.id)}
                      className="p-1.5 md:p-2 rounded-lg border border-slate-100 text-red-600 hover:bg-red-50 active:scale-95 transition-all shadow-sm"
                    >
                       <Trash2 size={16} />
                    </button>
                 </div>
               </div>
            </div>
          ))
        ) : (
          <div className="bg-white rounded-[2rem] border border-dashed border-slate-200 p-12 md:p-24 flex flex-col items-center justify-center text-center animate-in fade-in duration-500">
             <Stethoscope size={48} className="text-slate-200 mb-6" />
             <h3 className="text-lg md:text-xl font-black text-gray-800 uppercase tracking-tight">No Orders Found</h3>
             <p className="text-slate-400 text-xs md:text-sm font-medium mt-1">Scheduled procedures will appear here.</p>
          </div>
        )}
      </div>

      {/* New Procedure Order Modal */}
      {showOrderModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-2 md:p-4">
           <div className="bg-white rounded-3xl shadow-2xl w-full max-w-xl overflow-hidden animate-in zoom-in duration-200 flex flex-col max-h-[95vh] md:max-h-[90vh]">
              <div className="bg-[#8B0000] p-4 md:p-5 flex justify-between items-center text-white shrink-0">
                 <h4 className="font-black text-base md:text-lg tracking-tight uppercase">
                    {editingOrderId ? 'Update Procedure Order' : 'New Procedure Order'}
                 </h4>
                 <button onClick={() => setShowOrderModal(false)} className="hover:bg-white/10 p-1.5 rounded-full transition-colors">
                    <X size={24} />
                 </button>
              </div>

              <div className="flex-1 overflow-y-auto p-4 md:p-6 custom-scrollbar">
                {modalStep === 'search' ? (
                  <div className="space-y-6">
                    <div className="relative">
                       <input 
                         type="text" 
                         placeholder="Search Patient by MR / Name..."
                         value={orderSearchQuery}
                         autoFocus
                         onChange={(e) => setOrderSearchQuery(e.target.value)}
                         className="w-full pl-12 pr-4 py-3 md:py-4 rounded-xl border-2 border-slate-100 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner"
                       />
                       <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" />
                    </div>

                    <div className="space-y-3 pb-4">
                      {orderSearchQuery.length > 0 ? filteredPatients.map(patient => (
                        <div key={patient.id} className="p-4 md:p-5 border border-slate-50 rounded-2xl bg-white flex justify-between items-center group hover:bg-red-50 transition-all border-l-4 hover:border-l-[#8B0000] shadow-sm">
                           <div className="min-w-0 flex-1">
                              <div className="font-black text-slate-800 text-sm md:text-base uppercase leading-none mb-1 truncate">{patient.name}</div>
                              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">
                                MR#: {patient.mrNo} | Age: {patient.age}
                              </div>
                              <div className="text-[9px] font-black text-[#8B0000] uppercase mt-1 truncate">{patient.dept}</div>
                           </div>
                           <button 
                             onClick={() => handlePatientSelect(patient)}
                             className="bg-[#8B0000] text-white p-2 md:p-2.5 rounded-xl shadow-lg active:scale-95 transition-all ml-3 shrink-0"
                           >
                             <Plus size={18} />
                           </button>
                        </div>
                      )) : (
                        <div className="text-center py-10 text-slate-300">
                          <User size={40} className="mx-auto mb-2 opacity-20" />
                          <p className="text-[10px] font-black uppercase tracking-widest">Type to search registered patients</p>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6 animate-in fade-in duration-300">
                    <div className="bg-red-50/50 border border-red-50 rounded-2xl p-4 md:p-5 flex justify-between items-center">
                       <div className="flex items-center space-x-3 md:space-x-4 min-w-0">
                          <div className="w-10 h-10 md:w-12 md:h-12 bg-white rounded-2xl flex items-center justify-center text-[#8B0000] shadow-sm border border-red-50 shrink-0">
                             <User size={20} className="md:w-6 md:h-6" />
                          </div>
                          <div className="min-w-0">
                             <h5 className="font-black text-slate-800 uppercase leading-none mb-1 text-sm md:text-base truncate">{selectedPatient.name}</h5>
                             <div className="text-[9px] md:text-[10px] font-bold text-slate-500 uppercase tracking-tight">MR#: {selectedPatient.mrNo} | Age: {selectedPatient.age}</div>
                             <div className="text-[9px] font-black text-[#8B0000] uppercase mt-1 truncate">{selectedPatient.dept}</div>
                          </div>
                       </div>
                       {!editingOrderId && (
                         <button onClick={() => setModalStep('search')} className="text-[#8B0000] font-black text-[10px] md:text-[11px] hover:underline uppercase tracking-widest shrink-0 ml-2">Change</button>
                       )}
                    </div>

                    <div className="space-y-1.5 relative">
                       <label className="text-[10px] md:text-[11px] font-black text-[#8B0000] uppercase tracking-widest pl-1">Panel Category</label>
                       <select 
                         className="w-full px-4 py-3 rounded-xl border-2 border-slate-100 focus:border-[#8B0000] outline-none text-sm font-black uppercase appearance-none bg-white shadow-sm"
                         value={selectedPanel.id}
                         onChange={(e) => setSelectedPanel(PANEL_CATEGORIES.find(p => p.id === e.target.value) || PANEL_CATEGORIES[3])}
                       >
                          {PANEL_CATEGORIES.map(p => (
                            <option key={p.id} value={p.id}>{p.name} (% discount)</option>
                          ))}
                       </select>
                    </div>

                    <div className="space-y-3">
                       <div className="flex flex-col sm:flex-row justify-between sm:items-center px-1 gap-2">
                          <label className="text-[10px] md:text-[11px] font-black text-slate-800 uppercase tracking-widest">Select Procedures</label>
                          <div className="relative">
                             <input 
                               type="text" 
                               placeholder="Search..." 
                               value={procSearchQuery}
                               onChange={(e) => setProcSearchQuery(e.target.value)}
                               className="w-full sm:w-auto text-[10px] pl-8 pr-4 py-2 border border-slate-200 rounded-lg focus:border-[#8B0000] outline-none font-bold" 
                             />
                             <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-300" />
                          </div>
                       </div>
                       
                       <div className="border border-slate-100 rounded-2xl overflow-hidden max-h-[180px] md:max-h-[200px] overflow-y-auto bg-slate-50/20 custom-scrollbar shadow-inner">
                          {filteredProcedures.map(proc => {
                             const isChecked = selectedProcs.includes(proc.id);
                             return (
                               <label key={proc.id} className="flex items-center justify-between p-3 md:p-4 hover:bg-white cursor-pointer border-b border-white last:border-none group transition-all">
                                  <div className="flex items-center">
                                     <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${isChecked ? 'bg-[#8B0000] border-[#8B0000]' : 'bg-white border-slate-200'}`}>
                                        {isChecked && <Check size={12} className="text-white stroke-[4px]" />}
                                     </div>
                                     <input 
                                       type="checkbox" 
                                       checked={isChecked}
                                       onChange={() => toggleProc(proc.id)}
                                       className="hidden" 
                                     />
                                     <span className={`ml-3 md:ml-4 text-[11px] md:text-xs font-black uppercase transition-colors ${isChecked ? 'text-slate-800' : 'text-slate-500'}`}>{proc.name}</span>
                                  </div>
                                  <span className={`text-[10px] md:text-[11px] font-black ${isChecked ? 'text-[#8B0000]' : 'text-slate-400'} uppercase`}>{proc.fee}</span>
                               </label>
                             );
                          })}
                       </div>
                    </div>

                    <div className="bg-[#FAF6F6] border border-red-50 rounded-xl p-3 md:p-4 flex flex-col sm:flex-row justify-between items-center text-[#8B0000] font-black uppercase gap-2">
                       <div className="text-[10px] tracking-widest">
                         {selectedProcs.length} procedure(s) selected
                       </div>
                       <div className="text-xs md:text-sm tracking-tight">
                         Total: Rs. {modalNet.toLocaleString()}
                       </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="p-4 md:p-6 border-t border-slate-100 shrink-0 bg-white">
                <div className="flex justify-end space-x-3">
                   <button 
                     onClick={() => setShowOrderModal(false)}
                     className="px-6 md:px-8 py-2.5 md:py-3 rounded-xl border-2 border-slate-100 text-slate-400 font-black text-[10px] md:text-xs uppercase tracking-widest hover:bg-slate-50 transition-all flex-1 md:flex-none"
                   >
                     Cancel
                   </button>
                   <button 
                     onClick={handleFinalizeOrder}
                     disabled={modalStep === 'search' || selectedProcs.length === 0}
                     className={`px-8 md:px-10 py-2.5 md:py-3 rounded-xl font-black text-[10px] md:text-xs uppercase tracking-widest shadow-xl transition-all active:scale-95 border-2 flex-1 md:flex-none ${
                       modalStep === 'search' || selectedProcs.length === 0 
                       ? 'bg-slate-50 text-slate-300 border-slate-200 cursor-not-allowed' 
                       : 'bg-white border-[#8B0000] text-[#8B0000] shadow-red-900/5 hover:bg-red-50'
                     }`}
                   >
                     {editingOrderId ? 'Update Order' : 'Add Order'}
                   </button>
                </div>
              </div>
           </div>
        </div>
      )}

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #E2E8F0; border-radius: 10px; }
      `}</style>
    </div>
  );
};

export default ProcedureCounter;
