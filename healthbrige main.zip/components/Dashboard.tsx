
import React from 'react';
import { Activity, Users, Bed, DollarSign, Calendar, Filter, Scan, Beaker, Stethoscope } from 'lucide-react';
import { PANEL_CATEGORIES, PRIMARY_COLOR } from '../constants';
import StatsCard from './StatsCard';

const Dashboard: React.FC = () => {
  const summaryCards = [
    { label: 'TOTAL OPD', value: '0', sub: 'Registrations', icon: <Users size={18} />, color: 'border-red-800', iconColor: 'text-red-800 bg-red-50' },
    { label: 'ER PATIENTS', value: '0', sub: 'Emergency', icon: <Activity size={18} />, color: 'border-pink-400', iconColor: 'text-pink-600 bg-pink-50' },
    { label: 'ADMISSIONS', value: '0', sub: 'IPD Patients', icon: <Bed size={18} />, color: 'border-purple-500', iconColor: 'text-purple-600 bg-purple-50' },
    { label: 'ADMISSION FEES', value: '0', sub: 'Net Revenue', icon: <DollarSign size={18} />, color: 'border-green-500', iconColor: 'text-green-600 bg-green-50' },
  ];

  return (
    <div className="p-6 space-y-8 max-w-[1600px] mx-auto">
      {/* Dashboard Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h3 className="text-xl font-bold text-gray-800 flex items-center">
          <Activity className="mr-3" style={{ color: PRIMARY_COLOR }} size={24} />
          Dashboard Overview
        </h3>
        <div className="flex items-center space-x-2 bg-white p-1.5 rounded-xl shadow-sm border border-gray-100">
          <div className="flex items-center text-xs text-gray-500 bg-gray-50 px-3 py-1.5 rounded-lg border border-gray-100">
            <Calendar size={14} className="mr-2 text-gray-400" />
            <input type="text" defaultValue="01/02/2026" className="bg-transparent w-20 text-center focus:outline-none font-semibold text-gray-700" />
          </div>
          <span className="text-gray-300 font-bold">-</span>
          <div className="flex items-center text-xs text-gray-500 bg-gray-50 px-3 py-1.5 rounded-lg border border-gray-100">
            <Calendar size={14} className="mr-2 text-gray-400" />
            <input type="text" defaultValue="01/02/2026" className="bg-transparent w-20 text-center focus:outline-none font-semibold text-gray-700" />
          </div>
          <button className="bg-white text-[#8B0000] border-2 border-[#8B0000] p-2 rounded-lg hover:bg-red-50 transition-all shadow-md active:scale-95">
            <Filter size={18} />
          </button>
        </div>
      </div>

      {/* Primary Metrics (Upper Cards) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((card, idx) => (
          <div key={idx} className={`bg-white border-l-4 rounded-xl shadow-sm p-4 flex justify-between items-start ${card.color} hover:shadow-md transition-shadow`}>
            <div className="space-y-1">
              <div className="text-[10px] font-bold uppercase tracking-widest text-gray-500">{card.label}</div>
              <div className="text-3xl font-black text-gray-800 mt-2">0</div>
              <div className="text-xs text-gray-400 font-medium">{card.sub}</div>
            </div>
            <div className={`p-2 rounded-lg ${card.iconColor}`}>
              {card.icon}
            </div>
          </div>
        ))}
      </div>

      {/* Combined Stats Section */}
      <section className="space-y-4">
        <div className="flex items-center space-x-2 text-blue-700">
          <Activity size={18} />
          <h3 className="text-sm font-bold tracking-wide uppercase">Combined Lab + Radiology Statistics</h3>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {PANEL_CATEGORIES.map(cat => (
            <StatsCard 
              key={cat.id}
              title={cat.name}
              count={0}
              gross={0}
              disc={0}
              refund={0}
              net={0}
              colorClass={cat.color}
              badgeClass={cat.badge}
            />
          ))}
        </div>
      </section>

      {/* Radiology Section */}
      <section className="space-y-4">
        <div className="flex items-center space-x-2 text-red-800">
          <Scan size={18} />
          <h3 className="text-sm font-bold tracking-wide uppercase">Radiology Statistics</h3>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {PANEL_CATEGORIES.map(cat => (
            <StatsCard 
              key={cat.id}
              title={cat.name}
              count={0}
              gross={0}
              disc={0}
              refund={0}
              net={0}
              colorClass={cat.color}
              badgeClass={cat.badge}
            />
          ))}
        </div>
      </section>

      {/* Lab Section */}
      <section className="space-y-4">
        <div className="flex items-center space-x-2 text-teal-700">
          <Beaker size={18} />
          <h3 className="text-sm font-bold tracking-wide uppercase">Lab Statistics</h3>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {PANEL_CATEGORIES.map(cat => (
            <StatsCard 
              key={cat.id}
              title={cat.name}
              count={0}
              gross={0}
              disc={0}
              refund={0}
              net={0}
              colorClass={cat.color}
              badgeClass={cat.badge}
            />
          ))}
        </div>
      </section>
    </div>
  );
};

export default Dashboard;
