
import React, { useState, useRef } from 'react';
import { Settings, Upload, Database, AlertCircle, Save, HardDriveDownload, X, Check, FileJson } from 'lucide-react';
import { HospitalConfig, PanelCategory, Role, LabTest } from '../types';
import { Ward } from './WardSetup';

interface HospitalSetupProps {
  config: HospitalConfig;
  setConfig: React.Dispatch<React.SetStateAction<HospitalConfig>>;
  // Added for full backup/restore
  wards: Ward[];
  setWards: (wards: Ward[]) => void;
  panels: PanelCategory[];
  setPanels: (panels: PanelCategory[]) => void;
  roles: Role[];
  setRoles: (roles: Role[]) => void;
  labTests: any[];
  setLabTests: (tests: any[]) => void;
}

const HospitalSetup: React.FC<HospitalSetupProps> = ({ 
  config, setConfig, 
  wards, setWards,
  panels, setPanels,
  roles, setRoles,
  labTests, setLabTests
}) => {
  const [formData, setFormData] = useState<HospitalConfig>({ ...config });
  const [isSaved, setIsSaved] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  
  const logoInputRef = useRef<HTMLInputElement>(null);
  const restoreInputRef = useRef<HTMLInputElement>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setIsSaved(false);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('File is too large. Max 2MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, logo: reader.result as string }));
        setIsSaved(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = () => {
    if (!formData.name || !formData.address || !formData.contact) {
      alert('Please fill required fields marked with *');
      return;
    }
    setConfig(formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const handleCreateBackup = () => {
    const backupData = {
      version: '2.1',
      timestamp: new Date().toISOString(),
      hospital: config,
      wards: wards,
      panels: panels,
      roles: roles,
      labTests: labTests
    };

    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    
    const fileName = `HMIS_BACKUP_${config.name.replace(/\s+/g, '_')}_${new Date().toLocaleDateString().replace(/\//g, '-')}.json`;
    
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!window.confirm("WARNING: This will replace ALL current data. Proceed?")) {
      e.target.value = '';
      return;
    }

    setIsRestoring(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const data = JSON.parse(event.target?.result as string);
        
        // Validation check
        if (!data.hospital || !data.wards || !data.panels) {
          throw new Error("Invalid HMIS backup file structure.");
        }

        // Apply state updates
        setConfig(data.hospital);
        setFormData(data.hospital);
        setWards(data.wards);
        setPanels(data.panels);
        setRoles(data.roles);
        setLabTests(data.labTests);

        alert("Database restored successfully!");
      } catch (err) {
        alert("Error: " + (err instanceof Error ? err.message : "Failed to parse backup file"));
      } finally {
        setIsRestoring(false);
        if (restoreInputRef.current) restoreInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="p-6 max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden animate-in fade-in slide-in-from-top-4 duration-500">
          <div className="bg-slate-50/50 p-5 border-b border-slate-100 flex justify-between items-center">
            <h3 className="font-black text-slate-800 flex items-center uppercase tracking-wider text-sm">
              <Settings size={18} className="mr-2 text-red-800" />
              Hospital Configuration
            </h3>
            {isSaved && (
               <div className="text-green-600 text-[10px] font-black uppercase flex items-center bg-green-50 px-3 py-1 rounded-full animate-bounce">
                 <Save size={12} className="mr-1" /> Settings Saved Globally
               </div>
            )}
          </div>
          
          <div className="p-8 space-y-10">
            {/* Logo Section */}
            <div className="space-y-4">
               <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Hospital Logo (Header & Printouts)</label>
               
               {formData.logo ? (
                 <div className="relative w-48 h-48 group">
                    <img src={formData.logo} alt="Hospital Logo" className="w-full h-full object-contain border-2 border-slate-100 rounded-3xl p-4 bg-slate-50" />
                    <button 
                      onClick={() => { setFormData(prev => ({ ...prev, logo: null })); setIsSaved(false); }}
                      className="absolute -top-2 -right-2 bg-red-600 text-white p-2 rounded-full shadow-xl hover:scale-110 transition-transform"
                    >
                      <X size={16} />
                    </button>
                 </div>
               ) : (
                 <div 
                   onClick={() => logoInputRef.current?.click()}
                   className="border-2 border-dashed border-slate-200 rounded-3xl p-12 text-center cursor-pointer hover:bg-red-50/50 hover:border-red-200 transition-all group"
                 >
                    <input type="file" ref={logoInputRef} onChange={handleLogoUpload} accept="image/*" className="hidden" />
                    <Upload size={40} className="mx-auto text-slate-300 mb-4 group-hover:text-red-400 transition-colors" />
                    <p className="text-sm font-black text-slate-700 uppercase tracking-tight">Click to upload or drag logo</p>
                    <p className="text-[10px] text-slate-400 mt-1 uppercase font-bold">PNG, JPG, SVG up to 2MB</p>
                 </div>
               )}
            </div>

            {/* Form Section */}
            <div className="space-y-6 pt-6 border-t border-slate-50">
               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-1.5 md:col-span-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Hospital Name *</label>
                    <input type="text" name="name" value={formData.name} onChange={handleInputChange} className="w-full px-5 py-4 rounded-2xl border border-slate-200 focus:border-red-800 outline-none text-sm font-bold shadow-inner" />
                  </div>
                  <div className="space-y-1.5 md:col-span-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Physical Address *</label>
                    <input type="text" name="address" value={formData.address} onChange={handleInputChange} className="w-full px-5 py-4 rounded-2xl border border-slate-200 focus:border-red-800 outline-none text-sm font-bold shadow-inner" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Contact Number *</label>
                    <input type="text" name="contact" value={formData.contact} onChange={handleInputChange} className="w-full px-5 py-4 rounded-2xl border border-slate-200 focus:border-red-800 outline-none text-sm font-bold shadow-inner" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">PHC Registration No.</label>
                    <input type="text" name="phcNo" value={formData.phcNo} onChange={handleInputChange} className="w-full px-5 py-4 rounded-2xl border border-slate-200 focus:border-red-800 outline-none text-sm font-bold shadow-inner" />
                  </div>
               </div>
            </div>

            <div className="pt-8 border-t border-slate-50 flex justify-end">
               <button onClick={handleSave} className="flex items-center space-x-3 px-12 py-4 rounded-2xl bg-[#8B0000] text-white font-black uppercase tracking-widest shadow-2xl shadow-red-900/20 active:scale-95 hover:bg-red-900 transition-all">
                 <Save size={20} />
                 <span>Update Global Branding</span>
               </button>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="bg-slate-50/50 p-4 border-b border-slate-100 flex items-center">
            <Database size={16} className="mr-2 text-blue-800" />
            <h3 className="font-black text-slate-800 uppercase tracking-wider text-[11px]">Database Management</h3>
          </div>
          <div className="p-6 space-y-8">
            <div className="bg-amber-50 border border-amber-100 rounded-2xl p-5 flex items-start space-x-3 shadow-sm shadow-amber-900/5">
              <AlertCircle className="text-amber-500 shrink-0 mt-0.5" size={20} />
              <div>
                <div className="text-[11px] font-black text-amber-800 uppercase mb-1 tracking-tight">Data Security</div>
                <p className="text-[10px] leading-relaxed text-amber-700 font-medium">
                  Back up your database regularly to prevent data loss. Restore functionality should only be used in case of emergency or system migration.
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] pl-1">BACKUP DATA</h4>
              <div className="p-6 border border-slate-100 rounded-3xl bg-slate-50/50 text-center">
                <p className="text-[10px] text-slate-500 mb-6 font-bold uppercase">
                  Download a complete copy of your hospital database including patients, records, and settings.
                </p>
                <button 
                  onClick={handleCreateBackup}
                  className="w-full py-4 rounded-2xl border-2 border-[#8B0000] bg-white text-[#8B0000] font-black text-[11px] flex items-center justify-center space-x-3 hover:bg-red-50 transition-all uppercase tracking-widest shadow-xl shadow-red-900/5 active:scale-95"
                >
                  <HardDriveDownload size={18} />
                  <span>CREATE BACKUP</span>
                </button>
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] pl-1">RESTORE DATA</h4>
              <div className="p-6 border border-slate-100 rounded-3xl bg-white text-left">
                <div className="text-red-800 font-black text-[11px] uppercase mb-2">RESTORE FROM FILE</div>
                <p className="text-[10px] text-slate-500 mb-6 font-medium italic">
                  Note: This will replace ALL existing data with the content of the backup file.
                </p>
                <input type="file" ref={restoreInputRef} onChange={handleRestoreFile} accept=".json" className="hidden" />
                <button 
                  onClick={() => restoreInputRef.current?.click()}
                  disabled={isRestoring}
                  className={`w-full py-4 rounded-2xl border-2 border-dashed border-red-200 text-red-800 font-black text-[11px] flex items-center justify-center space-x-3 transition-all uppercase tracking-widest ${isRestoring ? 'opacity-50 cursor-wait' : 'hover:bg-red-50 active:scale-95'}`}
                >
                  {isRestoring ? <Database className="animate-spin" size={18} /> : <Upload size={18} />}
                  <span>{isRestoring ? 'RESTORING...' : 'UPLOAD BACKUP FILE'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HospitalSetup;
