
import React from 'react';
import { NAVIGATION_ITEMS, PRIMARY_COLOR } from '../constants';
import { ChevronRight, Activity } from 'lucide-react';
import { User } from '../types';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentUser: User | null;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, currentUser }) => {
  // Logic to hide administrative items for non-admin users
  const adminOnlyTabs = ['user-management', 'role-management', 'hospital-setup', 'speciality-setup', 'lab-setup', 'ward-setup', 'panel-setup'];
  const isUserAdmin = currentUser?.role === 'Admin';
  
  const filteredNavItems = NAVIGATION_ITEMS.filter(item => {
    if (adminOnlyTabs.includes(item.id)) return isUserAdmin;
    return true;
  });

  return (
    <div className="w-72 bg-white h-screen fixed left-0 top-0 border-r border-gray-100 overflow-y-auto hidden lg:block z-50 shadow-sm">
      <div className="p-6 border-b border-gray-50 flex items-center space-x-3 mb-2">
        <div className="relative">
          <div 
            className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-2xl shadow-lg shadow-red-900/20"
            style={{ backgroundColor: PRIMARY_COLOR }}
          >
            H
          </div>
          <Activity size={14} className="absolute -bottom-1 -right-1 text-white bg-[#8B0000] rounded-full p-0.5 border-2 border-white" />
        </div>
        <h1 className="text-xl font-black tracking-tighter text-gray-800 uppercase">HealthBridge</h1>
      </div>
      
      <nav className="px-3 space-y-1">
        {filteredNavItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center p-3 rounded-xl transition-all duration-200 group relative ${
              activeTab === item.id 
                ? 'text-white shadow-xl shadow-red-900/20 scale-[1.02]' 
                : 'text-gray-500 hover:bg-gray-50 hover:text-gray-900'
            }`}
            style={activeTab === item.id ? { backgroundColor: PRIMARY_COLOR } : {}}
          >
            <div className={`p-2 rounded-xl mr-3 ${
              activeTab === item.id 
                ? 'bg-white/20 text-white' 
                : 'bg-gray-50 text-gray-400 group-hover:bg-gray-100 group-hover:text-gray-600'
            }`}>
              {item.icon}
            </div>
            <div className="text-left flex-1">
              <div className={`font-bold text-sm leading-tight ${activeTab === item.id ? 'text-white' : 'text-gray-700'}`}>
                {item.label}
              </div>
              <div className={`text-[10px] font-medium ${activeTab === item.id ? 'text-white/70' : 'text-gray-400'}`}>
                {item.subtitle}
              </div>
            </div>
            {activeTab === item.id && (
              <ChevronRight size={14} className="text-white/60 ml-2" />
            )}
          </button>
        ))}
      </nav>
      <div className="h-20" />
    </div>
  );
};

export default Sidebar;
