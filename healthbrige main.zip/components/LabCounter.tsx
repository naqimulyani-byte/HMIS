
import React, { useState } from 'react';
import { Beaker, Search, Plus, Calendar, Filter, X, Check, Printer, User, CreditCard, ChevronRight } from 'lucide-react';
import { PRIMARY_COLOR, PANEL_CATEGORIES } from '../constants';

interface TestParameter {
  id: string;
  name: string;
  type: string;
  unit: string;
  min: string;
  max: string;
}

interface Test {
  id: string;
  name: string;
  fee: number;
  isActive: boolean;
  parameters: TestParameter[];
}

interface LabOrder {
  id: string;
  receiptNo: string;
  trxNo: string;
  mrNo: string;
  patientName: string;
  tests: string[];
  panel: string;
  grossAmount: number;
  discount: number;
  netAmount: number;
  date: string;
  status: 'Pending' | 'Paid';
}

interface LabCounterProps {
  availableTests: Test[];
}

const LabCounter: React.FC<LabCounterProps> = ({ availableTests }) => {
  const [orders, setOrders] = useState<LabOrder[]>([
    {
      id: 'o1',
      receiptNo: 'LR2601020001',
      trxNo: 'LT2601020001',
      mrNo: '2601010003',
      patientName: 'HAROON',
      tests: ['CBC', 'LFT'],
      panel: 'Paying',
      grossAmount: 1900,
      discount: 0,
      netAmount: 1900,
      date: '02/01/2026 09:19 PM',
      status: 'Paid'
    }
  ]);

  const [showOrderModal, setShowOrderModal] = useState(false);
  const [modalStep, setModalStep] = useState<'search' | 'select'>('search');
  const [searchQuery, setSearchQuery] = useState('');
  const [orderSearchQuery, setOrderSearchQuery] = useState('');
  const [testSearchQuery, setTestSearchQuery] = useState('');
  
  // New Order State
  const [selectedPatient, setSelectedPatient] = useState<any>(null);
  const [selectedTests, setSelectedTests] = useState<string[]>([]);
  const [selectedPanel, setSelectedPanel] = useState(PANEL_CATEGORIES[3]); // Default: Paying

  // Mock registered patients
  const registeredPatients = [
    { id: '1', mrNo: '2601010003', name: 'HAROON', gender: 'Male', age: '5 Years', dept: 'Eye OPD', time: '01/01/2026 02:21 PM' },
    { id: '2', mrNo: '2601010002', name: 'SAIF ULLAH', gender: 'Male', age: '25 Years', dept: 'Pediatrics OPD', time: '01/01/2026 02:04 PM' },
  ];

  const handlePatientSelect = (patient: any) => {
    setSelectedPatient(patient);
    setModalStep('select');
  };

  const toggleTest = (testId: string) => {
    setSelectedTests(prev => 
      prev.includes(testId) ? prev.filter(id => id !== testId) : [...prev, testId]
    );
  };

  const calculateTotals = () => {
    const gross = selectedTests.reduce((acc, testId) => {
      const test = availableTests.find(t => t.id === testId);
      return acc + (test?.fee || 0);
    }, 0);
    const discountAmount = Math.round((gross * selectedPanel.discount) / 100);
    const net = gross - discountAmount;
    return { gross, discountAmount, net };
  };

  const handleFinalizeOrder = () => {
    const { gross, discountAmount, net } = calculateTotals();
    const now = new Date();
    const formattedDate = now.toLocaleDateString('en-GB') + ' ' + now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: true });
    
    const count = orders.length + 1;
    const newOrder: LabOrder = {
      id: Math.random().toString(36).substr(2, 9),
      receiptNo: `LR260102${String(count).padStart(4, '0')}`,
      trxNo: `LT260102${String(count).padStart(4, '0')}`,
      mrNo: selectedPatient.mrNo,
      patientName: selectedPatient.name,
      tests: selectedTests.map(id => availableTests.find(t => t.id === id)?.name || ''),
      panel: selectedPanel.name,
      grossAmount: gross,
      discount: discountAmount,
      netAmount: net,
      date: formattedDate,
      status: 'Paid'
    };

    setOrders([newOrder, ...orders]);
    triggerReceiptPrint(newOrder);
    resetOrderForm();
    setShowOrderModal(false);
  };

  const resetOrderForm = () => {
    setSelectedPatient(null);
    setSelectedTests([]);
    setSelectedPanel(PANEL_CATEGORIES[3]);
    setOrderSearchQuery('');
    setTestSearchQuery('');
    setModalStep('search');
  };

  const triggerReceiptPrint = (order: LabOrder) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    const html = `
      <html>
        <head>
          <title>Lab Receipt - ${order.receiptNo}</title>
          <style>
            @page { size: 80mm 200mm; margin: 0; }
            body { font-family: 'Courier New', Courier, monospace; width: 70mm; margin: 5mm; font-size: 12px; }
            .center { text-align: center; }
            .header { border-bottom: 1px dashed #000; padding-bottom: 5px; margin-bottom: 10px; }
            .row { display: flex; justify-content: space-between; margin: 2px 0; }
            .bold { font-weight: bold; }
            .divider { border-top: 1px dashed #000; margin: 5px 0; }
            .total-section { font-weight: bold; margin-top: 10px; }
          </style>
        </head>
        <body onload="window.print(); window.close();">
          <div class="header center">
            <div class="bold">DHQ HOSPITAL SUDHNUTI</div>
            <div>LABORATORY RECEIPT</div>
            <div class="divider"></div>
          </div>
          <div class="row"><span>Receipt#</span> <span class="bold">${order.receiptNo}</span></div>
          <div class="row"><span>Patient</span> <span class="bold">${order.patientName}</span></div>
          <div class="row total-section"><span>NET:</span> <span>Rs. ${order.netAmount}</span></div>
        </body>
      </html>
    `;
    printWindow.document.write(html);
    printWindow.document.close();
  };

  const filteredOrders = orders.filter(o => 
    o.patientName.toLowerCase().includes(searchQuery.toLowerCase()) || 
    o.mrNo.includes(searchQuery) || 
    o.receiptNo.includes(searchQuery)
  );

  const filteredPatients = registeredPatients.filter(p => 
    p.name.toLowerCase().includes(orderSearchQuery.toLowerCase()) || 
    p.mrNo.includes(orderSearchQuery)
  );

  // Show only active tests in the counter
  const activeTests = availableTests.filter(t => t.isActive);
  
  const filteredTestsInModal = activeTests.filter(t => 
    t.name.toLowerCase().includes(testSearchQuery.toLowerCase())
  );

  const currentTotals = calculateTotals();

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center bg-white p-4 rounded-2xl shadow-sm border border-gray-100 sticky top-20 z-10">
        <div className="flex items-center space-x-4 flex-1">
          <div className="relative flex-1 max-w-md">
            <input 
              type="text" 
              placeholder="Search by Name, MR, or Receipt..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:border-red-800 outline-none"
            />
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
          </div>
          <select className="bg-gray-50 border border-gray-200 rounded-xl px-4 py-2.5 text-sm font-medium outline-none">
            <option>All Panels</option>
            {PANEL_CATEGORIES.map(p => <option key={p.id}>{p.name}</option>)}
          </select>
          <div className="flex items-center space-x-1 bg-gray-50 border border-gray-200 rounded-xl px-2 py-1.5">
             <Calendar size={14} className="text-gray-400 ml-1" />
             <input type="date" defaultValue="2026-02-01" className="bg-transparent text-xs p-1 outline-none font-bold" />
             <span className="text-gray-400">-</span>
             <input type="date" defaultValue="2026-02-01" className="bg-transparent text-xs p-1 outline-none font-bold" />
          </div>
        </div>
        <button 
          onClick={() => { resetOrderForm(); setShowOrderModal(true); }}
          className="ml-4 flex items-center space-x-2 px-8 py-3 rounded-xl bg-white border-2 border-[#8B0000] text-[#8B0000] font-black uppercase tracking-widest transition-all active:scale-95 shadow-xl shadow-red-900/5 hover:bg-red-50"
        >
          <Plus size={18} />
          <span>New Order</span>
        </button>
      </div>

      {/* Stats Summary Panel */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {PANEL_CATEGORIES.slice(0, 4).map(cat => (
          <div key={cat.id} className={`bg-white border-l-4 rounded-xl shadow-sm p-4 ${cat.color} transition-transform hover:scale-[1.02]`}>
            <div className="flex justify-between mb-3">
              <span className="text-[10px] font-black uppercase text-slate-500 tracking-wider">{cat.name}</span>
              <span className={`text-[10px] px-2.5 py-0.5 rounded-md font-black ${cat.badge}`}>
                {orders.filter(o => o.panel === cat.name).length}
              </span>
            </div>
            <div className="space-y-1 text-xs">
               <div className="flex justify-between text-gray-500 font-bold"><span>Gross</span><span className="text-gray-800 font-black">{orders.filter(o => o.panel === cat.name).reduce((acc, curr) => acc + curr.grossAmount, 0).toLocaleString()}</span></div>
               <div className="flex justify-between text-sm font-black text-red-800 border-t border-slate-50 pt-1 mt-2"><span>NET</span><span>{orders.filter(o => o.panel === cat.name).reduce((acc, curr) => acc + curr.netAmount, 0).toLocaleString()}</span></div>
            </div>
          </div>
        ))}
      </div>

      {/* Orders List */}
      <div className="space-y-3">
        {filteredOrders.length > 0 ? (
          filteredOrders.map(order => (
            <div key={order.id} className="bg-white rounded-xl border border-gray-100 shadow-sm p-4 flex items-center justify-between group hover:border-red-100 transition-all">
               <div className="flex-1">
                 <h4 className="font-black text-gray-800 text-lg uppercase leading-none mb-1">{order.patientName}</h4>
                 <div className="text-[11px] font-bold text-gray-400 uppercase tracking-tighter">MR: {order.mrNo} &bull; {order.date}</div>
               </div>
               <div className="flex items-center space-x-12 shrink-0">
                 <div className="flex flex-col"><span className="text-[10px] font-black text-gray-400 uppercase leading-none mb-1">Receipt No</span><span className="text-xs font-black text-[#8B0000] tracking-tight">{order.receiptNo}</span></div>
                 <div className="flex items-center space-x-1.5 px-3 py-1 bg-green-50 text-green-600 rounded-full border border-green-100"><div className="w-1.5 h-1.5 rounded-full bg-green-500" /><span className="text-[10px] font-black uppercase tracking-widest">Paid</span></div>
                 <div className="text-right"><div className="text-base font-black text-gray-800 leading-none">{order.netAmount}</div></div>
                 <button onClick={() => triggerReceiptPrint(order)} className="w-10 h-10 rounded-lg border-2 border-red-800 text-red-800 flex items-center justify-center hover:bg-red-800 hover:text-white transition-all active:scale-95"><Printer size={18} /></button>
               </div>
            </div>
          ))
        ) : (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200/60 p-20 flex flex-col items-center justify-center text-center"><Beaker size={48} className="text-slate-200 mb-6" /><h3 className="text-xl font-black text-gray-800 uppercase tracking-tight">No Orders Found</h3></div>
        )}
      </div>

      {/* New Order Modal */}
      {showOrderModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
           <div className="bg-white rounded-2xl shadow-2xl w-full max-w-xl overflow-hidden animate-in zoom-in duration-200 flex flex-col max-h-[90vh]">
              <div className="bg-[#8B0000] p-4 flex justify-between items-center text-white shrink-0">
                 <h4 className="font-black text-lg tracking-tight uppercase">New Lab Order</h4>
                 <button onClick={() => setShowOrderModal(false)} className="text-white/80 hover:text-white transition-colors"><X size={24} /></button>
              </div>

              <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
                {modalStep === 'search' ? (
                  <div className="space-y-4">
                    <div className="relative"><input type="text" placeholder="Search Patient..." value={orderSearchQuery} autoFocus onChange={(e) => setOrderSearchQuery(e.target.value)} className="w-full px-10 py-3 rounded-lg border border-gray-300 focus:border-[#8B0000] outline-none text-sm font-bold" /><Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /></div>
                    <div className="space-y-3">
                      {orderSearchQuery.length > 0 && filteredPatients.map(p => (
                        <div key={p.id} className="p-4 border border-gray-100 rounded-lg shadow-sm bg-white flex justify-between items-center hover:border-red-800 transition-all">
                           <div><div className="font-black text-gray-800 text-base uppercase leading-none mb-1">{p.name}</div><div className="text-[11px] font-bold text-gray-500">MR#: {p.mrNo}</div></div>
                           <button onClick={() => handlePatientSelect(p)} className="bg-white border-2 border-red-800 text-red-800 p-2.5 rounded-lg"><Plus size={18} /></button>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-5">
                    <div className="bg-[#FFF5F5] border border-red-100 rounded-xl p-4 flex justify-between items-center">
                       <div className="flex items-center space-x-3"><div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-red-800"><User size={20} /></div><div><h5 className="font-black text-gray-800 uppercase leading-none mb-1">{selectedPatient.name}</h5><div className="text-[11px] font-bold text-gray-500">MR#: {selectedPatient.mrNo}</div></div></div>
                       <button onClick={() => setModalStep('search')} className="text-[#8B0000] font-bold text-xs uppercase underline">Change</button>
                    </div>
                    <div className="space-y-2">
                       <div className="flex justify-between items-center"><label className="text-[11px] font-black text-red-800 uppercase">Select Lab Tests</label><div className="relative"><input type="text" placeholder="Search..." value={testSearchQuery} onChange={(e) => setTestSearchQuery(e.target.value)} className="text-[10px] px-8 py-1.5 border border-gray-300 rounded-md focus:border-[#8B0000] outline-none" /><Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" /></div></div>
                       <div className="border border-gray-200 rounded-lg overflow-hidden max-h-[250px] overflow-y-auto custom-scrollbar">
                          {filteredTestsInModal.map(test => {
                             const isChecked = selectedTests.includes(test.id);
                             return (
                               <label key={test.id} className="flex items-center justify-between p-3 hover:bg-gray-50 cursor-pointer border-b border-gray-50 last:border-none">
                                  <div className="flex items-center"><input type="checkbox" checked={isChecked} onChange={() => toggleTest(test.id)} className="w-4 h-4 rounded border-gray-300 text-red-800" /><span className={`ml-3 text-xs font-bold uppercase ${isChecked ? 'text-red-800' : 'text-gray-600'}`}>{test.name}</span></div>
                                  <span className="text-[11px] font-bold text-gray-400">Rs. {test.fee}</span>
                               </label>
                             );
                          })}
                          {filteredTestsInModal.length === 0 && (
                            <div className="p-10 text-center text-[10px] font-black uppercase text-gray-400 tracking-widest">
                               No active tests found.
                            </div>
                          )}
                       </div>
                    </div>
                    <div className="bg-[#FFF5F5] border border-red-100 rounded-lg p-3 flex justify-between items-center"><div className="text-[11px] font-black text-[#8B0000] uppercase">{selectedTests.length} selected</div><div className="text-[12px] font-black text-[#8B0000] uppercase">Total: Rs. {currentTotals.net.toLocaleString()}</div></div>
                  </div>
                )}
              </div>

              <div className="p-4 border-t border-gray-100 shrink-0 bg-white">
                <div className="flex justify-end space-x-3">
                   <button onClick={() => setShowOrderModal(false)} className="px-6 py-2.5 rounded-lg border-2 border-gray-200 text-gray-400 font-bold text-xs uppercase tracking-widest hover:bg-gray-50">Cancel</button>
                   <button onClick={handleFinalizeOrder} disabled={modalStep === 'search' || selectedTests.length === 0} className={`px-8 py-2.5 rounded-lg font-black text-xs uppercase border-2 tracking-widest transition-all ${modalStep === 'search' || selectedTests.length === 0 ? 'bg-gray-50 text-gray-300 border-gray-200' : 'bg-white border-[#8B0000] text-[#8B0000] hover:bg-red-50'}`}>Add Order</button>
                </div>
              </div>
           </div>
        </div>
      )}
      
      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #f8fafc; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #cbd5e0; }
      `}</style>
    </div>
  );
};

export default LabCounter;
