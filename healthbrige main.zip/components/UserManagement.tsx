
import React, { useState, useMemo } from 'react';
import { Users, Search, Edit2, Trash2, Power, UserPlus, X, Key, Shield, User as UserIcon } from 'lucide-react';
import { PRIMARY_COLOR } from '../constants';
import { Role, User } from '../types';

interface UserManagementProps {
  roles: Role[];
}

const UserManagement: React.FC<UserManagementProps> = ({ roles }) => {
  // Pre-load the Super Admin in the list
  const [users, setUsers] = useState<User[]>([
    { id: 'super-admin', fullName: 'Administrator', fatherName: 'System', cnic: '00000-0000000-0', role: 'Admin', designation: 'Super User', contact: '00000000000', address: 'Hospital Server', isActive: true },
    { id: '1', fullName: 'Ahsan', fatherName: 'Ali', cnic: '22222-2222222-2', role: 'Counter', designation: 'SE', contact: '03000057234', address: 'NHM', isActive: true },
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<User>>({
    fullName: '',
    fatherName: '',
    cnic: '',
    designation: '',
    contact: '',
    address: '',
    role: 'Counter',
    password: ''
  });

  const filteredUsers = useMemo(() => {
    return users.filter(u => 
      u.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      u.cnic.includes(searchQuery)
    );
  }, [users, searchQuery]);

  const handleEdit = (user: User) => {
    setEditingId(user.id);
    setFormData({
      fullName: user.fullName,
      fatherName: user.fatherName || '',
      cnic: user.cnic,
      designation: user.designation || '',
      contact: user.contact || '',
      address: user.address || '',
      role: user.role,
      password: ''
    });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setFormData({
      fullName: '', fatherName: '', cnic: '', designation: '', contact: '', address: '', role: 'Counter', password: ''
    });
  };

  const handleToggleStatus = (id: string) => {
    if (id === 'super-admin') return; // Cannot disable super admin
    setUsers(prev => prev.map(u => u.id === id ? { ...u, isActive: !u.isActive } : u));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName || !formData.cnic) {
      alert('Full Name and CNIC are required.');
      return;
    }

    if (editingId) {
      setUsers(prev => prev.map(u => u.id === editingId ? { ...u, ...formData as User } : u));
    } else {
      const newUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        ...(formData as Omit<User, 'id' | 'isActive'>),
        isActive: true
      } as User;
      setUsers(prev => [...prev, newUser]);
    }
    handleCancelEdit();
  };

  const handleDelete = (id: string) => {
    if (id === 'super-admin') {
      alert('Critical Error: Cannot delete the Super Admin account.');
      return;
    }
    if (window.confirm('Delete this user permanently?')) {
      setUsers(prev => prev.filter(u => u.id !== id));
      if (editingId === id) handleCancelEdit();
    }
  };

  return (
    <div className="p-6 max-w-[1600px] mx-auto flex flex-col lg:flex-row gap-6 h-[calc(100vh-120px)]">
      
      {/* Left Column: System Users List */}
      <div className="w-full lg:w-[450px] flex flex-col space-y-4 h-full shrink-0">
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 flex flex-col h-full overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-sm font-black text-[#8B0000] uppercase tracking-tight flex items-center">
              <Users size={18} className="mr-2" />
              Staff Accounts
            </h3>
          </div>
          
          <div className="p-4 border-b border-slate-50 bg-slate-50/30">
            <div className="relative">
              <input 
                type="text" 
                placeholder="Search staff..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white focus:border-[#8B0000] outline-none text-sm font-medium shadow-sm transition-all"
              />
              <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-300" />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar bg-slate-50/10">
            {filteredUsers.map((user) => (
              <div 
                key={user.id}
                className={`p-5 rounded-2xl border-2 transition-all group relative bg-white ${
                  editingId === user.id ? 'border-[#8B0000] shadow-md' : 'border-transparent hover:border-slate-200 shadow-sm'
                }`}
              >
                <div className="flex justify-between items-start">
                  <div className="space-y-1.5 min-w-0 flex-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-black text-slate-800 text-sm uppercase truncate">{user.fullName}</span>
                      <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-widest ${
                        user.role === 'Admin' ? 'bg-purple-50 text-purple-600' : 'bg-orange-50 text-orange-600'
                      }`}>
                        {user.role}
                      </span>
                    </div>
                    <div className="flex flex-col text-[10px] font-bold text-slate-400 uppercase tracking-tight leading-none space-y-1">
                      <span>CNIC: {user.cnic}</span>
                      {user.designation && <span>{user.designation}</span>}
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2 shrink-0">
                    <button 
                      onClick={() => handleEdit(user)}
                      className="p-1.5 text-slate-300 hover:text-blue-500 transition-colors"
                    >
                      <Edit2 size={14} />
                    </button>
                    {user.id !== 'super-admin' && (
                      <>
                        <button 
                          onClick={() => handleToggleStatus(user.id)}
                          className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase transition-all ${
                            user.isActive 
                            ? 'bg-green-50 text-green-600 hover:bg-green-100' 
                            : 'bg-slate-100 text-slate-400 hover:bg-slate-200'
                          }`}
                        >
                          {user.isActive ? 'Active' : 'Locked'}
                        </button>
                        <button onClick={() => handleDelete(user.id)} className="p-1.5 text-slate-300 hover:text-red-500 transition-colors">
                          <Trash2 size={14} />
                        </button>
                      </>
                    )}
                    {user.id === 'super-admin' && (
                      <div className="px-3 py-1 bg-slate-100 text-slate-400 rounded-lg text-[9px] font-black uppercase">Protected</div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right Column: Edit/Add User Account Form */}
      <div className="flex-1 flex flex-col space-y-4 h-full overflow-hidden">
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 flex flex-col h-full overflow-hidden">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-sm font-black text-[#8B0000] uppercase tracking-tight flex items-center">
              <Edit2 size={18} className="mr-2" />
              {editingId ? 'Update Profile' : 'Register New Staff Member'}
            </h3>
            {editingId && (
              <button onClick={handleCancelEdit} className="text-[10px] font-black text-red-600 bg-red-50 px-3 py-1 rounded-full uppercase hover:bg-red-100">
                <X size={12} className="mr-1" /> Close Edit
              </button>
            )}
          </div>

          <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-8 custom-scrollbar">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">CNIC No. *</label>
                <input type="text" value={formData.cnic} onChange={e => setFormData({...formData, cnic: e.target.value})} placeholder="00000-0000000-0" className="w-full px-5 py-3.5 rounded-2xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner" />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Password</label>
                <input type="password" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} placeholder="Set login password" className="w-full px-5 py-3.5 rounded-2xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner" />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Full Name *</label>
                <input type="text" value={formData.fullName} onChange={e => setFormData({...formData, fullName: e.target.value})} placeholder="Full Name" className="w-full px-5 py-3.5 rounded-2xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner" />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Role Type *</label>
                <select value={formData.role} onChange={e => setFormData({...formData, role: e.target.value})} className="w-full px-5 py-3.5 rounded-2xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold bg-white">
                  {roles.map(role => (
                    <option key={role.id} value={role.name}>{role.name}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Designation</label>
                <input type="text" value={formData.designation} onChange={e => setFormData({...formData, designation: e.target.value})} placeholder="e.g. Counter In-charge" className="w-full px-5 py-3.5 rounded-2xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner" />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Cell No.</label>
                <input type="text" value={formData.contact} onChange={e => setFormData({...formData, contact: e.target.value})} placeholder="Contact #" className="w-full px-5 py-3.5 rounded-2xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner" />
              </div>
            </div>

            <div className="mt-12 flex justify-end">
              <button type="submit" className="px-10 py-4 rounded-2xl bg-[#8B0000] text-white font-black text-xs uppercase tracking-widest shadow-2xl active:scale-95 transition-all flex items-center justify-center space-x-3">
                <Shield size={16} />
                <span>{editingId ? 'Save Profile' : 'Authorize & Register'}</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default UserManagement;
