
import React, { useState, useMemo } from 'react';
import { Beaker, Search, Trash2, Edit2, Plus, X, Settings, Power, Save, Check, AlertCircle, ChevronRight } from 'lucide-react';
import { PRIMARY_COLOR } from '../constants';

interface Parameter {
  id: string;
  name: string;
  type: string;
  unit: string;
  min: string;
  max: string;
}

interface Test {
  id: string;
  name: string;
  fee: number;
  isActive: boolean;
  parameters: Parameter[];
}

interface LabTestSetupProps {
  tests: Test[];
  setTests: React.Dispatch<React.SetStateAction<Test[]>>;
}

const LabTestSetup: React.FC<LabTestSetupProps> = ({ tests, setTests }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingTestId, setEditingTestId] = useState<string | null>(null);
  const [showParamModal, setShowParamModal] = useState(false);
  const [selectedTestForParams, setSelectedTestForParams] = useState<Test | null>(null);

  // Form states
  const [testForm, setTestForm] = useState({ name: '', fee: '' });
  const [paramForm, setParamForm] = useState({ name: '', type: 'Numeric Value', unit: '', min: '', max: '' });

  const filteredTests = useMemo(() => {
    return tests.filter(t => t.name.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [tests, searchQuery]);

  const handleSaveTest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!testForm.name || !testForm.fee) return;

    if (editingTestId) {
      setTests(prev => prev.map(t => t.id === editingTestId ? { ...t, name: testForm.name, fee: Number(testForm.fee) } : t));
      setEditingTestId(null);
    } else {
      const newTest: Test = {
        id: Math.random().toString(36).substr(2, 9),
        name: testForm.name,
        fee: Number(testForm.fee),
        isActive: true,
        parameters: []
      };
      setTests(prev => [...prev, newTest]);
    }
    setTestForm({ name: '', fee: '' });
  };

  const handleToggleActive = (id: string) => {
    setTests(prev => prev.map(t => t.id === id ? { ...t, isActive: !t.isActive } : t));
  };

  const handleDeleteTest = (id: string) => {
    if (window.confirm('Are you sure you want to delete this test permanently?')) {
      setTests(prev => prev.filter(t => t.id !== id));
      
      // Clear editing state if the deleted test was being edited
      if (editingTestId === id) {
        setEditingTestId(null);
        setTestForm({ name: '', fee: '' });
      }

      // Close parameter modal if the deleted test was open
      if (selectedTestForParams?.id === id) {
        setShowParamModal(false);
        setSelectedTestForParams(null);
      }
    }
  };

  const openParamSetup = (test: Test) => {
    setSelectedTestForParams(test);
    setShowParamModal(true);
  };

  const handleAddParameter = () => {
    if (!paramForm.name || !selectedTestForParams) return;
    const newParam: Parameter = {
      ...paramForm,
      id: Math.random().toString(36).substr(2, 9)
    };
    
    const updatedTest = {
      ...selectedTestForParams,
      parameters: [...selectedTestForParams.parameters, newParam]
    };

    setTests(prev => prev.map(t => t.id === updatedTest.id ? updatedTest : t));
    setSelectedTestForParams(updatedTest);
    setParamForm({ name: '', type: 'Numeric Value', unit: '', min: '', max: '' });
  };

  const handleDeleteParam = (paramId: string) => {
    if (!selectedTestForParams) return;
    const updatedParams = selectedTestForParams.parameters.filter(p => p.id !== paramId);
    const updatedTest = { ...selectedTestForParams, parameters: updatedParams };
    
    setTests(prev => prev.map(t => t.id === updatedTest.id ? updatedTest : t));
    setSelectedTestForParams(updatedTest);
  };

  return (
    <div className="p-4 md:p-6 max-w-[1600px] mx-auto flex flex-col lg:flex-row gap-6">
      
      {/* Left Column: Test List */}
      <div className="flex-1 space-y-4">
        <div className="flex items-center space-x-2">
          <Beaker size={20} className="text-[#8B0000]" />
          <h3 className="text-lg font-black text-[#8B0000] uppercase tracking-tight">Lab Tests</h3>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-4 border-b border-slate-50">
            <div className="relative">
              <input 
                type="text" 
                placeholder="Search tests..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:border-[#8B0000] outline-none text-sm font-medium transition-all"
              />
              <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-300" />
            </div>
          </div>

          <div className="divide-y divide-slate-50 max-h-[calc(100vh-300px)] overflow-y-auto custom-scrollbar">
            {filteredTests.map((test) => (
              <div key={test.id} className="p-4 hover:bg-slate-50/50 transition-colors flex items-center justify-between group">
                <div className="flex items-center space-x-4">
                  <h4 className={`font-bold text-sm uppercase ${!test.isActive ? 'text-slate-300' : 'text-slate-700'}`}>
                    {test.name}
                  </h4>
                  <span className={`text-[10px] font-black tracking-tight ${!test.isActive ? 'text-slate-200' : 'text-red-800'}`}>
                    Rs. {test.fee}
                  </span>
                  <span className="bg-slate-100 text-slate-400 text-[9px] font-black px-2 py-0.5 rounded uppercase">
                    {test.parameters.length} params
                  </span>
                </div>

                <div className="flex items-center space-x-1">
                  <button 
                    onClick={() => openParamSetup(test)}
                    className="p-2 text-slate-400 hover:text-slate-600 hover:bg-white rounded-lg transition-all active:scale-90"
                    title="Setup Parameters"
                  >
                    <Settings size={18} />
                  </button>
                  <button 
                    onClick={() => handleToggleActive(test.id)}
                    className={`p-2 rounded-lg transition-all active:scale-90 ${test.isActive ? 'text-green-500 hover:bg-green-50' : 'text-slate-300 hover:bg-slate-100'}`}
                    title={test.isActive ? 'Deactivate' : 'Activate'}
                  >
                    <Power size={18} />
                  </button>
                  <button 
                    onClick={() => {
                      setEditingTestId(test.id);
                      setTestForm({ name: test.name, fee: test.fee.toString() });
                    }}
                    className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition-all active:scale-90"
                    title="Edit Test"
                  >
                    <Edit2 size={18} />
                  </button>
                  <button 
                    onClick={() => handleDeleteTest(test.id)}
                    className="p-2 text-slate-300 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all active:scale-90"
                    title="Delete Test"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>
            ))}
            {filteredTests.length === 0 && (
              <div className="p-10 text-center text-slate-400 text-xs font-bold uppercase tracking-widest">
                No tests found matching your search.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Right Column: Add/Edit Form */}
      <div className="w-full lg:w-96 shrink-0">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden sticky top-24">
          <div className="p-5 border-b border-slate-100 bg-slate-50/50">
            <h3 className="text-base font-black text-[#8B0000] uppercase tracking-tight">
              {editingTestId ? 'Edit Test' : 'Add New Test'}
            </h3>
          </div>
          
          <form onSubmit={handleSaveTest} className="p-6 space-y-6">
            <div className="space-y-1 relative">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Test Name</label>
              <input 
                type="text" 
                value={testForm.name}
                onChange={(e) => setTestForm({...testForm, name: e.target.value})}
                placeholder="e.g. CBC, Lipid Profile"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner" 
              />
            </div>

            <div className="space-y-1 relative">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Fee (Rs.)</label>
              <input 
                type="number" 
                value={testForm.fee}
                onChange={(e) => setTestForm({...testForm, fee: e.target.value})}
                placeholder="0"
                className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner" 
              />
            </div>

            <div className="flex gap-3 pt-4">
              {editingTestId && (
                <button 
                  type="button"
                  onClick={() => { setEditingTestId(null); setTestForm({ name: '', fee: '' }); }}
                  className="flex-1 py-3.5 rounded-xl border-2 border-slate-100 text-slate-400 font-black text-xs uppercase tracking-widest hover:bg-slate-50 transition-all"
                >
                  Cancel
                </button>
              )}
              <button 
                type="submit"
                className="flex-[2] py-3.5 rounded-xl bg-[#8B0000] text-white font-black text-xs uppercase tracking-widest shadow-xl shadow-red-900/20 active:scale-95 transition-all flex items-center justify-center space-x-3"
              >
                {editingTestId ? <Check size={16} /> : <Plus size={16} />}
                <span>{editingTestId ? 'Update' : 'Add Test'}</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Parameter Setup Modal */}
      {showParamModal && selectedTestForParams && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
           <div className="bg-white rounded-3xl shadow-2xl w-full max-w-4xl overflow-hidden animate-in zoom-in duration-200 flex flex-col max-h-[90vh]">
              <div className="bg-[#8B0000] p-5 flex justify-between items-center text-white shrink-0">
                 <h4 className="font-black text-lg tracking-tight uppercase">Setup Parameters</h4>
                 <button onClick={() => setShowParamModal(false)} className="hover:bg-white/10 p-1.5 rounded-full transition-colors">
                    <X size={24} />
                 </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 md:p-8 custom-scrollbar">
                <div className="mb-8 border-b border-slate-100 pb-6 flex justify-between items-end">
                   <div>
                      <h2 className="text-2xl font-black text-slate-800 uppercase leading-none">{selectedTestForParams.name}</h2>
                      <p className="text-[10px] font-black text-red-800 uppercase tracking-[0.2em] mt-2">Manage Result Parameters</p>
                   </div>
                   <div className="text-right">
                      <span className="text-xl font-black text-slate-800">Rs. {selectedTestForParams.fee}</span>
                   </div>
                </div>

                {/* Add New Parameter Form */}
                <div className="bg-slate-50/50 rounded-2xl p-6 border border-slate-100 mb-8">
                   <div className="flex items-center space-x-2 mb-6">
                      <Plus size={14} className="text-[#8B0000]" />
                      <h5 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Add New Parameter</h5>
                   </div>
                   <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
                      <div className="md:col-span-4 space-y-1">
                         <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest pl-1">Parameter Name</label>
                         <input 
                           type="text" 
                           value={paramForm.name}
                           onChange={(e) => setParamForm({...paramForm, name: e.target.value})}
                           placeholder="e.g. Hemoglobin" 
                           className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-xs font-bold focus:border-[#8B0000] outline-none shadow-sm" 
                         />
                      </div>
                      <div className="md:col-span-3 space-y-1">
                         <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest pl-1">Result Type</label>
                         <select 
                           value={paramForm.type}
                           onChange={(e) => setParamForm({...paramForm, type: e.target.value})}
                           className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-xs font-bold focus:border-[#8B0000] outline-none shadow-sm appearance-none"
                         >
                            <option>Numeric Value</option>
                            <option>Textual Result</option>
                            <option>Selection List</option>
                         </select>
                      </div>
                      <div className="md:col-span-2 space-y-1">
                         <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest pl-1">Unit</label>
                         <input 
                           type="text" 
                           value={paramForm.unit}
                           onChange={(e) => setParamForm({...paramForm, unit: e.target.value})}
                           placeholder="g/dL" 
                           className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-xs font-bold focus:border-[#8B0000] outline-none shadow-sm" 
                         />
                      </div>
                      <div className="md:col-span-1 space-y-1">
                         <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest pl-1">Min</label>
                         <input 
                           type="text" 
                           value={paramForm.min}
                           onChange={(e) => setParamForm({...paramForm, min: e.target.value})}
                           placeholder="Min" 
                           className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-xs font-bold focus:border-[#8B0000] outline-none shadow-sm text-center" 
                         />
                      </div>
                      <div className="md:col-span-1 space-y-1">
                         <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest pl-1">Max</label>
                         <input 
                           type="text" 
                           value={paramForm.max}
                           onChange={(e) => setParamForm({...paramForm, max: e.target.value})}
                           placeholder="Max" 
                           className="w-full px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-xs font-bold focus:border-[#8B0000] outline-none shadow-sm text-center" 
                         />
                      </div>
                      <div className="md:col-span-1">
                         <button 
                           onClick={handleAddParameter}
                           className="w-full aspect-square rounded-xl bg-red-800/10 text-red-800 flex items-center justify-center hover:bg-red-800 hover:text-white transition-all active:scale-95 shadow-sm"
                         >
                            <Plus size={20} />
                         </button>
                      </div>
                   </div>
                </div>

                {/* Parameters List Table */}
                <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm">
                   <table className="w-full text-left">
                      <thead>
                         <tr className="bg-slate-50/50 border-b border-slate-100">
                            <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Parameter</th>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Type</th>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Details</th>
                            <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Actions</th>
                         </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                         {selectedTestForParams.parameters.map((param) => (
                            <tr key={param.id} className="hover:bg-slate-50/30 transition-colors group">
                               <td className="px-6 py-4 font-black text-slate-800 text-sm uppercase">{param.name}</td>
                               <td className="px-6 py-4">
                                  <span className="text-[9px] font-black text-blue-700 bg-blue-50 border border-blue-100 px-2.5 py-1 rounded-md uppercase tracking-wider">
                                     {param.type}
                                  </span>
                               </td>
                               <td className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-tight">
                                  {param.min} - {param.max} {param.unit}
                               </td>
                               <td className="px-6 py-4 text-right">
                                  <div className="flex items-center justify-end space-x-1">
                                     <button className="p-2 text-slate-300 hover:text-blue-500 rounded-lg transition-colors active:scale-90"><Edit2 size={16} /></button>
                                     <button onClick={() => handleDeleteParam(param.id)} className="p-2 text-slate-300 hover:text-red-500 rounded-lg transition-colors active:scale-90"><Trash2 size={16} /></button>
                                  </div>
                               </td>
                            </tr>
                         ))}
                         {selectedTestForParams.parameters.length === 0 && (
                            <tr>
                               <td colSpan={4} className="px-6 py-10 text-center text-slate-300 font-bold uppercase text-[10px] tracking-widest">
                                  No parameters defined for this test yet.
                               </td>
                            </tr>
                         )}
                      </tbody>
                   </table>
                </div>
              </div>

              <div className="p-6 border-t border-slate-100 shrink-0 bg-white">
                <div className="flex justify-end space-x-3">
                   <button 
                     onClick={() => setShowParamModal(false)}
                     className="px-8 py-3 rounded-xl border-2 border-slate-100 text-slate-400 font-black text-xs uppercase tracking-widest hover:bg-slate-50 transition-all"
                   >
                     Cancel
                   </button>
                   <button 
                     onClick={() => setShowParamModal(false)}
                     className="px-10 py-3 rounded-xl bg-[#8B0000] text-white font-black text-xs uppercase tracking-widest shadow-xl shadow-red-900/20 active:scale-95 transition-all"
                   >
                     Save Changes
                   </button>
                </div>
              </div>
           </div>
        </div>
      )}

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #E2E8F0; border-radius: 10px; }
      `}</style>
    </div>
  );
};

export default LabTestSetup;
