
import React, { useState, useRef } from 'react';
import { FileText, Search, Calendar, Settings, Printer, Download, X, QrCode, Check, Save, Activity } from 'lucide-react';
import { PRIMARY_COLOR } from '../constants';
import { HospitalConfig } from '../types';

interface SignatureSlot {
  id: number;
  enabled: boolean;
  fullName: string;
  qualification: string;
  designation: string;
  institution: string;
}

interface LabReportData {
  id: string;
  patientName: string;
  mrNo: string;
  receiptNo: string;
  orderDate: string;
  resultDate: string;
  printDate: string;
  age: string;
  gender: string;
  cellNo: string;
  tests: {
    name: string;
    results: {
      parameter: string;
      result: string;
      unit: string;
      refRange: string;
      flag?: 'up' | 'down';
    }[];
  }[];
}

interface LabReportsProps {
  hospitalConfig: HospitalConfig;
}

const LabReports: React.FC<LabReportsProps> = ({ hospitalConfig }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [hasSearched, setHasSearched] = useState(false);
  const [fromDate, setFromDate] = useState('2026-02-01');
  const [toDate, setToDate] = useState('2026-02-01');
  const [showFormatModal, setShowFormatModal] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [selectedReport, setSelectedReport] = useState<LabReportData | null>(null);
  const reportRef = useRef<HTMLDivElement>(null);

  const [signatureSlots, setSignatureSlots] = useState<SignatureSlot[]>([
    { id: 1, enabled: true, fullName: 'Dr. Sobia Rubab', qualification: 'MBBS, FCPS Paeds Medicine', designation: 'Professor', institution: 'Nishtar Medical University Multan' },
    { id: 2, enabled: false, fullName: '', qualification: '', designation: '', institution: '' },
    { id: 3, enabled: false, fullName: '', qualification: '', designation: '', institution: '' },
    { id: 4, enabled: false, fullName: '', qualification: '', designation: '', institution: '' },
  ]);

  const mockReports: LabReportData[] = [
    {
      id: 'rep1',
      patientName: 'HAROON',
      mrNo: '2601010003',
      receiptNo: 'LR2601020001',
      orderDate: '02/01/2026 09:19 PM',
      resultDate: '02/01/2026 09:32 PM',
      printDate: '02/01/2026 09:39 PM',
      age: '5 Years',
      gender: 'Male',
      cellNo: 'N/A',
      tests: [
        {
          name: 'Liver Function Test (LFT)',
          results: [
            { parameter: 'SGOT/AST', result: '10', unit: 'U/L', refRange: '0 - 40 U/L' },
            { parameter: 'SGPT/ALT', result: '30', unit: 'U/L', refRange: '0 - 40 U/L' },
            { parameter: 'Bilirubin Total', result: '1', unit: 'mg/dL', refRange: '0.1 - 1.2 mg/dL' },
          ]
        },
        {
          name: 'CBC',
          results: [
            { parameter: 'WBC', result: '100', unit: 'mgg', refRange: '1000 - 7000 mgg', flag: 'down' },
            { parameter: 'Hemoglobin', result: '12', unit: 'g/dL', refRange: '13 - 18 g/dL', flag: 'down' },
          ]
        }
      ]
    },
    {
       id: 'rep2',
       patientName: 'SAIF ULLAH',
       mrNo: '2601010002',
       receiptNo: 'LR2601010005',
       orderDate: '01/01/2026 10:15 AM',
       resultDate: '01/01/2026 11:30 AM',
       printDate: '01/01/2026 12:00 PM',
       age: '25 Years',
       gender: 'Male',
       cellNo: '0300-1234567',
       tests: [
         {
           name: 'Blood Glucose (R)',
           results: [
             { parameter: 'Blood Sugar', result: '105', unit: 'mg/dL', refRange: '70 - 110 mg/dL' }
           ]
         }
       ]
    }
  ];

  const handleSearch = () => {
    if (!searchQuery.trim()) return;
    setHasSearched(true);
  };

  const filteredReports = mockReports.filter(report => {
    const query = searchQuery.toLowerCase();
    return (
      report.patientName.toLowerCase().includes(query) ||
      report.mrNo.includes(query) ||
      report.receiptNo.toLowerCase().includes(query)
    );
  });

  const handleOpenReport = (report: LabReportData) => {
    setSelectedReport(report);
    setShowPreviewModal(true);
  };

  const toggleSignature = (id: number) => {
    setSignatureSlots(slots => slots.map(s => s.id === id ? { ...s, enabled: !s.enabled } : s));
  };

  const updateSignature = (id: number, field: keyof SignatureSlot, value: string) => {
    setSignatureSlots(slots => slots.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  const handleEnableAll = () => setSignatureSlots(slots => slots.map(s => ({ ...s, enabled: true })));
  const handleDisableAll = () => setSignatureSlots(slots => slots.map(s => ({ ...s, enabled: false })));

  const handlePrintReport = () => {
    if (!reportRef.current) return;
    const printContent = reportRef.current.innerHTML;
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Lab Investigation Report - ${selectedReport?.mrNo}</title>
            <style>
              @page { size: A4; margin: 0; }
              body { margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
              .print-container { width: 210mm; min-height: 297mm; padding: 15mm; margin: 0 auto; box-sizing: border-box; }
              table { width: 100%; border-collapse: collapse; margin-top: 10px; }
              th { text-align: left; padding: 8px; border-bottom: 2px solid #eee; font-size: 10px; text-transform: uppercase; color: #666; }
              td { padding: 8px; border-bottom: 1px solid #f5f5f5; font-size: 12px; }
              .header { display: flex; justify-content: space-between; border-bottom: 4px solid #333; padding-bottom: 15px; margin-bottom: 20px; }
              .patient-info { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; background: #f9f9f9; padding: 15px; border: 1px solid #eee; font-size: 11px; margin-bottom: 20px; }
              .test-title { background: #f5f5f5; padding: 8px; font-weight: bold; text-transform: uppercase; font-size: 12px; margin-top: 20px; }
              .signatures { margin-top: 50px; display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; }
              .sig-item { text-align: center; border-top: 1px solid #999; padding-top: 5px; font-size: 9px; }
            </style>
          </head>
          <body onload="window.print(); window.close();">
            <div class="print-container">${printContent}</div>
          </body>
        </html>
      `);
      printWindow.document.close();
    }
  };

  const handleDownloadPDF = () => {
    handlePrintReport();
  };

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center space-x-2 mb-6">
          <FileText size={20} className="text-[#8B0000]" />
          <h3 className="text-lg font-black text-[#8B0000] uppercase tracking-tight">Lab Reports</h3>
        </div>

        <div className="flex flex-wrap items-end gap-4">
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">From Date</label>
            <div className="relative">
              <input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm font-bold focus:border-[#8B0000] outline-none" />
              <Calendar size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">To Date</label>
            <div className="relative">
              <input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm font-bold focus:border-[#8B0000] outline-none" />
              <Calendar size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>
          </div>
          <div className="space-y-1.5 flex-1 min-w-[300px]">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Search</label>
            <div className="relative">
              <input type="text" placeholder="Search by Patient Name, MR#, or Receipt#" value={searchQuery} onChange={(e) => { setSearchQuery(e.target.value); if (e.target.value === '') setHasSearched(false); }} onKeyDown={(e) => e.key === 'Enter' && handleSearch()} className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm font-medium focus:border-[#8B0000] outline-none" />
              <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button onClick={handleSearch} className="px-10 py-2.5 rounded-xl bg-white border-2 border-[#8B0000] text-[#8B0000] font-black text-xs uppercase tracking-widest shadow-lg shadow-red-900/5 active:scale-95 transition-all hover:bg-red-50">Search</button>
            <button onClick={() => setShowFormatModal(true)} className="px-6 py-2.5 rounded-xl border-2 border-[#8B0000] bg-white text-[#8B0000] font-black text-xs uppercase tracking-widest hover:bg-red-50 flex items-center space-x-2 shadow-sm"><Settings size={16} /><span>Format</span></button>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        {!hasSearched ? (
            <div className="bg-white rounded-3xl p-20 flex flex-col items-center justify-center text-center border border-dashed border-gray-200">
                <Search size={48} className="text-slate-200 mb-6" />
                <h4 className="font-black text-gray-800 text-lg uppercase tracking-tight">Search Lab Reports</h4>
                <p className="text-slate-400 text-sm mt-2 max-w-xs font-medium uppercase tracking-tight">Enter Patient Name, MR#, or Receipt</p>
            </div>
        ) : filteredReports.length > 0 ? filteredReports.map(report => (
          <div key={report.id} className="bg-white rounded-xl border border-slate-100 p-5 flex items-center justify-between group hover:border-[#8B0000]/20 transition-all shadow-sm animate-in fade-in slide-in-from-bottom-2">
            <div className="flex-1 flex items-center gap-x-12">
              <div className="flex items-center space-x-4">
                <h4 className="font-black text-slate-800 text-lg uppercase tracking-tight">{report.patientName}</h4>
                <div className="bg-[#8B0000] text-white rounded-lg flex flex-col items-center justify-center px-4 py-1.5 min-w-[120px]">
                  <span className="text-[9px] font-black uppercase tracking-widest leading-none mb-1">MR#</span>
                  <span className="text-sm font-black tracking-tight">{report.mrNo}</span>
                </div>
              </div>
              <button onClick={() => handleOpenReport(report)} className="px-8 py-2.5 rounded-xl border-2 border-[#8B0000] bg-white text-[#8B0000] font-black text-xs uppercase tracking-widest hover:bg-red-50 transition-all active:scale-95 flex items-center space-x-2 shrink-0 ml-4"><FileText size={16} /><span>Report</span></button>
            </div>
          </div>
        )) : (
            <div className="bg-white rounded-3xl p-20 flex flex-col items-center justify-center text-center border border-dashed border-gray-200 animate-in fade-in">
                <Search size={48} className="text-slate-200 mb-6" />
                <h4 className="font-black text-gray-800 text-lg uppercase tracking-tight">No Reports Found</h4>
                <p className="text-slate-400 text-sm mt-2 max-w-xs font-medium uppercase tracking-tight">Search by name or MR# to list lab investigation reports</p>
                <button onClick={() => setHasSearched(false)} className="mt-4 text-[10px] font-black text-[#8B0000] uppercase tracking-widest hover:underline">Clear Search</button>
            </div>
        )}
      </div>

      {showPreviewModal && selectedReport && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-[110] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-5xl overflow-hidden flex flex-col h-[90vh]">
            <div className="bg-[#8B0000] p-4 flex justify-between items-center text-white shrink-0">
              <div className="flex items-center space-x-3">
                <FileText size={24} />
                <div>
                  <h4 className="font-black text-base uppercase tracking-tight">Lab Investigation Report</h4>
                  <p className="text-[10px] font-black uppercase tracking-widest opacity-80">{selectedReport.patientName} &bull; MR#: {selectedReport.mrNo}</p>
                </div>
              </div>
              <button onClick={() => setShowPreviewModal(false)} className="hover:bg-white/10 p-2 rounded-full transition-colors"><X size={24} /></button>
            </div>

            <div className="flex-1 overflow-y-auto p-12 bg-slate-500/10 flex justify-center scrollbar-hide">
              <div ref={reportRef} className="w-[210mm] min-h-[297mm] bg-white shadow-2xl p-[15mm] flex flex-col animate-in slide-in-from-bottom-4 duration-500">
                {/* LettersHead Dynamic */}
                <div className="flex justify-between items-start border-b-4 border-slate-900 pb-6 mb-8 relative">
                   <div className="flex items-center space-x-6">
                      <div className="relative group">
                        {hospitalConfig.logo ? (
                          <img src={hospitalConfig.logo} className="w-20 h-20 object-contain rounded-2xl border-2 border-slate-100 p-1" />
                        ) : (
                          <div className="w-20 h-20 bg-[#8B0000] rounded-2xl flex items-center justify-center text-white font-black text-3xl shadow-lg">H</div>
                        )}
                        <Activity size={16} className="absolute -bottom-1 -right-1 text-white bg-[#8B0000] rounded-full p-0.5 border-2 border-white" />
                      </div>
                      <div>
                        <h1 className="text-3xl font-black text-slate-900 leading-none uppercase">{hospitalConfig.name}</h1>
                        <p className="text-[10px] font-bold text-slate-500 mt-2 uppercase tracking-wide">{hospitalConfig.address}</p>
                        <p className="text-[10px] font-black text-slate-800 uppercase tracking-tighter">{hospitalConfig.contact} ${hospitalConfig.email ? '| ' + hospitalConfig.email : ''}</p>
                        <p className="text-[9px] font-black text-[#8B0000] uppercase tracking-widest mt-1">HealthBridge HMIS Network | Reg#: {hospitalConfig.phcNo}</p>
                      </div>
                   </div>
                   <div className="text-right">
                      <QrCode size={64} className="ml-auto mb-1" />
                      <div className="text-[9px] font-black text-slate-800">{selectedReport.receiptNo}</div>
                   </div>
                </div>

                <div className="text-center mb-8">
                  <h2 className="text-xl font-black uppercase border-b-2 border-slate-200 inline-block px-10 pb-1 tracking-[0.2em] text-slate-800">LAB. INVESTIGATIONS REPORT</h2>
                </div>

                <div className="grid grid-cols-2 gap-x-12 gap-y-1.5 text-[11px] bg-slate-50/50 p-6 border border-slate-200 mb-10">
                  <div className="flex"><span className="w-24 font-black text-slate-400 uppercase tracking-wider">MR #:</span> <span className="font-black text-slate-900">{selectedReport.mrNo}</span></div>
                  <div className="flex"><span className="w-24 font-black text-slate-400 uppercase tracking-wider">Receipt #:</span> <span className="font-black text-slate-900">{selectedReport.receiptNo}</span></div>
                  <div className="flex"><span className="w-24 font-black text-slate-400 uppercase tracking-wider">Patient:</span> <span className="font-black text-slate-900 uppercase">{selectedReport.patientName}</span></div>
                  <div className="flex"><span className="w-24 font-black text-slate-400 uppercase tracking-wider">Order Date:</span> <span className="font-black text-slate-900">{selectedReport.orderDate}</span></div>
                  <div className="flex"><span className="w-24 font-black text-slate-400 uppercase tracking-wider">Age/Sex:</span> <span className="font-black text-slate-900">{selectedReport.age} / {selectedReport.gender}</span></div>
                  <div className="flex"><span className="w-24 font-black text-slate-400 uppercase tracking-wider">Result Date:</span> <span className="font-black text-slate-900">{selectedReport.resultDate}</span></div>
                </div>

                <div className="flex-1 space-y-10">
                  {selectedReport.tests.map((test, idx) => (
                    <div key={idx} className="space-y-2">
                       <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider bg-slate-100 p-2">{test.name}</h3>
                       <table className="w-full text-left">
                         <thead>
                           <tr className="border-b border-slate-200 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                             <th className="py-2 pl-4">Parameter</th>
                             <th className="py-2 text-center">Result</th>
                             <th className="py-2 pr-4 text-right">Ref. Range</th>
                           </tr>
                         </thead>
                         <tbody className="divide-y divide-slate-100">
                            {test.results.map((res, ridx) => (
                              <tr key={ridx} className="text-xs">
                                <td className="py-3 pl-4 font-bold text-slate-700">{res.parameter}</td>
                                <td className="py-3 text-center">
                                  <span className={`font-black flex items-center justify-center ${res.flag ? 'text-blue-600' : 'text-slate-900'}`}>
                                    {res.flag === 'down' && <span className="mr-1">↓</span>}
                                    {res.flag === 'up' && <span className="mr-1">↑</span>}
                                    {res.result} {res.unit}
                                  </span>
                                </td>
                                <td className="py-3 pr-4 text-right font-medium text-slate-500 italic">{res.refRange}</td>
                              </tr>
                            ))}
                         </tbody>
                       </table>
                    </div>
                  ))}
                </div>

                <div className="mt-20 pt-10 grid grid-cols-4 gap-6">
                   {signatureSlots.filter(s => s.enabled).map(slot => (
                     <div key={slot.id} className="text-center space-y-0.5 border-t border-slate-400 pt-4">
                        <div className="text-[11px] font-black text-slate-900 uppercase leading-none">{slot.fullName}</div>
                        <div className="text-[9px] font-bold text-slate-500 uppercase tracking-tighter">{slot.qualification}</div>
                        <div className="text-[9px] font-black text-slate-800 uppercase tracking-widest">{slot.designation}</div>
                        <div className="text-[8px] font-medium text-slate-400 uppercase">{slot.institution}</div>
                     </div>
                   ))}
                </div>
              </div>
            </div>

            <div className="p-6 bg-white border-t border-slate-100 flex items-center justify-between shrink-0">
               <div className="flex items-center space-x-3">
                 <button onClick={handlePrintReport} className="px-8 py-3 rounded-xl bg-white border-2 border-[#8B0000] text-[#8B0000] font-black text-xs uppercase tracking-widest shadow-xl shadow-red-900/5 active:scale-95 flex items-center space-x-2 hover:bg-red-50"><Printer size={18} /><span>Print Report</span></button>
               </div>
               <button onClick={() => setShowPreviewModal(false)} className="px-8 py-3 rounded-xl border border-slate-200 text-slate-500 font-bold text-xs uppercase tracking-widest hover:bg-slate-50 transition-colors">Close Preview</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LabReports;
