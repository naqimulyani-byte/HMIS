
import React, { useState } from 'react';
import { Scan, Search, Plus, Calendar, X, Check, Printer, User, Filter } from 'lucide-react';
import { PRIMARY_COLOR, PANEL_CATEGORIES } from '../constants';

interface RadiologyOrder {
  id: string;
  receiptNo: string;
  trxNo: string;
  mrNo: string;
  patientName: string;
  tests: string[];
  panel: string;
  grossAmount: number;
  discount: number;
  netAmount: number;
  date: string;
  status: 'Pending' | 'Paid';
}

const RADIOLOGY_TESTS = [
  { id: 'r1', name: 'X-Ray Pelvis AP', fee: 800 },
  { id: 'r2', name: 'CT Scan Brain', fee: 5500 },
  { id: 'r3', name: 'X-Ray Chest PA', fee: 800 },
  { id: 'r4', name: 'Ultrasound', fee: 1500 },
  { id: 'r5', name: 'MRI Spine', fee: 8500 },
  { id: 'r6', name: 'X-Ray Chest', fee: 800 },
  { id: 'r7', name: 'Ultrasound Abdomen', fee: 1500 },
];

const RadiologyCounter: React.FC = () => {
  const [fromDate, setFromDate] = useState('2026-03-01');
  const [toDate, setToDate] = useState('2026-03-01');
  const [orders, setOrders] = useState<RadiologyOrder[]>([]);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [modalStep, setModalStep] = useState<'search' | 'select'>('search');
  const [searchQuery, setSearchQuery] = useState('');
  const [orderSearchQuery, setOrderSearchQuery] = useState('');
  const [testSearchQuery, setTestSearchQuery] = useState('');
  
  // New Order State
  const [selectedPatient, setSelectedPatient] = useState<any>(null);
  const [selectedTests, setSelectedTests] = useState<string[]>([]);
  const [selectedPanel, setSelectedPanel] = useState(PANEL_CATEGORIES[3]); // Default: Paying

  // Mock registered patients
  const registeredPatients = [
    { id: '1', mrNo: '2601010003', name: 'HAROON', gender: 'Male', age: '5 Years', dept: 'Eye OPD', time: '01/01/2026 02:21 PM' },
    { id: '2', mrNo: '2601010002', name: 'SAIF ULLAH', gender: 'Male', age: '25 Years', dept: 'Pediatrics OPD', time: '01/01/2026 02:04 PM' },
  ];

  const handlePatientSelect = (patient: any) => {
    setSelectedPatient(patient);
    setModalStep('select');
  };

  const toggleTest = (testId: string) => {
    setSelectedTests(prev => 
      prev.includes(testId) ? prev.filter(id => id !== testId) : [...prev, testId]
    );
  };

  const calculateTotals = () => {
    const gross = selectedTests.reduce((acc, testId) => {
      const test = RADIOLOGY_TESTS.find(t => t.id === testId);
      return acc + (test?.fee || 0);
    }, 0);
    const discountAmount = Math.round((gross * selectedPanel.discount) / 100);
    const net = gross - discountAmount;
    return { gross, discountAmount, net };
  };

  const handleFinalizeOrder = () => {
    const { gross, discountAmount, net } = calculateTotals();
    const now = new Date();
    const formattedDate = now.toLocaleDateString('en-GB') + ' ' + now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: true });
    
    const count = orders.length + 1;
    const newOrder: RadiologyOrder = {
      id: Math.random().toString(36).substr(2, 9),
      receiptNo: `RR260103${String(count).padStart(4, '0')}`,
      trxNo: `RT260103${String(count).padStart(4, '0')}`,
      mrNo: selectedPatient.mrNo,
      patientName: selectedPatient.name,
      tests: selectedTests.map(id => RADIOLOGY_TESTS.find(t => t.id === id)?.name || ''),
      panel: selectedPanel.name,
      grossAmount: gross,
      discount: discountAmount,
      netAmount: net,
      date: formattedDate,
      status: 'Paid'
    };

    setOrders([newOrder, ...orders]);
    resetOrderForm();
    setShowOrderModal(false);
  };

  const resetOrderForm = () => {
    setSelectedPatient(null);
    setSelectedTests([]);
    setSelectedPanel(PANEL_CATEGORIES[3]);
    setOrderSearchQuery('');
    setTestSearchQuery('');
    setModalStep('search');
  };

  const triggerReceiptPrint = (order: RadiologyOrder) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    const html = `
      <html>
        <head>
          <title>Radiology Receipt - ${order.receiptNo}</title>
          <style>
            @page { size: 80mm 200mm; margin: 0; }
            body { font-family: 'Courier New', Courier, monospace; width: 70mm; margin: 5mm; font-size: 12px; }
            .center { text-align: center; }
            .header { border-bottom: 1px dashed #000; padding-bottom: 5px; margin-bottom: 10px; }
            .row { display: flex; justify-content: space-between; margin: 2px 0; }
            .bold { font-weight: bold; }
            .divider { border-top: 1px dashed #000; margin: 5px 0; }
            .total-section { font-weight: bold; margin-top: 10px; }
            .footer { margin-top: 20px; font-size: 10px; text-align: center; }
          </style>
        </head>
        <body onload="window.print(); window.close();">
          <div class="header center">
            <div class="bold">DHQ HOSPITAL SUDHNUTI</div>
            <div>RADIOLOGY RECEIPT</div>
            <div class="divider"></div>
          </div>
          <div class="row"><span>Receipt#</span> <span class="bold">${order.receiptNo}</span></div>
          <div class="row"><span>MR No.</span> <span class="bold">${order.mrNo}</span></div>
          <div class="row"><span>Patient</span> <span class="bold">${order.patientName}</span></div>
          <div class="divider"></div>
          <div class="bold">TESTS:</div>
          ${order.tests.map(t => `<div class="row"><span>- ${t}</span></div>`).join('')}
          <div class="divider"></div>
          <div class="row total-section"><span>NET PAYABLE:</span> <span>Rs. ${order.netAmount}</span></div>
          <div class="footer">
            <div class="bold">STATUS: PAID</div>
            <div>Powered by HealthBridge HMIS</div>
          </div>
        </body>
      </html>
    `;
    printWindow.document.write(html);
    printWindow.document.close();
  };

  const filteredOrders = orders.filter(o => 
    o.patientName.toLowerCase().includes(searchQuery.toLowerCase()) || 
    o.mrNo.includes(searchQuery) || 
    o.receiptNo.includes(searchQuery)
  );

  const filteredPatients = registeredPatients.filter(p => 
    p.name.toLowerCase().includes(orderSearchQuery.toLowerCase()) || 
    p.mrNo.includes(orderSearchQuery)
  );

  const filteredTests = RADIOLOGY_TESTS.filter(t => 
    t.name.toLowerCase().includes(testSearchQuery.toLowerCase())
  );

  const { net } = calculateTotals();

  return (
    <div className="p-6 max-w-[1600px] mx-auto space-y-6">
      {/* Search & Action Header */}
      <div className="flex justify-between items-center bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
        <div className="flex items-center space-x-4 flex-1">
          <div className="relative flex-1 max-w-md">
            <input 
              type="text" 
              placeholder="Search by Name, MR, or Receipt..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:border-[#8B0000] outline-none"
            />
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
          </div>
          <select className="bg-white border border-gray-200 rounded-xl px-4 py-2.5 text-sm font-medium outline-none">
            <option>All Panels</option>
            {PANEL_CATEGORIES.map(p => <option key={p.id}>{p.name}</option>)}
          </select>
          
          {/* Working Date Filter */}
          <div className="flex items-center space-x-3 bg-white border border-gray-200 rounded-xl px-4 py-2.5 shadow-sm">
             <div className="flex items-center space-x-2">
               <input 
                 type="date" 
                 value={fromDate} 
                 onChange={(e) => setFromDate(e.target.value)}
                 className="text-xs font-black outline-none bg-transparent cursor-pointer hover:text-[#8B0000] transition-colors" 
               />
               <Calendar size={14} className="text-gray-400 pointer-events-none" />
             </div>
             <span className="text-gray-300 font-bold">-</span>
             <div className="flex items-center space-x-2">
               <input 
                 type="date" 
                 value={toDate} 
                 onChange={(e) => setToDate(e.target.value)}
                 className="text-xs font-black outline-none bg-transparent cursor-pointer hover:text-[#8B0000] transition-colors" 
               />
               <Calendar size={14} className="text-gray-400 pointer-events-none" />
             </div>
          </div>
        </div>
        
        <button 
          onClick={() => { resetOrderForm(); setShowOrderModal(true); }}
          className="ml-4 flex items-center space-x-2 px-8 py-3 rounded-xl bg-white border-2 border-[#8B0000] text-[#8B0000] font-black uppercase tracking-widest transition-all active:scale-95 shadow-xl shadow-red-900/10 hover:bg-red-50"
        >
          <Plus size={18} />
          <span>New Order</span>
        </button>
      </div>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-[#FDF2F2] border-l-4 border-[#8B0000] rounded-xl shadow-sm overflow-hidden">
          <div className="p-3 bg-[#FDF2F2] flex justify-between items-center border-b border-[#F9EAEA]">
            <div className="flex items-center text-[#8B0000] font-black text-xs uppercase tracking-tight">
              <ActivityIcon size={14} className="mr-2" />
              All Categories
            </div>
            <span className="bg-[#8B0000] text-white text-[10px] font-black px-2 py-0.5 rounded">
              {orders.length}
            </span>
          </div>
          <div className="p-4 space-y-2">
            <div className="flex justify-between text-[11px] text-slate-500 font-bold uppercase">
              <span>Gross</span>
              <span className="text-slate-800">{orders.reduce((a, b) => a + b.grossAmount, 0).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-[11px] text-slate-500 font-bold uppercase">
              <span>Disc.</span>
              <span className="text-slate-800">{orders.reduce((a, b) => a + b.discount, 0).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-[11px] text-red-500 font-bold uppercase">
              <span>Refund</span>
              <span>-0</span>
            </div>
            <div className="flex justify-between text-base font-black text-[#8B0000] border-t border-red-100 pt-2 mt-2">
              <span>NET</span>
              <span>{orders.reduce((a, b) => a + b.netAmount, 0).toLocaleString()}</span>
            </div>
          </div>
        </div>

        <div className="bg-[#F2F4FD] border-l-4 border-blue-800 rounded-xl shadow-sm overflow-hidden">
          <div className="p-3 bg-[#F2F4FD] flex justify-between items-center border-b border-[#E9ECF9]">
            <div className="flex items-center text-blue-800 font-black text-xs uppercase tracking-tight">
              Paying
            </div>
            <span className="bg-blue-800 text-white text-[10px] font-black px-2 py-0.5 rounded">
              {orders.filter(o => o.panel === 'Paying').length}
            </span>
          </div>
          <div className="p-4 space-y-2">
            <div className="flex justify-between text-[11px] text-slate-500 font-bold uppercase">
              <span>Gross</span>
              <span className="text-slate-800">{orders.filter(o => o.panel === 'Paying').reduce((a, b) => a + b.grossAmount, 0).toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-[11px] text-slate-500 font-bold uppercase">
              <span>Disc.</span>
              <span className="text-slate-800">0</span>
            </div>
            <div className="flex justify-between text-[11px] text-red-500 font-bold uppercase">
              <span>Refund</span>
              <span>-0</span>
            </div>
            <div className="flex justify-between text-base font-black text-blue-800 border-t border-blue-100 pt-2 mt-2">
              <span>NET</span>
              <span>{orders.filter(o => o.panel === 'Paying').reduce((a, b) => a + b.netAmount, 0).toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Orders List */}
      <div className="space-y-2">
        {filteredOrders.length > 0 ? (
          filteredOrders.map(order => (
            <div key={order.id} className="bg-white rounded-xl border border-slate-100 shadow-sm p-4 flex items-center justify-between group hover:border-[#8B0000]/20 transition-all">
               <div className="flex-1">
                 <h4 className="font-black text-slate-800 text-lg uppercase leading-none mb-1">{order.patientName}</h4>
                 <div className="text-[11px] font-bold text-slate-400 uppercase tracking-tighter flex items-center">
                   MR: {order.mrNo} <span className="mx-2 opacity-50">•</span> {order.date}
                 </div>
               </div>

               <div className="flex items-center space-x-12">
                 <div className="flex flex-col items-center">
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest leading-none mb-1">Receipt No</span>
                    <span className="text-xs font-black text-[#8B0000] tracking-tight">{order.receiptNo}</span>
                 </div>
                 <div className="flex flex-col items-center">
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest leading-none mb-1">Trx. No</span>
                    <span className="text-xs font-black text-green-600 tracking-tight">{order.trxNo}</span>
                 </div>
                 <div className="flex flex-col items-center">
                    <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest leading-none mb-1">Category</span>
                    <span className="text-xs font-black text-blue-800 tracking-tight">{order.panel}</span>
                 </div>
                 
                 <div className="flex items-center space-x-2 bg-green-50 text-green-600 px-3 py-1 rounded-full border border-green-100">
                    <Check size={12} className="stroke-[3px]" />
                    <span className="text-[10px] font-black uppercase tracking-widest">Paid</span>
                 </div>

                 <div className="text-right min-w-[80px]">
                    <div className="text-[10px] font-bold text-slate-400 uppercase">{order.tests.length} Tests</div>
                    <div className="text-base font-black text-slate-800 leading-none">{order.netAmount}</div>
                 </div>

                 <button 
                   onClick={() => triggerReceiptPrint(order)}
                   className="w-10 h-10 rounded-lg border border-red-100 text-[#8B0000] flex items-center justify-center hover:bg-[#8B0000] hover:text-white transition-all active:scale-95"
                 >
                   <Printer size={18} />
                 </button>
               </div>
            </div>
          ))
        ) : (
          <div className="bg-white rounded-3xl border border-dashed border-slate-200 p-24 flex flex-col items-center justify-center text-center">
            <Scan size={48} className="text-slate-200 mb-6" />
            <h3 className="text-xl font-black text-gray-800 uppercase tracking-tight">No Orders Found</h3>
            <p className="text-slate-400 text-sm font-medium mt-1">Ordered radiology tests will appear here.</p>
          </div>
        )}
      </div>

      {/* New Order Modal */}
      {showOrderModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
           <div className="bg-white rounded-2xl shadow-2xl w-full max-w-xl overflow-hidden animate-in zoom-in duration-200 flex flex-col max-h-[90vh]">
              <div className="bg-[#8B0000] p-4 flex justify-between items-center text-white shrink-0">
                 <h4 className="font-black text-lg tracking-tight uppercase">New Radiology Order</h4>
                 <button onClick={() => setShowOrderModal(false)} className="hover:bg-white/10 p-1.5 rounded-full transition-colors">
                    <X size={24} />
                 </button>
              </div>

              <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
                {modalStep === 'search' ? (
                  <div className="space-y-6">
                    <div className="relative">
                       <input 
                         type="text" 
                         placeholder="Search Patient by MR / Name..."
                         value={orderSearchQuery}
                         autoFocus
                         onChange={(e) => setOrderSearchQuery(e.target.value)}
                         className="w-full pl-12 pr-4 py-4 rounded-xl border-2 border-slate-100 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner"
                       />
                       <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" />
                    </div>

                    <div className="space-y-3">
                      {orderSearchQuery.length > 0 && filteredPatients.map(patient => (
                        <div key={patient.id} className="p-5 border border-slate-50 rounded-2xl bg-white flex justify-between items-center group hover:bg-red-50/30 transition-all border-l-4 hover:border-l-[#8B0000]">
                           <div>
                              <div className="font-black text-slate-800 text-base uppercase leading-none mb-1">{patient.name}</div>
                              <div className="text-[11px] font-bold text-slate-400 uppercase tracking-tighter">
                                MR#: {patient.mrNo} | Age: {patient.age} | Dept: {patient.dept}
                              </div>
                           </div>
                           <button 
                             onClick={() => handlePatientSelect(patient)}
                             className="bg-[#8B0000] text-white p-2.5 rounded-xl shadow-lg shadow-red-900/10 active:scale-95 transition-all"
                           >
                             <Plus size={18} />
                           </button>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6 animate-in fade-in duration-300">
                    <div className="bg-[#FFF5F5] border border-red-50 rounded-2xl p-5 flex justify-between items-center">
                       <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-[#8B0000] shadow-sm border border-red-50">
                             <User size={24} />
                          </div>
                          <div>
                             <h5 className="font-black text-slate-800 uppercase leading-none mb-1 text-base">{selectedPatient.name}</h5>
                             <div className="text-[10px] font-bold text-slate-500 uppercase tracking-tight">MR#: {selectedPatient.mrNo} | Age: {selectedPatient.age}</div>
                             <div className="text-[10px] font-black text-[#8B0000] uppercase mt-1">{selectedPatient.dept} | {selectedPatient.time}</div>
                          </div>
                       </div>
                       <button onClick={() => setModalStep('search')} className="text-[#8B0000] font-black text-[11px] hover:underline uppercase tracking-widest">Change</button>
                    </div>

                    <div className="space-y-1.5 relative">
                       <label className="text-[11px] font-black text-[#8B0000] uppercase tracking-widest pl-1">Panel Category</label>
                       <select 
                         className="w-full px-4 py-3 rounded-xl border-2 border-slate-100 focus:border-[#8B0000] outline-none text-sm font-black uppercase appearance-none bg-white"
                         value={selectedPanel.id}
                         onChange={(e) => setSelectedPanel(PANEL_CATEGORIES.find(p => p.id === e.target.value) || PANEL_CATEGORIES[3])}
                       >
                          {PANEL_CATEGORIES.map(p => (
                            <option key={p.id} value={p.id}>{p.name} (% discount)</option>
                          ))}
                       </select>
                    </div>

                    <div className="space-y-3">
                       <div className="flex justify-between items-center px-1">
                          <label className="text-[11px] font-black text-[#8B0000] uppercase tracking-widest">Select Radiology Tests</label>
                          <div className="relative">
                             <input 
                               type="text" 
                               placeholder="Search tests..." 
                               value={testSearchQuery}
                               onChange={(e) => setTestSearchQuery(e.target.value)}
                               className="text-[10px] pl-8 pr-4 py-2 border-2 border-slate-50 rounded-xl focus:border-[#8B0000] outline-none font-bold" 
                             />
                             <Search size={12} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" />
                          </div>
                       </div>
                       
                       <div className="border border-slate-50 rounded-2xl overflow-hidden max-h-[250px] overflow-y-auto shadow-inner bg-slate-50/30 custom-scrollbar">
                          {filteredTests.map(test => {
                             const isChecked = selectedTests.includes(test.id);
                             return (
                               <label key={test.id} className="flex items-center justify-between p-4 hover:bg-white cursor-pointer border-b border-white last:border-none group transition-all">
                                  <div className="flex items-center">
                                     <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${isChecked ? 'bg-[#8B0000] border-[#8B0000]' : 'bg-white border-slate-200'}`}>
                                        {isChecked && <Check size={12} className="text-white stroke-[4px]" />}
                                     </div>
                                     <input 
                                       type="checkbox" 
                                       checked={isChecked}
                                       onChange={() => toggleTest(test.id)}
                                       className="hidden" 
                                     />
                                     <span className={`ml-4 text-xs font-black uppercase transition-colors ${isChecked ? 'text-slate-800' : 'text-slate-500'}`}>{test.name}</span>
                                  </div>
                                  <span className={`text-[11px] font-black ${isChecked ? 'text-[#8B0000]' : 'text-slate-400'} uppercase`}>Rs. {test.fee}</span>
                               </label>
                             );
                          })}
                       </div>
                    </div>

                    <div className="bg-[#FFF5F5] border border-red-50 rounded-xl p-4 flex justify-between items-center text-red-800 font-black uppercase">
                       <div className="text-[11px] tracking-widest">
                         {selectedTests.length} test(s) selected
                       </div>
                       <div className="text-sm tracking-tight">
                         Total: Rs. {net.toLocaleString()}
                       </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="p-6 border-t border-slate-50 shrink-0 bg-white">
                <div className="flex justify-end space-x-3">
                   <button 
                     onClick={() => setShowOrderModal(false)}
                     className="px-8 py-3 rounded-xl border-2 border-slate-200 text-slate-400 font-black text-xs uppercase tracking-widest hover:bg-slate-50 transition-all"
                   >
                     Cancel
                   </button>
                   <button 
                     onClick={handleFinalizeOrder}
                     disabled={modalStep === 'search' || selectedTests.length === 0}
                     className={`px-10 py-3 rounded-xl font-black text-xs uppercase tracking-widest shadow-xl transition-all active:scale-95 border-2 ${
                       modalStep === 'search' || selectedTests.length === 0 
                       ? 'bg-slate-50 text-slate-300 border-slate-200 cursor-not-allowed' 
                       : 'bg-white border-[#8B0000] text-[#8B0000] shadow-red-900/5 hover:bg-red-50'
                     }`}
                   >
                     Add Order
                   </button>
                </div>
              </div>
           </div>
        </div>
      )}
      
      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 6px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #f8fafc; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #cbd5e0; }
      `}</style>
    </div>
  );
};

const ActivityIcon = ({ size, className }: { size: number; className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
  </svg>
);

export default RadiologyCounter;
