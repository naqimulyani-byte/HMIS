
import React, { useState, useMemo } from 'react';
import { RotateCcw, Search, X, Check, Printer, User, DollarSign, AlertCircle, ClipboardList, ShieldAlert } from 'lucide-react';
import { HospitalConfig } from '../types';

interface RefundItem {
  id: string;
  name: string;
  type: string;
  fee: number;
  status: string;
}

interface ReceiptData {
  receiptNo: string;
  mrNo: string;
  patientName: string;
  cnic: string;
  date: string;
  items: RefundItem[];
}

interface ProcessRefundProps {
  hospitalConfig: HospitalConfig;
}

const ProcessRefund: React.FC<ProcessRefundProps> = ({ hospitalConfig }) => {
  const [receiptQuery, setReceiptQuery] = useState('');
  const [foundReceipt, setFoundReceipt] = useState<ReceiptData | null>(null);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [approvedBy, setApprovedBy] = useState('');
  const [refundReason, setRefundReason] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [lastRefundId, setLastRefundId] = useState('');
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  // Expanded mock data
  const mockReceipts: ReceiptData[] = [
    {
      receiptNo: 'LR2601110001',
      mrNo: '2601010003',
      patientName: 'HAROON',
      cnic: 'N/A',
      date: '11/01/2026 12:42 AM',
      items: [
        { id: 'i1', name: 'Blood Glucose (R)', type: 'INVESTIGATION', fee: 150, status: '-' },
        { id: 'i2', name: 'Liver Function Test (LFT)', type: 'INVESTIGATION', fee: 1200, status: '-' },
        { id: 'i3', name: 'CBC', type: 'INVESTIGATION', fee: 700, status: '-' },
      ]
    },
    {
      receiptNo: 'LR2601020002',
      mrNo: '2601010002',
      patientName: 'SAIF ULLAH',
      cnic: '33101-7654321-1',
      date: '02/01/2026 10:15 AM',
      items: [
        { id: 'i4', name: 'X-Ray Chest PA', type: 'RADIOLOGY', fee: 800, status: '-' },
        { id: 'i5', name: 'Lipid Profile', type: 'INVESTIGATION', fee: 1200, status: '-' },
      ]
    },
    {
      receiptNo: 'PRR260110001',
      mrNo: '2601010001',
      patientName: 'SAJJAAD',
      cnic: '33101-9999999-1',
      date: '10/01/2026 08:30 PM',
      items: [
        { id: 'i6', name: 'Minor Procedure', type: 'PROCEDURE', fee: 1000, status: '-' },
      ]
    }
  ];

  const handleFindReceipt = () => {
    const query = receiptQuery.trim().toUpperCase();
    if (!query) return;

    const result = mockReceipts.find(r => 
      r.receiptNo.toUpperCase() === query || 
      r.mrNo.toUpperCase() === query
    );

    if (result) {
      setFoundReceipt(result);
      setSelectedItems(result.items.map(i => i.id));
      setIsSuccess(false);
    } else {
      alert(`No receipt found with ID or MR#: ${query}`);
      setFoundReceipt(null);
    }
  };

  const toggleItem = (id: string) => {
    setSelectedItems(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleDeselectAll = () => setSelectedItems([]);
  const handleSelectAll = () => {
    if (foundReceipt) setSelectedItems(foundReceipt.items.map(i => i.id));
  };

  const totalRefundAmount = useMemo(() => {
    if (!foundReceipt) return 0;
    return foundReceipt.items
      .filter(i => selectedItems.includes(i.id))
      .reduce((sum, item) => sum + item.fee, 0);
  }, [foundReceipt, selectedItems]);

  const handleInitiateRefund = () => {
    if (selectedItems.length === 0) {
      alert('Please select at least one item to refund.');
      return;
    }
    if (!approvedBy || !refundReason) {
      alert('Please enter who authorized the refund and the reason.');
      return;
    }
    setShowConfirmModal(true);
  };

  const handleFinalConfirm = () => {
    if (!foundReceipt) return;
    const refundId = `RF${foundReceipt.receiptNo.slice(-8)}`;
    setLastRefundId(refundId);
    setIsSuccess(true);
    setShowConfirmModal(false);
  };

  const handlePrintRefundSlip = () => {
    if (!foundReceipt) return;

    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const now = new Date();
    const formattedDate = now.toLocaleDateString('en-GB') + ' ' + now.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: true });

    const html = `
      <html>
        <head>
          <title>Refund Slip - ${lastRefundId}</title>
          <style>
            @page { size: A5; margin: 5mm; }
            body { font-family: 'Inter', sans-serif; margin: 0; padding: 10px; color: #333; line-height: 1.3; font-size: 10px; }
            .header { display: flex; align-items: center; justify-content: center; position: relative; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 15px; }
            .hospital-info { text-align: center; }
            .hospital-info h1 { margin: 0; font-size: 16px; font-weight: 800; text-transform: uppercase; }
            .hospital-info p { margin: 1px 0; color: #666; font-size: 8px; }
            .refund-title { text-align: center; margin-bottom: 15px; }
            .refund-title span { font-weight: 800; text-transform: uppercase; border: 2px solid #000; padding: 3px 20px; border-radius: 5px; font-size: 11px; }
            .details-grid { display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 5px; background: #f4f7f6; padding: 10px; margin-bottom: 15px; }
            .detail-item { margin-bottom: 4px; }
            .label { font-weight: 700; color: #777; display: block; font-size: 7px; text-transform: uppercase; }
            .value { font-weight: 800; font-size: 10px; color: #000; text-transform: uppercase; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
            th { text-align: left; padding: 6px; border-bottom: 1.5px solid #333; text-transform: uppercase; font-size: 8px; color: #555; }
            td { padding: 6px; border-bottom: 1px solid #eee; font-size: 10px; }
            .fee-col { text-align: right; }
            .totals { border-top: 2px solid #000; padding-top: 5px; }
            .refund-amount-box { background: #f4f7f6; padding: 5px 10px; display: flex; justify-content: flex-end; align-items: center; margin-top: 5px; }
            .sig-box { text-align: center; width: 45%; border-top: 1.5px solid #000; padding-top: 5px; font-weight: 800; font-size: 8px; text-transform: uppercase; }
          </style>
        </head>
        <body onload="window.print(); window.close();">
          <div class="header">
            <div class="hospital-info">
              <h1>${hospitalConfig.name}</h1>
              <p>${hospitalConfig.address}</p>
              <p>Contact: ${hospitalConfig.contact}</p>
            </div>
          </div>
          <div class="refund-title"><span>Refund Slip</span></div>
          <div class="details-grid">
            <div class="detail-item"><span class="label">MR NO</span><span class="value">${foundReceipt.mrNo}</span></div>
            <div class="detail-item"><span class="label">PATIENT NAME</span><span class="value">${foundReceipt.patientName}</span></div>
            <div class="detail-item"><span class="label">RECEIPT NO</span><span class="value">${foundReceipt.receiptNo}</span></div>
            <div class="detail-item"><span class="label">REFUND NO</span><span class="value">${lastRefundId}</span></div>
            <div class="detail-item"><span class="label">DATE</span><span class="value">${formattedDate}</span></div>
            <div class="detail-item"><span class="label">TYPE</span><span class="value">Full Refund</span></div>
            <div class="detail-item"><span class="label">REASON</span><span class="value">${refundReason}</span></div>
            <div class="detail-item"><span class="label">APPROVED BY</span><span class="value">${approvedBy}</span></div>
          </div>
          <table>
            <thead><tr><th>Item Description</th><th>Type</th><th class="fee-col">Paid Amount</th></tr></thead>
            <tbody>
              ${foundReceipt.items.filter(i => selectedItems.includes(i.id)).map(item => `
                <tr><td>${item.name}</td><td>${item.type}</td><td class="fee-col">Rs. ${item.fee}</td></tr>
              `).join('')}
            </tbody>
          </table>
          <div class="totals">
            <div class="refund-amount-box">
              <span style="font-weight:700; margin-right:20px; font-size:12px;">Total Refunded Amount</span>
              <span style="font-weight:800; font-size:14px;">Rs. ${totalRefundAmount}</span>
            </div>
          </div>
          <div style="margin-top: 40px; display: flex; justify-content: space-between;">
            <div class="sig-box">Authorized Signature</div>
            <div class="sig-box">Patient / Receiver's Sign</div>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(html);
    printWindow.document.close();
  };

  const handleReset = () => {
    setFoundReceipt(null);
    setReceiptQuery('');
    setSelectedItems([]);
    setApprovedBy('');
    setRefundReason('');
    setIsSuccess(false);
    setShowConfirmModal(false);
  };

  return (
    <div className="p-6 max-w-[1600px] mx-auto flex flex-col lg:flex-row gap-6 h-[calc(100vh-120px)]">
      {/* Left Pane: Search */}
      <div className="w-full lg:w-[400px] flex flex-col space-y-4 h-full shrink-0">
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 flex flex-col h-full overflow-hidden">
          <div className="p-5 border-b border-slate-100">
            <h3 className="text-sm font-black text-[#8B0000] uppercase tracking-tight flex items-center">
              Search Receipt
            </h3>
          </div>
          
          <div className="p-6 space-y-6">
            <div className="relative">
              <input 
                type="text" 
                placeholder="Receipt # or MR #..." 
                value={receiptQuery}
                onChange={(e) => setReceiptQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleFindReceipt()}
                className="w-full pl-10 pr-4 py-3.5 rounded-2xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner uppercase"
              />
              <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-300" />
            </div>

            <button 
              onClick={handleFindReceipt}
              className="w-full py-4 rounded-2xl bg-[#8B0000] text-white font-black text-xs uppercase tracking-widest shadow-xl shadow-red-900/10 active:scale-95 transition-all"
            >
              Find Receipt
            </button>

            <div className="pt-10 flex flex-col items-center justify-center text-center space-y-4">
              {foundReceipt && !isSuccess ? (
                <div className="w-full p-6 rounded-2xl bg-white border-2 border-[#8B0000] text-left animate-in fade-in zoom-in duration-300 shadow-md">
                  <div className="text-[10px] font-black text-slate-400 uppercase mb-2 flex justify-between">
                    <span>MR# {foundReceipt.mrNo}</span>
                    <span>{foundReceipt.date.split(' ')[0]}</span>
                  </div>
                  <h4 className="font-black text-lg text-red-800 uppercase leading-none mb-1">{foundReceipt.patientName}</h4>
                  <div className="flex justify-between items-end mt-4">
                    <span className="text-[11px] font-black text-[#8B0000] tracking-tight">{foundReceipt.receiptNo}</span>
                    <span className="text-sm font-black text-slate-800">Rs. {foundReceipt.items.reduce((a,b)=>a+b.fee, 0).toLocaleString()}</span>
                  </div>
                </div>
              ) : (
                <>
                  <div className="text-slate-200"><Search size={48} /></div>
                  <p className="text-slate-300 font-bold uppercase text-[10px] tracking-widest italic">No receipts found.</p>
                  <div className="text-[9px] text-slate-400 bg-slate-50 px-3 py-1 rounded-full">Try: LR2601020002</div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Right Pane: Selection */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 flex flex-col h-full overflow-hidden relative">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-sm font-black text-[#8B0000] uppercase tracking-tight flex items-center">
              Refund Selection
            </h3>
            {foundReceipt && !isSuccess && (
              <button onClick={handleReset} className="text-[10px] font-black text-red-600 bg-red-50 px-3 py-1 rounded-full uppercase hover:bg-red-100 transition-colors">
                Cancel Refund
              </button>
            )}
          </div>

          <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
            {isSuccess ? (
              <div className="flex flex-col items-center justify-center h-full text-center space-y-6 animate-in zoom-in duration-500">
                <div className="w-24 h-24 bg-green-50 rounded-full flex items-center justify-center text-green-500 shadow-lg border border-green-100">
                  <Check size={48} strokeWidth={3} />
                </div>
                <div>
                  <h2 className="text-3xl font-black text-slate-800 uppercase tracking-tight">Refund Successful!</h2>
                  <p className="text-slate-500 font-medium mt-2">Refund <span className="font-black text-red-800">#{lastRefundId}</span> has been processed.</p>
                </div>
                <div className="flex gap-4">
                  <button 
                    onClick={handlePrintRefundSlip}
                    className="px-10 py-4 rounded-2xl bg-[#008B45] text-white font-black text-xs uppercase tracking-widest shadow-xl shadow-green-900/10 active:scale-95 transition-all flex items-center space-x-2"
                  >
                    <Printer size={18} />
                    <span>Print Refund Slip (A5)</span>
                  </button>
                  <button 
                    onClick={handleReset}
                    className="px-10 py-4 rounded-2xl bg-white border-2 border-slate-200 text-slate-500 font-black text-xs uppercase tracking-widest hover:bg-slate-50 transition-all"
                  >
                    Done
                  </button>
                </div>
              </div>
            ) : foundReceipt ? (
              <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
                {/* Patient Header Card */}
                <div className="flex items-center justify-between p-6 rounded-3xl bg-slate-50/50 border border-slate-100">
                   <div className="flex items-center space-x-5">
                      <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center text-red-800 shadow-sm border border-red-50">
                        <User size={30} />
                      </div>
                      <div>
                        <h4 className="text-2xl font-black text-slate-800 uppercase tracking-tight leading-none">{foundReceipt.patientName}</h4>
                        <div className="flex items-center space-x-4 mt-2">
                           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">MR: {foundReceipt.mrNo}</span>
                           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">CNIC: {foundReceipt.cnic}</span>
                        </div>
                      </div>
                   </div>
                   <div className="text-right">
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-1">Receipt Date</span>
                      <span className="text-xs font-black text-slate-700 uppercase">{foundReceipt.date}</span>
                   </div>
                </div>

                {/* Items Table */}
                <div className="space-y-4">
                  <div className="flex justify-between items-center px-1">
                    <h5 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em]">Select Items to Refund</h5>
                    <button 
                      onClick={selectedItems.length === foundReceipt.items.length ? handleDeselectAll : handleSelectAll}
                      className="text-[10px] font-black text-red-800 uppercase tracking-widest hover:underline"
                    >
                      {selectedItems.length === foundReceipt.items.length ? 'Deselect All' : 'Select All'}
                    </button>
                  </div>

                  <div className="border border-slate-100 rounded-[2rem] overflow-hidden bg-white shadow-sm">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="bg-slate-50/50 border-b border-slate-100">
                          <th className="px-8 py-4 w-12"></th>
                          <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Item Name</th>
                          <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Type</th>
                          <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Fee</th>
                          <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Status</th>
                          <th className="px-4 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {foundReceipt.items.map((item) => (
                          <tr key={item.id} className={`hover:bg-slate-50/30 transition-all ${selectedItems.includes(item.id) ? 'bg-red-50/20' : ''}`}>
                            <td className="px-8 py-4">
                              <button 
                                onClick={() => toggleItem(item.id)}
                                className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all ${selectedItems.includes(item.id) ? 'bg-[#8B0000] border-[#8B0000]' : 'border-slate-200'}`}
                              >
                                {selectedItems.includes(item.id) && <Check size={14} className="text-white stroke-[4px]" />}
                              </button>
                            </td>
                            <td className="px-4 py-4 font-black text-slate-700 text-sm uppercase">{item.name}</td>
                            <td className="px-4 py-4 text-center">
                              <span className="text-[9px] font-black text-slate-400 bg-slate-50 px-2 py-1 rounded uppercase tracking-wider">{item.type}</span>
                            </td>
                            <td className="px-4 py-4 text-right font-black text-slate-700 text-sm">Rs. {item.fee.toLocaleString()}</td>
                            <td className="px-4 py-4 text-center font-bold text-slate-400 text-xs">{item.status}</td>
                            <td className="px-4 py-4 text-center">
                               <span className="text-[10px] font-black text-slate-300 uppercase">-</span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Form Fields */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Approved By (MS/AMS/DMS) *</label>
                    <input 
                      type="text" 
                      value={approvedBy}
                      onChange={e => setApprovedBy(e.target.value)}
                      placeholder="Who authorized?"
                      className="w-full px-5 py-4 rounded-2xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner" 
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Refund Reason *</label>
                    <textarea 
                      rows={1}
                      value={refundReason}
                      onChange={e => setRefundReason(e.target.value)}
                      placeholder="Reason for refund..."
                      className="w-full px-5 py-4 rounded-2xl border border-slate-200 focus:border-[#8B0000] outline-none text-sm font-bold shadow-inner resize-none" 
                    />
                  </div>
                </div>

                {/* Action Footer */}
                <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-6 border-t border-slate-50 pb-10">
                   <div className="flex items-center space-x-6 p-6 rounded-3xl bg-slate-50/50 border border-slate-100 flex-1 w-full md:w-auto">
                      <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-slate-400">
                        <DollarSign size={24} />
                      </div>
                      <div className="flex-1">
                        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-0.5">Total Refund</span>
                        <span className="text-2xl font-black text-red-800 leading-none">Rs. {totalRefundAmount.toLocaleString()}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-0.5">Items</span>
                        <span className="text-xl font-black text-slate-800 leading-none">{selectedItems.length}</span>
                      </div>
                   </div>

                   <button 
                     onClick={handleInitiateRefund}
                     className="w-full md:w-auto px-12 py-5 rounded-[1.5rem] bg-[#8B0000] text-white font-black text-xs uppercase tracking-widest shadow-2xl shadow-red-900/20 active:scale-95 transition-all flex items-center justify-center space-x-3"
                   >
                     <RotateCcw size={18} />
                     <span>Confirm & Refund</span>
                   </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center space-y-4">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center text-slate-200 border border-slate-100">
                  <Search size={32} />
                </div>
                <p className="text-slate-400 font-black uppercase text-[10px] tracking-widest">Select a receipt to list items.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* CUSTOM CONFIRMATION MODAL */}
      {showConfirmModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-[200] flex items-center justify-center p-4">
          <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-md overflow-hidden animate-in zoom-in duration-300">
            <div className="p-8 text-center space-y-6">
              <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center text-red-600 mx-auto shadow-inner">
                <ShieldAlert size={40} />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight">Confirm Refund</h3>
                <p className="text-sm text-slate-500 font-medium">Are you sure you want to process a refund of <span className="font-black text-red-800">Rs. {totalRefundAmount.toLocaleString()}</span>? This action cannot be undone.</p>
              </div>
              
              <div className="flex flex-col space-y-3">
                <button 
                  onClick={handleFinalConfirm}
                  className="w-full py-4 rounded-2xl bg-[#8B0000] text-white font-black text-sm uppercase tracking-widest shadow-xl shadow-red-900/20 active:scale-95 transition-all hover:bg-red-900"
                >
                  Yes, Process Refund
                </button>
                <button 
                  onClick={() => setShowConfirmModal(false)}
                  className="w-full py-4 rounded-2xl bg-slate-100 text-slate-500 font-black text-xs uppercase tracking-widest hover:bg-slate-200 transition-all"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #E2E8F0; border-radius: 10px; }
      `}</style>
    </div>
  );
};

export default ProcessRefund;
