
import React, { useState } from 'react';
import { Lock, User as UserIcon, Eye, EyeOff, ShieldCheck, Activity } from 'lucide-react';
import { PRIMARY_COLOR } from '../constants';
import { User } from '../types';

interface LoginProps {
  onLoginSuccess: (user: User) => void;
  hospitalName: string;
}

const Login: React.FC<LoginProps> = ({ onLoginSuccess, hospitalName }) => {
  const [cnic, setCnic] = useState('00000-0000000-0');
  const [password, setPassword] = useState('admin123');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // HARDCODED SUPER ADMIN CREDENTIALS
    if (cnic === '00000-0000000-0' && password === 'admin123') {
      const adminUser: User = {
        id: 'super-admin',
        fullName: 'Administrator',
        cnic: '00000-0000000-0',
        role: 'Admin',
        isActive: true,
        designation: 'Super User'
      };
      onLoginSuccess(adminUser);
    } else {
      setError('Invalid CNIC or Password. Access Denied.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      <div className="mb-8 text-center flex flex-col items-center">
        <div className="relative mb-4 group">
          <div 
            className="w-20 h-20 rounded-[2rem] flex items-center justify-center text-white font-bold text-5xl shadow-2xl shadow-red-900/30 animate-pulse group-hover:scale-110 transition-transform duration-500"
            style={{ backgroundColor: PRIMARY_COLOR }}
          >
            H
          </div>
          <div className="absolute -bottom-2 -right-2 bg-white p-2 rounded-2xl shadow-lg border border-slate-100">
            <Activity size={24} className="text-[#8B0000]" />
          </div>
        </div>
        <h1 className="text-4xl font-black tracking-tighter text-gray-800 uppercase">{hospitalName}</h1>
        <p className="text-[11px] font-black text-red-800 uppercase tracking-[0.4em] mt-2">Hospital Management Information System</p>
      </div>

      <div className="w-full max-w-md bg-white rounded-[2.5rem] shadow-2xl shadow-red-900/5 border border-slate-100 overflow-hidden">
        <div className="bg-slate-50/50 p-6 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ShieldCheck size={20} className="text-red-800" />
            <span className="font-black text-[10px] uppercase tracking-widest text-gray-800">Secure Access Portal</span>
          </div>
          <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest">v2.1 Stable</div>
        </div>

        <form onSubmit={handleLogin} className="p-10 space-y-6">
          {error && (
            <div className="bg-red-50 border border-red-100 text-red-600 text-xs font-bold p-4 rounded-xl flex items-center">
              <Lock size={14} className="mr-2" />
              {error}
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">CNIC Number</label>
            <div className="relative">
              <input 
                type="text" 
                value={cnic}
                onChange={(e) => setCnic(e.target.value)}
                placeholder="00000-0000000-0"
                className="w-full pl-12 pr-4 py-4 rounded-2xl border border-slate-100 bg-slate-50 focus:border-red-800 focus:bg-white outline-none text-sm font-bold transition-all shadow-inner"
              />
              <UserIcon size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between items-center pr-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest pl-1">Password</label>
              <button type="button" className="text-[10px] font-black text-red-800 uppercase tracking-widest hover:underline">Forgot?</button>
            </div>
            <div className="relative">
              <input 
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-12 pr-12 py-4 rounded-2xl border border-slate-100 bg-slate-50 focus:border-red-800 focus:bg-white outline-none text-sm font-bold transition-all shadow-inner"
              />
              <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
              <button 
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-300 hover:text-slate-500 transition-colors"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <button 
            type="submit"
            className="w-full py-5 rounded-[1.5rem] bg-white border-2 border-[#8B0000] text-[#8B0000] font-black text-xs uppercase tracking-[0.2em] shadow-2xl shadow-red-900/5 active:scale-95 transition-all mt-4 hover:bg-red-50"
          >
            Authenticate Session
          </button>
        </form>

        <div className="p-6 bg-slate-50 border-t border-slate-100 text-center">
          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">
            Developed by HealthBridge Systems &bull; 2026 v2.1
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
