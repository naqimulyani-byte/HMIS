
export enum UserRole {
  ADMIN = 'Admin',
  COUNTER = 'Counter',
  DOCTOR = 'Doctor'
}

export interface HospitalConfig {
  name: string;
  address: string;
  contact: string;
  phcNo: string;
  email: string;
  logo: string | null;
}

export interface Role {
  id: string;
  name: string;
  description: string;
  permissions: string[];
}

export interface User {
  id: string;
  cnic: string;
  fullName: string;
  fatherName?: string;
  designation?: string;
  contact?: string;
  address?: string;
  role: string;
  isActive: boolean;
  password?: string;
}

export interface Patient {
  id: string;
  mrNumber: string;
  fullName: string;
  guardianName: string;
  gender: 'Male' | 'Female' | 'Other';
  dob: { year: string; month: string; day: string };
  contact: string;
  cnic: string;
  address: string;
  registeredAt: string;
}

export interface PanelCategory {
  id: string;
  name: string;
  discount: number;
  color: string;
  badge: string;
  description?: string;
  isActive: boolean;
}

export interface LabTest {
  id: string;
  name: string;
  fee: number;
  params: number;
  isActive: boolean;
}

export interface Stats {
  gross: number;
  disc: number;
  refund: number;
  net: number;
  count: number;
}
